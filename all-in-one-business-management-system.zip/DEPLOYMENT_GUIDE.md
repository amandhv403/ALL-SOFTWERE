# Deployment Guide (putting the system on a live server)

"Deploying" means running the system on a server so that staff can reach it from the internet. Your team's computers only need a browser. This guide describes what a live deployment needs. It is not a step-by-step for one specific hosting company.

## Status

The project has **not** been deployed to a hosting provider yet. There was no GitHub or Vercel access during development. Steps below are the recommended path.

## What a live deployment needs

1. **A server or hosting service that can run Node.js 22 and keep files.** A small virtual server (VPS) from any provider in Bangladesh or abroad is simplest. A serverless platform (for example Vercel) also works for the web app, but it must have a PostgreSQL database and a persistent place to keep uploaded documents. Documents are stored in the `UPLOAD_DIR` folder, which serverless platforms do not keep between runs.
2. **A managed PostgreSQL database** (15 or newer) with automatic backups.
3. **HTTPS** (a secure certificate). Logins use cookies that are only sent over HTTPS when `COOKIE_SECURE=true`.
4. **A domain name**, for example `erp.yourcompany.com`.

## Environment settings

Set these in the server's environment (never in code or in GitHub):

| Setting | Example | Purpose |
|---|---|---|
| `DATABASE_URL` | `postgresql://app_user:...@db-host:5432/business_system?sslmode=require` | Database connection |
| `UPLOAD_DIR` | `/var/lib/business-system/uploads` | Private document folder. Must be outside the project folder and backed up |
| `COOKIE_SECURE` | `true` | Required on HTTPS |
| `FRAME_ANCESTORS` | (leave empty) | Must stay empty on a live site, so nobody can show it inside another website. Only set for the Arena Code preview (README section 3a) |

## Steps for a VPS (Linux)

1. Install Node.js 22 and create a database user with a strong password.
2. Copy the project (from the ZIP or from your repository) to the server, for example `/srv/business-system`.
3. Create the environment file with the settings above.
4. Run:
   ```
   npm ci
   npx drizzle-kit push
   npm run build
   ```
5. Run the app with a process manager such as **pm2** so it restarts after a reboot:
   ```
   pm2 start "npm run start" --name business-system
   pm2 save
   ```
6. Put **Nginx** (or Caddy) in front of it to provide HTTPS and forward port 443 to the app on port 3000. In the Nginx server block set `client_max_body_size 12m;`, otherwise document uploads fail. README.md section 6 has a complete example.
7. Test: sign in, create a test record, log out, and check the audit log.

## Updating a live system

1. Take a database backup and a copy of the `UPLOAD_DIR` folder.
2. Copy the new code to the server (keep `.env` and the upload folder).
3. Run `npm ci`, `npx drizzle-kit push`, `npm run build`, then restart the app (`pm2 restart business-system`).
4. Test the main pages, then tell staff that the update is complete.

Updates never delete data. If `drizzle-kit push` asks to remove a column or table, **stop and ask the developer** before saying yes.

## Health check

The app answers `GET /api/health` with `{"ok":true}` when the database is reachable. Use it for uptime monitoring.

## Things to avoid

- Do not expose the PostgreSQL port to the internet.
- Do not put the `.env` file in GitHub or in a shared folder.
- Do not run the app without HTTPS on the open internet.
- Do not keep the upload folder inside a public web folder.

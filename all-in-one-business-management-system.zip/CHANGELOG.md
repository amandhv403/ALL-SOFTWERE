# Changelog

All notable changes to this project are listed here, newest first.

## 0.1.2 — Arena Code preview fix

### Fixed
- The application showed "refused to connect" inside the Arena Code preview. Cause: every page sent `X-Frame-Options: DENY`, which stops any other website from showing it. The setting is now `FRAME_ANCESTORS`. Empty (the default, and what a live site should use) keeps the strict rule. When it lists the Arena addresses, the application sends a `Content-Security-Policy: frame-ancestors` list instead, and only those websites may show it.
- Inside the preview window the sign-in cookie now uses `SameSite=None; Secure; Partitioned`, so people stay signed in there. Live sites keep `SameSite=Lax`.
- Sign-out now overwrites the sign-in cookie with an expired copy that has the same settings, so the browser removes it in both modes (before, the removal used different settings).
- The ZIP file is no longer stored inside the Git repository (`*.zip` is ignored).

### Added
- `FRAME_ANCESTORS` setting, documented in README section 3a, `.env.example` and DEPLOYMENT_GUIDE.md.
- Build check: an invalid `FRAME_ANCESTORS` value stops the build with a clear message.
- End-to-end test: checks the framing headers for the chosen mode, the sign-in cookie settings, sign-out clearing the cookie, and a real before-and-after count for "mark all notifications as read" (the old check always passed).

## 0.1.1 — Full code review and fixes

### Fixed
- Passport numbers are masked (last 4 characters only) for people without document permission, on the customer profile and in the customer CSV export. Editing a customer no longer erases a stored passport number for people who cannot see it.
- Company logos are visible to anyone with access to the company, so printed invoices and receipts show the logo for all authorised staff.
- Company deletion is blocked by the database while a company has records (was cascade delete).
- All six lint errors fixed (variable naming, state changes during rendering, impure date call). Lint now reports 0 errors and 0 warnings.
- CSV export type check uses an own-property check.

### Added
- README.md: full deployment guide (local, Linux server with pm2 and Nginx, AI-agent instructions, checklist, troubleshooting).
- REVIEW_REPORT.md: the two review rounds and their results.
- Smoke test checks for passport masking (187 checks in total).

### Verified
- Type check, lint, production build and route generation pass.
- End-to-end test passes 187 of 187 on a fresh database, in two separate runs.

## 0.1.0 — First working release (foundation and core business modules)

### Added
- Owner setup page (first visit), sign-in, sign-out, password change, profile page, account lockout after 5 failed attempts.
- Companies: create, edit profile, numbering prefixes, working hours, logo upload, module switches, activate and deactivate.
- One-click creation of the owner's 11 business workspaces.
- Branches and departments with open and close.
- Team and access: assign a person to a company with a role, branch and department; extra and removed permissions per person.
- 15 built-in company roles and 2 top-level roles (Owner, Group Administrator). Custom roles with a permission grid.
- Users and logins page: create accounts with temporary passwords, reset passwords, switch accounts on or off, change top-level roles.
- Owner dashboard with a company comparison table, and a company dashboard with lead pipeline, follow-ups, receipts and recent activity.
- CRM: leads (duplicate check, assignment, status changes with reasons, timeline, notes), lead conversion to customers, customer profiles with edit, follow-ups board, sales pipeline.
- Sales: targets by company, branch, department or person with achievement and previous period; marketing campaigns with spend, leads, cost per lead, revenue and return.
- Visa files: opening with default checklist, status changes with history, checklist with received and verified states, documents, appointment and decision dates, edit details.
- Accounting: quotations and invoices (up to five items, tax, discount, company numbering), quotation status and conversion, cancellation with reason, money receipts (full, partial and advance payments), applying advances, refunds with approval, receipt cancellation, printable receipts with reprint count and amount in words, expenses with approval and receipt attachment, cash and bank accounts, transfers, ledgers.
- Printable A4 invoices and quotations with company logo and footer.
- HR: employee records (salary protected), daily attendance sheet with late and early calculation, leave requests with approval and overlap check.
- Office tasks board, in-app notifications, audit log viewer.
- Reports: collections by method and month, aging of unpaid invoices, expenses by category, basic cash-basis income and expense view, leads by source, visa files and processing time, attendance and leave summary, cash position.
- CSV exports (leads, customers, invoices, receipts, expenses, visa files, employees without salary, attendance), each recorded in the audit log.
- Protected file viewer for uploaded documents.
- Documentation set: README, installation, database setup, user, admin, deployment, backup and restore, architecture, schema, security notes, development status, testing report.

### Changed
- Starter template replaced with the business system.
- Database connection string moved from code to the `.env` file (`drizzle.config.ts`).

### Not yet included
See DEVELOPMENT_STATUS.md for the full list.

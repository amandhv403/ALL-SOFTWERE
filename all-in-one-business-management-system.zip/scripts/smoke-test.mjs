// End-to-end smoke test for the running application.
// It talks to the app over HTTP, exactly like a browser does (server actions are called with the same
// encoding the React forms use), and checks the database directly with psql.
//
// Use it on a FRESH, EMPTY database after `npm run start`:
//   node scripts/smoke-test.mjs http://localhost:3000
//
// It creates an owner account, a test staff account and sample records. Do not run it on live data.
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";

const BASE = process.argv[2] ?? "http://localhost:3000";
const envText = readFileSync(".env", "utf8");
const DB_URL = (envText.match(/^DATABASE_URL=(.*)$/m)?.[1] ?? process.env.DATABASE_URL ?? "").trim();
// FRAME_ANCESTORS from .env (empty on a live site). The test checks that the headers match this setting.
const FRAME_ANCESTORS = (envText.match(/^FRAME_ANCESTORS=(.*)$/m)?.[1] ?? "").trim().replace(/^"|"$/g, "");
const manifest = JSON.parse(readFileSync(".next/server/server-reference-manifest.json", "utf8"));

// Map each exported server action name to its ID and to a page that uses it.
function pathFromWorkers(workers) {
  const key = Object.keys(workers)[0] ?? "app/page";
  const segments = key
    .replace(/^app\//, "")
    .replace(/\/(page|route)$/, "")
    .split("/")
    .filter((s) => !(s.startsWith("(") && s.endsWith(")")))
    .map((s) => (s.startsWith("[") ? "1" : s));
  return "/" + segments.join("/");
}
const ACTIONS = {};
for (const [id, entry] of Object.entries(manifest.node)) {
  if (entry.exportedName && !ACTIONS[entry.exportedName]) {
    ACTIONS[entry.exportedName] = { id, path: pathFromWorkers(entry.workers) };
  }
}

let failures = 0;
let passes = 0;
function check(name, condition, detail = "") {
  if (condition) {
    passes += 1;
    console.log(`PASS  ${name}`);
  } else {
    failures += 1;
    console.log(`FAIL  ${name}  ${detail}`);
  }
}

function sql(query) {
  const out = execFileSync("psql", [DB_URL, "-X", "-A", "-t", "-F", "|", "-c", query], { encoding: "utf8" });
  return out.trim() === "" ? [] : out.trim().split("\n").map((line) => line.split("|"));
}
const one = (query) => sql(query)[0]?.[0] ?? null;
const today = new Date().toISOString().slice(0, 10);
const firstOfMonth = `${today.slice(0, 8)}01`;

let session = null;
let lastSetCookies = [];
async function http(method, pathname, { headers = {}, body } = {}) {
  const res = await fetch(BASE + pathname, {
    method,
    headers: { ...(session ? { cookie: `bms_session=${session}` } : {}), ...headers },
    body,
    redirect: "manual",
  });
  lastSetCookies = res.headers.getSetCookie();
  for (const cookie of lastSetCookies) {
    const match = cookie.match(/^bms_session=([^;]*)/);
    if (match) session = match[1] || null;
  }
  return res;
}

// kind: "state" = form used with useActionState (args: prev, formData); "plain" = (formData); "none" = no arguments.
async function act(name, fields = {}, kind = "state") {
  const meta = ACTIONS[name];
  if (!meta) throw new Error(`Unknown action ${name}`);
  const headers = { "Next-Action": meta.id, Accept: "text/x-component" };
  let body;
  if (kind === "none") {
    body = "[]";
    headers["Content-Type"] = "text/plain;charset=UTF-8";
  } else {
    // React sends the argument list last, after the form fields it refers to.
    body = new FormData();
    for (const [key, value] of Object.entries(fields)) body.append(`_1_${key}`, value);
    body.append("0", JSON.stringify(kind === "state" ? [null, "$K1"] : ["$K1"]));
  }
  const res = await http("POST", meta.path, { headers, body });
  const text = await res.text();
  return { status: res.status, location: res.headers.get("x-action-redirect") ?? res.headers.get("location") ?? "", text };
}

const P = "plain";
const S = "state";
const N = "none";

async function getPage(pathname, expected = 200) {
  const res = await http("GET", pathname);
  const body = await res.text();
  check(`GET ${pathname} -> ${expected}`, res.status === expected, `got ${res.status} ${res.headers.get("location") ?? ""}`);
  return { status: res.status, body, location: res.headers.get("location") ?? "" };
}

async function run() {
  console.log(`Smoke test against ${BASE}\n`);

  // ---------- 1. First-time setup ----------
  const setupPage = await getPage("/setup");
  check("setup page shows the owner form", setupPage.body.includes("Create owner account"));
  // ---------- 0. Framing rules (must match FRAME_ANCESTORS in .env) ----------
  const framingRes = await http("GET", "/login");
  const xFrame = framingRes.headers.get("x-frame-options");
  const csp = framingRes.headers.get("content-security-policy") ?? "";
  if (FRAME_ANCESTORS) {
    check("preview mode: X-Frame-Options header is removed", xFrame === null, `got ${xFrame}`);
    check("preview mode: frame-ancestors lists every allowed site", FRAME_ANCESTORS.split(/\s+/).every((origin) => csp.includes(origin)), csp);
  } else {
    check("live mode: X-Frame-Options is DENY", xFrame === "DENY", `got ${xFrame}`);
    check("live mode: frame-ancestors is 'none'", csp.includes("frame-ancestors 'none'"), csp);
  }
  const owner = { email: "owner@test.local", password: "Owner-pass-123" };
  let r = await act("createOwnerAccount", { fullName: "Test Owner", email: owner.email, password: owner.password, confirmPassword: owner.password });
  check("owner account created and signed in", r.location.includes("/dashboard") && session !== null, `status ${r.status} location ${r.location} body ${r.text.slice(0, 200)}`);
  const creationCookie = lastSetCookies.find((c) => c.startsWith("bms_session=")) ?? "";
  if (FRAME_ANCESTORS) {
    check("preview mode: sign-in cookie is SameSite=None; Secure; Partitioned", /SameSite=None/i.test(creationCookie) && /;\s*Secure/i.test(creationCookie) && /Partitioned/i.test(creationCookie), creationCookie);
  } else {
    check("live mode: sign-in cookie is HttpOnly and SameSite=Lax", /SameSite=Lax/i.test(creationCookie) && /HttpOnly/i.test(creationCookie), creationCookie);
  }
  const ownerSession = session;
  check("owner exists in database", one(`select count(*) from users where global_role='owner'`) === "1");
  check("system roles were created", Number(one(`select count(*) from roles where is_system = true`)) >= 15);

  // ---------- 2. Owner dashboard and admin pages ----------
  for (const p of ["/dashboard", "/companies", "/notifications", "/account", "/admin/users", "/admin/roles", "/admin/audit"]) {
    await getPage(p);
  }

  // ---------- 3. Companies ----------
  r = await act("seedPortfolioCompanies", {}, N);
  check("portfolio companies added", r.location.includes("/companies?notice"), `location ${r.location} status ${r.status}`);
  check("11 portfolio companies exist", one(`select count(*) from companies`) === "11");
  const companyId = Number(one(`select id from companies where name='Dhaka Holiday'`));
  const otherCompanyId = Number(one(`select id from companies where name='Little Wonder Co.'`));
  check("found Dhaka Holiday", companyId > 0);

  r = await act("createCompany", { name: "Test Consulting Ltd", businessType: "general", phone: "01700000000" });
  check("create company form works", r.location.includes("/settings") || r.location.includes("/c/"), `${r.location} ${r.text.slice(0, 200)}`);
  const testCompanyId = Number(one(`select id from companies where name='Test Consulting Ltd'`));
  const C = companyId;

  r = await act("updateCompanyProfile", {
    companyId: C, name: "Dhaka Holiday", businessType: "travel_agency", brandColor: "#0f766e",
    invoicePrefix: "DH-INV", quotationPrefix: "DH-QTN", receiptPrefix: "DH-RCT", visaPrefix: "DH-VISA",
    shiftStart: "09:00", shiftEnd: "18:00", graceMinutes: "10", financialYearStartMonth: "7", address: "Gulshan, Dhaka",
  });
  check("company profile saved", r.text.includes('"ok":true'), r.text.slice(0, 200));

  const moduleFields = { companyId: C };
  for (const m of ["crm", "sales", "marketing", "visa", "accounting", "hr", "tasks", "reports", "documents"]) moduleFields[`module_${m}`] = "on";
  r = await act("updateCompanyModules", moduleFields);
  check("modules saved", r.text.includes('"ok":true'), r.text.slice(0, 200));

  r = await act("createBranch", { companyId: C, name: "Dhaka - Gulshan", address: "Gulshan 2", phone: "" });
  check("branch created", r.text.includes('"ok":true'), r.text.slice(0, 200));
  r = await act("createDepartment", { companyId: C, name: "Visa processing", description: "Visa files" });
  check("department created", r.text.includes('"ok":true'), r.text.slice(0, 200));
  const branchId = one(`select id from branches where company_id=${C} limit 1`);
  check("branch stored", Boolean(branchId));

  for (const p of [`/c/${C}`, `/c/${C}/settings`, `/c/${C}/settings/structure`, `/c/${C}/team`]) await getPage(p);

  // ---------- 4. CRM: leads and customers ----------
  r = await act("createLead", {
    companyId: C, fullName: "Nusrat Jahan", phone: "01822222222", email: "nusrat@example.com", city: "Dhaka",
    leadSource: "facebook", interestedService: "Umrah package", expectedValue: "50000", notes: "Asked about November",
  });
  check("lead created", r.location.includes("/crm/leads/"), `${r.location} ${r.text.slice(0, 200)}`);
  const leadId = one(`select id from leads where company_id=${C} and full_name='Nusrat Jahan'`);
  check("lead stored with code LD-", (one(`select code from leads where id=${leadId}`) ?? "").startsWith("LD-"));

  r = await act("createLead", { companyId: C, fullName: "Duplicate Person", phone: "01822222222", leadSource: "walk_in", expectedValue: "0" });
  check("duplicate lead is blocked", r.text.includes("similar record already exists"), r.text.slice(0, 200));

  const lead2 = one(`select id from leads where company_id=${C} and full_name='Nusrat Jahan'`);
  r = await act("createCustomer", {
    companyId: C, fullName: "Rahim Uddin", phone: "01711111111", email: "rahim@example.com", category: "individual",
    country: "Bangladesh", nationality: "Bangladeshi", passportNumber: "a1234567", passportExpiry: "2031-06-30",
    dateOfBirth: "1990-04-12", interestedService: "Honeymoon package", assignedUserId: "", branchId: "",
  });
  check("customer created", r.location.includes("/crm/customers/"), `${r.location} ${r.text.slice(0, 200)}`);
  const customerId = one(`select id from customers where company_id=${C} and full_name='Rahim Uddin'`);
  check("customer code CUS-", (one(`select code from customers where id=${customerId}`) ?? "").startsWith("CUS-"));
  check("passport number stored in upper case", one(`select passport_number from customers where id=${customerId}`) === "A1234567");
  const ownerProfile = await getPage(`/c/${C}/crm/customers/${customerId}`);
  check("owner sees the full passport number", ownerProfile.body.includes("A1234567"));

  r = await act("createCustomer", { companyId: C, fullName: "Rahim Duplicate", phone: "+8801711111111", category: "individual" });
  check("duplicate customer detected (+880 form)", r.text.includes("similar record already exists"), r.text.slice(0, 200));

  r = await act("setLeadStatus", { companyId: C, leadId: lead2, status: "contacted", reason: "", note: "Called" }, P);
  check("lead status changed", r.location.includes("notice"), r.location);
  r = await act("setLeadStatus", { companyId: C, leadId: lead2, status: "lost", reason: "", note: "" }, P);
  check("lost lead needs a reason", r.location.includes("error"), r.location);
  r = await act("assignLead", { companyId: C, leadId: lead2, assignedUserId: "" }, P);
  check("lead assignment action runs", r.location.includes("/crm/leads/"), r.location);

  r = await act("scheduleFollowUp", { companyId: C, customerId, title: "Send visa checklist", notes: "", dueAt: "2026-12-01T10:00", assignedUserId: "" });
  check("follow-up scheduled", r.text.includes('"ok":true'), r.text.slice(0, 200));
  r = await act("addActivity", { companyId: C, customerId, type: "call", summary: "Discussed Umrah dates", details: "" }, P);
  check("timeline note added", r.location.includes("notice"), r.location);

  r = await act("convertLead", { companyId: C, leadId }, P);
  check("lead converted to customer", r.location.includes("/crm/customers/"), r.location);
  check("converted lead linked", one(`select status from leads where id=${leadId}`) === "converted");

  for (const p of [`/c/${C}/crm/leads`, `/c/${C}/crm/leads/${lead2}`, `/c/${C}/crm/customers`, `/c/${C}/crm/customers/${customerId}`, `/c/${C}/crm/followups?scope=all`, `/c/${C}/sales/pipeline`]) await getPage(p);

  // ---------- 5. Accounting ----------
  r = await act("createCashAccount", { companyId: C, name: "bKash merchant", accountType: "mobile_wallet", providerName: "bKash", accountNumberMasked: "017****111", openingBalance: "1000" });
  check("cash account created", r.text.includes('"ok":true'), r.text.slice(0, 200));
  r = await act("createCashAccount", { companyId: C, name: "Head office cash", accountType: "cash", providerName: "", accountNumberMasked: "", openingBalance: "0" });
  check("second cash account created", r.text.includes('"ok":true'), r.text.slice(0, 200));
  const bkashId = one(`select id from cash_accounts where company_id=${C} and name='bKash merchant'`);
  const cashId = one(`select id from cash_accounts where company_id=${C} and name='Head office cash'`);

  r = await act("transferFunds", { companyId: C, fromAccountId: bkashId, toAccountId: cashId, amount: "500", transferDate: today, reference: "Float" });
  check("transfer recorded", r.text.includes('"ok":true'), r.text.slice(0, 200));
  r = await act("transferFunds", { companyId: C, fromAccountId: cashId, toAccountId: bkashId, amount: "999999", transferDate: today, reference: "" });
  check("transfer larger than balance is refused", r.text.includes("only has"), r.text.slice(0, 200));

  const categoryId = one(`select id from expense_categories where company_id=${C} order by name limit 1`);
  r = await act("createDocument", {
    companyId: C, docType: "invoice", customerId, issueDate: today, dueDate: "", serviceReference: "UMRAH-001",
    visaApplicationId: "", item1_service: "", item1_description: "Umrah package - 2 persons", item1_qty: "2", item1_price: "15000",
    item1_tax: "15", item2_description: "Visa fee", item2_qty: "1", item2_price: "500", item2_tax: "0", discount: "0", notes: "", terms: "Pay on time",
  });
  check("invoice created", r.location.includes("/accounting/invoices/"), `${r.location} ${r.text.slice(0, 200)}`);
  const invoiceId = one(`select id from invoices where company_id=${C} and doc_type='invoice' order by id desc limit 1`);
  check("invoice total is 34,000 + 15% tax on the package (34,500 + 500)", one(`select total from invoices where id=${invoiceId}`) === "35000.00" || one(`select total from invoices where id=${invoiceId}`) === "34500.00", `total ${one(`select total from invoices where id=${invoiceId}`)}`);
  check("invoice number uses company prefix", (one(`select number from invoices where id=${invoiceId}`) ?? "").startsWith("DH-INV-"));

  r = await act("recordReceipt", {
    companyId: C, customerId, receiptDate: today, amount: "20000", paymentMethod: "bkash", transactionRef: "BKX-TEST-1",
    accountId: bkashId, invoiceId, applyAmount: "", formToken: "token-aaaaaaaa-1", receivedByName: "Test Owner", notes: "",
  });
  check("receipt recorded against invoice", r.location.includes("/accounting/receipts/"), `${r.location} ${r.text.slice(0, 200)}`);
  const receiptId = one(`select id from receipts where company_id=${C} order by id desc limit 1`);
  check("receipt number uses company prefix", (one(`select number from receipts where id=${receiptId}`) ?? "").startsWith("DH-RCT-"));
  check("invoice shows partial payment", one(`select status from invoices where id=${invoiceId}`) === "partially_paid");

  r = await act("recordReceipt", { companyId: C, customerId, receiptDate: today, amount: "20000", paymentMethod: "bkash", transactionRef: "", accountId: "", invoiceId: "", applyAmount: "", formToken: "token-aaaaaaaa-1", receivedByName: "", notes: "" });
  check("double submission of the same form is ignored", r.location.includes("already") || r.location.includes("notice"), r.location);
  check("no duplicate receipt was created", one(`select count(*) from receipts where company_id=${C} and form_token='token-aaaaaaaa-1'`) === "1");

  r = await act("recordReceipt", { companyId: C, customerId, receiptDate: today, amount: "5000", paymentMethod: "cash", transactionRef: "", accountId: cashId, invoiceId: "", applyAmount: "", formToken: "token-bbbbbbbb-2", receivedByName: "", notes: "Advance" });
  check("advance payment recorded", r.location.includes("/accounting/receipts/"), r.location);
  const advanceReceipt = one(`select id from receipts where company_id=${C} and form_token='token-bbbbbbbb-2'`);

  r = await act("recordReceipt", { companyId: C, customerId, receiptDate: today, amount: "20000", paymentMethod: "cash", transactionRef: "BKX-TEST-1", accountId: "", invoiceId: "", applyAmount: "", formToken: "token-cccccccc-3", receivedByName: "", notes: "" });
  check("duplicate transaction ID is refused", r.text.includes("already recorded"), r.text.slice(0, 200));

  r = await act("applyAdvance", { companyId: C, invoiceId, receiptId: advanceReceipt, amount: "5000" });
  check("advance applied to invoice", r.text.includes('"ok":true'), r.text.slice(0, 200));
  // Invoice total is 35,000 (2 x 15,000 + 15% tax, plus a 500 visa fee). Receipt 20,000 + advance 5,000 leaves 10,000.
  check("invoice due reduced to 10,000 after the advance", one(`select due_amount from invoices where id=${invoiceId}`) === "10000.00", `due ${one(`select due_amount from invoices where id=${invoiceId}`)}`);

  r = await act("cancelDocument", { companyId: C, invoiceId, reason: "Testing cancellation with payments" }, P);
  check("cannot cancel an invoice with payments", r.location.includes("error"), r.location);

  r = await act("cancelReceipt", { companyId: C, receiptId, reason: "Paid twice by mistake" }, P);
  check("receipt cancelled with reason", r.location.includes("notice"), r.location);
  check("cancelled receipt keeps its number", (one(`select number from receipts where id=${receiptId}`) ?? "").startsWith("DH-RCT-"));
  // Cancelling the 20,000 receipt puts that money back on the invoice: 35,000 - 5,000 advance = 30,000 due.
  check("invoice due recalculated after cancellation (30,000)", one(`select due_amount from invoices where id=${invoiceId}`) === "30000.00", `due ${one(`select due_amount from invoices where id=${invoiceId}`)}`);

  r = await act("createDocument", { companyId: C, docType: "quotation", customerId, issueDate: today, dueDate: "", serviceReference: "", visaApplicationId: "", item1_service: "", item1_description: "Honeymoon package", item1_qty: "1", item1_price: "80000", item1_tax: "0", discount: "5000", notes: "", terms: "" });
  check("quotation created with discount", r.location.includes("/accounting/invoices/"), `${r.location} ${r.text.slice(0, 200)}`);
  const quoteId = one(`select id from invoices where company_id=${C} and doc_type='quotation' order by id desc limit 1`);
  check("quotation number uses quotation prefix", (one(`select number from invoices where id=${quoteId}`) ?? "").startsWith("DH-QTN-"));
  r = await act("setQuotationStatus", { companyId: C, invoiceId: quoteId, status: "accepted" }, P);
  check("quotation accepted", r.location.includes("notice"), r.location);
  r = await act("convertQuotation", { companyId: C, invoiceId: quoteId }, P);
  check("quotation converted into invoice", r.location.includes("/accounting/invoices/") && r.location.includes("notice"), r.location);

  r = await act("createExpense", {
    companyId: C, expenseDate: today, categoryId, amount: "1200", description: "Office electricity bill", paymentMethod: "bank_transfer", accountId: "", payeeName: "DESCO", reference: "BILL-44",
  });
  check("expense recorded and approved by owner", r.location.includes("approved"), r.location);
  check("expense status is approved", one(`select status from expenses where company_id=${C} order by id desc limit 1`) === "approved");

  for (const p of [
    `/c/${C}/accounting/invoices`, `/c/${C}/accounting/invoices?type=quotation`, `/c/${C}/accounting/invoices/${invoiceId}`,
    `/c/${C}/accounting/invoices/${invoiceId}/print`, `/c/${C}/accounting/invoices/new`, `/c/${C}/accounting/invoices/new?visaId=1`,
    `/c/${C}/accounting/receipts`, `/c/${C}/accounting/receipts/new?customerId=${customerId}`, `/c/${C}/accounting/receipts/${receiptId}`,
    `/c/${C}/accounting/receipts/${receiptId}/print?copy=2&size=compact`, `/c/${C}/accounting/receipts/${advanceReceipt}/print`,
    `/c/${C}/accounting/expenses`, `/c/${C}/accounting/cash-bank?account=${bkashId}`,
  ]) await getPage(p);

  // ---------- 6. Visa ----------
  r = await act("createVisaApplication", {
    companyId: C, customerId, destinationCountry: "Malaysia", visaCategory: "Tourist / visit", travelPurpose: "Family holiday",
    embassy: "Malaysian High Commission", applicationDate: today, submissionDate: "", appointmentAt: "", travelDate: "2026-12-20",
    returnDate: "2026-12-30", status: "new", assignedUserId: "", serviceFee: "5000", notes: "Urgent",
  });
  check("visa file opened", r.location.includes("/visa/applications/"), `${r.location} ${r.text.slice(0, 200)}`);
  const visaId = one(`select id from visa_applications where company_id=${C} order by id desc limit 1`);
  check("visa file code uses company prefix", (one(`select code from visa_applications where id=${visaId}`) ?? "").startsWith("DH-VISA-"));
  check("default checklist created", Number(one(`select count(*) from visa_checklist_items where visa_application_id=${visaId}`)) >= 10);

  r = await act("changeVisaStatus", { companyId: C, applicationId: visaId, status: "submitted", note: "Sent to embassy", submissionDate: today, appointmentAt: "", approvalDate: "", validFrom: "", validUntil: "", refusalReason: "" });
  check("visa status changed to submitted", r.text.includes('"ok":true'), r.text.slice(0, 200));
  r = await act("changeVisaStatus", { companyId: C, applicationId: visaId, status: "refused", note: "", submissionDate: "", appointmentAt: "", approvalDate: "", validFrom: "", validUntil: "", refusalReason: "" });
  check("refusal needs a reason", r.text.includes("Write the reason"), r.text.slice(0, 200));
  r = await act("changeVisaStatus", { companyId: C, applicationId: visaId, status: "approved", note: "Visa granted", submissionDate: "", appointmentAt: "", approvalDate: today, validFrom: today, validUntil: "2027-01-31", refusalReason: "" });
  check("visa approved with validity dates", r.text.includes('"ok":true'), r.text.slice(0, 200));
  check("visa status history recorded", Number(one(`select count(*) from visa_status_history where visa_application_id=${visaId}`)) >= 3);
  const checklistItem = one(`select id from visa_checklist_items where visa_application_id=${visaId} order by sort_order limit 1`);
  r = await act("setChecklistItem", { companyId: C, applicationId: visaId, itemId: checklistItem, status: "verified" }, P);
  check("checklist item verified", r.location.includes("notice"), r.location);

  for (const p of [`/c/${C}/visa/applications`, `/c/${C}/visa/applications/${visaId}`, `/c/${C}/accounting/invoices/new?customerId=${customerId}&visaId=${visaId}`]) await getPage(p);

  // ---------- 7. Documents (private files) ----------
  const pdfBlob = new Blob(["%PDF-1.4\n% smoke test document\n"], { type: "application/pdf" });
  const upload = new FormData();
  for (const [k, v] of Object.entries({ companyId: String(C), module: "crm", category: "passport", title: "Passport bio page", customerId: String(customerId) })) upload.append(`_1_${k}`, v);
  upload.append("_1_file", pdfBlob, "passport.pdf");
  upload.append("0", JSON.stringify([null, "$K1"]));
  const uploadRes = await http("POST", ACTIONS.uploadDocument.path, { headers: { "Next-Action": ACTIONS.uploadDocument.id, Accept: "text/x-component" }, body: upload });
  const uploadText = await uploadRes.text();
  check("passport uploaded", uploadText.includes("uploaded securely"), uploadText.slice(0, 200));
  const docId = one(`select id from documents order by id desc limit 1`);
  const fileRes = await http("GET", `/api/files/${docId}`);
  check("uploaded file opens for an authorised user", fileRes.status === 200 && (fileRes.headers.get("content-type") ?? "").includes("application/pdf"), `status ${fileRes.status}`);
  const downloadRes = await http("GET", `/api/files/${docId}?download=1`);
  check("download is offered as an attachment", (downloadRes.headers.get("content-disposition") ?? "").startsWith("attachment"));
  const anonymous = await fetch(`${BASE}/api/files/${docId}`, { redirect: "manual" });
  check("file is refused without signing in", anonymous.status === 401, `status ${anonymous.status}`);
  check("file access is logged", Number(one(`select count(*) from audit_logs where action like 'document.%'`)) >= 1);

  // ---------- 8. HR, leave, tasks, targets, campaigns ----------
  r = await act("createEmployee", {
    companyId: C, fullName: "Karim Hossain", phone: "01755555555", email: "karim@example.com", designation: "Visa Officer", departmentId: "",
    branchId: branchId ?? "", joinDate: "2025-07-01", employmentStatus: "active", reportingManagerId: "", userId: "", basicSalary: "35000",
    nationalId: "1234567890", address: "Mirpur", dateOfBirth: "", notes: "",
  });
  check("employee created", r.location.includes("/hr/employees/"), `${r.location} ${r.text.slice(0, 200)}`);
  const employeeId = one(`select id from employees where company_id=${C} and full_name='Karim Hossain'`);
  check("employee code EMP-", (one(`select code from employees where id=${employeeId}`) ?? "").startsWith("EMP-"));
  check("salary stored for authorised user", one(`select basic_salary from employees where id=${employeeId}`) === "35000.00");

  r = await act("markAttendance", { companyId: C, attendanceDate: today, employeeIds: String(employeeId), [`status_${employeeId}`]: "present", [`in_${employeeId}`]: "09:25", [`out_${employeeId}`]: "17:50", [`note_${employeeId}`]: "" }, P);
  check("attendance saved", r.location.includes("notice"), r.location);
  check("late minutes calculated (15 after 09:10 grace)", one(`select late_minutes from attendance where employee_id=${employeeId} and attendance_date='${today}'`) === "15");
  check("late arrival marks status as late", one(`select status from attendance where employee_id=${employeeId} and attendance_date='${today}'`) === "late");

  r = await act("requestLeave", { companyId: C, employeeId, leaveType: "annual", startDate: "2026-02-01", endDate: "2026-02-03", reason: "Family event" });
  check("leave requested", r.text.includes('"ok":true'), r.text.slice(0, 200));
  const leaveId = one(`select id from leave_requests where employee_id=${employeeId} order by id desc limit 1`);
  check("leave days counted (3)", one(`select days from leave_requests where id=${leaveId}`) === "3");
  r = await act("requestLeave", { companyId: C, employeeId, leaveType: "sick", startDate: "2026-02-02", endDate: "2026-02-02", reason: "" });
  check("overlapping leave is refused", r.text.includes("overlaps"), r.text.slice(0, 200));
  r = await act("decideLeave", { companyId: C, leaveId, decision: "approve", note: "" }, P);
  check("leave approved", r.location.includes("notice"), r.location);

  r = await act("createTask", { companyId: C, title: "Collect passport copies", description: "For the Malaysia files", priority: "high", dueDate: "2026-01-01", assignedUserId: "" });
  check("task created", r.text.includes('"ok":true'), r.text.slice(0, 200));
  const taskId = one(`select id from tasks where company_id=${C} order by id desc limit 1`);
  r = await act("updateTaskStatus", { companyId: C, taskId, status: "done" }, P);
  check("task completed", r.location.includes("notice"), r.location);

  r = await act("createTarget", { companyId: C, label: "This month revenue", scopeChoice: "company", metric: "revenue", periodType: "monthly", periodStart: firstOfMonth, targetValue: "500000" });
  check("target created", r.text.includes('"ok":true'), r.text.slice(0, 200));
  r = await act("createCampaign", { companyId: C, name: "Umrah Ramadan offer", channel: "facebook", status: "active", budget: "20000", startDate: today, endDate: "", ownerUserId: "", objective: "50 enquiries" });
  check("campaign created", r.text.includes('"ok":true'), r.text.slice(0, 200));

  for (const p of [`/c/${C}/hr/employees`, `/c/${C}/hr/employees/${employeeId}`, `/c/${C}/hr/attendance?date=${today}`, `/c/${C}/hr/leave`, `/c/${C}/hr/leave?status=pending`, `/c/${C}/tasks?scope=all&done=1`, `/c/${C}/sales/targets`, `/c/${C}/marketing/campaigns`, `/c/${C}/reports?from=${firstOfMonth}&to=${today}`]) await getPage(p);

  // ---------- 9. Roles, staff accounts and permissions ----------
  r = await act("createCustomRole", { name: "Senior Visa Consultant", description: "Test role", p_visa_view: "on", p_visa_create: "on", p_visa_edit: "on" });
  check("custom role created", r.text.includes('"ok":true'), r.text.slice(0, 200));
  const customRoleId = one(`select id from roles where name='Senior Visa Consultant'`);
  r = await act("deleteCustomRole", { roleId: customRoleId }, P);
  check("unused custom role deleted", r.location.includes("notice"), r.location);

  r = await act("createUserAccount", { fullName: "Staff Reader", email: "reader@test.local", phone: "", globalRole: "staff", tempPassword: "Reader-pass-123" });
  check("staff login created", r.text.includes('"ok":true'), r.text.slice(0, 200));
  const readerId = one(`select id from users where email='reader@test.local'`);
  const readOnlyRoleId = one(`select id from roles where key='read_only'`);
  r = await act("assignTeamAccess", { companyId: C, userId: readerId, roleId: readOnlyRoleId, branchId: "", departmentId: "", grants: "", revokes: "documents.view" });
  check("read-only access given to staff login", r.text.includes('"ok":true'), r.text.slice(0, 200));
  r = await act("assignTeamAccess", { companyId: C, userId: readerId, roleId: readOnlyRoleId, branchId: "", departmentId: "", grants: "accounting.explode", revokes: "" });
  check("unknown permission name is rejected", r.text.includes("not recognised") && r.text.includes("accounting.explode"), r.text.slice(0, 200));

  // Sign in as the staff login in a separate session.
  session = null;
  r = await act("login", { email: "reader@test.local", password: "Reader-pass-123" });
  check("staff login signs in and must change temporary password", r.location.includes("/account") && session !== null, `${r.location} ${r.text.slice(0, 120)}`);
  const readerSession = session;
  await getPage(`/c/${C}/accounting/invoices`);
  await getPage(`/c/${C}/hr/employees`);
  const employeesPage = await getPage(`/c/${C}/crm/customers`);
  check("staff page hides salary", !(await getPage(`/c/${C}/hr/employees`)).body.includes("35,000.00"));
  check("staff page lists customers", employeesPage.body.includes("Rahim Uddin"));
  const staffProfile = await getPage(`/c/${C}/crm/customers/${customerId}`);
  check("staff without document rights sees only the last 4 passport digits", !staffProfile.body.includes("A1234567") && staffProfile.body.includes("****4567"));
  const denied = await act("createExpense", { companyId: C, expenseDate: today, categoryId, amount: "100", description: "Should be refused", paymentMethod: "cash", accountId: "", payeeName: "", reference: "" });
  check("read-only staff cannot create expenses", denied.text.includes("do not have permission"), denied.text.slice(0, 200));
  const receiptsForm = await http("GET", `/c/${C}/accounting/receipts/new`);
  check("read-only staff is sent away from the payment form", receiptsForm.status === 307 && receiptsForm.headers.get("location")?.includes(`/c/${C}?error`), `status ${receiptsForm.status} ${receiptsForm.headers.get("location")}`);
  const otherCompany = await http("GET", `/c/${otherCompanyId}`);
  check("staff cannot open a company they are not assigned to", otherCompany.status === 307 && (otherCompany.headers.get("location") ?? "").includes("/dashboard?error"), `status ${otherCompany.status}`);
  const adminPage = await http("GET", "/admin/users");
  check("staff cannot open the admin users page", adminPage.status === 307, `status ${adminPage.status}`);
  const exportDenied = await http("GET", `/api/export?companyId=${C}&type=invoices`);
  check("read-only staff cannot export", exportDenied.status === 403, `status ${exportDenied.status}`);
  const sessionSaved = session;
  session = readerSession;
  check("staff is recognised after sign-in", (await http("GET", "/dashboard")).status === 200);
  session = sessionSaved;

  // Owner returns and tests the rest.
  session = ownerSession;
  check("owner session still valid", (await http("GET", "/dashboard")).status === 200);

  // ---------- 10. Exports and reports ----------
  for (const type of ["leads", "customers", "invoices", "receipts", "expenses", "visa", "employees", "attendance"]) {
    const res = await http("GET", `/api/export?companyId=${C}&type=${type}`);
    const body = await res.text();
    check(`CSV export: ${type}`, res.status === 200 && (res.headers.get("content-type") ?? "").includes("text/csv"), `status ${res.status}`);
    if (type === "employees") check("CSV export includes the salary column for the owner", body.split("\n")[0].includes("Basic salary"), body.split("\n")[0]);
  }
  check("exports are logged", Number(one(`select count(*) from audit_logs where action='export.csv'`)) >= 8);

  // ---------- 11. Companies, team and admin actions ----------
  r = await act("setCompanyActive", { companyId: otherCompanyId, active: "0" }, P);
  check("company deactivated", r.location.includes("notice"), r.location);
  check("company deactivation stored", one(`select is_active from companies where id=${otherCompanyId}`) === "f");
  r = await act("setCompanyActive", { companyId: otherCompanyId, active: "1" }, P);
  check("company reactivated", r.location.includes("notice"), r.location);

  r = await act("setUserActive", { userId: readerId, active: "0" }, P);
  check("staff login switched off", r.location.includes("notice"), r.location);
  check("switched-off login cannot use the old session", (await (async () => { session = readerSession; const res = await http("GET", "/dashboard"); session = ownerSession; return res; })()).status === 307);
  r = await act("setUserActive", { userId: readerId, active: "1" }, P);
  check("staff login switched on again", r.location.includes("notice"), r.location);

  r = await act("resetUserPassword", { userId: readerId, tempPassword: "Reader-pass-456" }, P);
  check("temporary password reset", r.location.includes("notice"), r.location);

  // Lockout after repeated wrong passwords.
  session = null;
  for (let i = 0; i < 5; i += 1) await act("login", { email: "reader@test.local", password: "wrong-password-1" });
  r = await act("login", { email: "reader@test.local", password: "Reader-pass-456" });
  check("account locks after 5 wrong passwords", r.text.includes("locked for 15 minutes"), r.text.slice(0, 200));
  session = ownerSession;

  r = await act("removeTeamAccess", { companyId: C, userId: readerId }, P);
  check("team access removed (history kept)", r.location.includes("notice"), r.location);

  r = await act("updateMyProfile", { fullName: "Test Owner", phone: "01700000001" });
  check("profile updated", r.text.includes('"ok":true'), r.text.slice(0, 200));

  const unreadQuery = `select count(*) from notifications n join users u on u.id = n.user_id where u.email = 'owner@test.local' and n.is_read = false`;
  const unreadBefore = one(unreadQuery);
  r = await act("markAllNotificationsRead", {}, N);
  const unreadAfter = one(unreadQuery);
  check(`notifications marked read (unread before: ${unreadBefore})`, unreadAfter === "0", `unread after: ${unreadAfter}`);

  // ---------- 12. Every main page with real data ----------
  const pages = [
    `/c/${C}`, `/c/${C}/settings`, `/c/${C}/settings/structure`, `/c/${C}/team`, `/c/${C}/crm/leads`, `/c/${C}/crm/customers`,
    `/c/${C}/crm/followups`, `/c/${C}/reports`, `/notifications`, `/account`, `/admin/users`, `/admin/roles`, `/admin/audit`,
    `/companies`, `/dashboard`,
  ];
  for (const p of pages) await getPage(p);
  for (const p of [`/c/${otherCompanyId}`, `/c/${testCompanyId}/settings`]) await getPage(p);

  await getPage(`/c/${C}/accounting/cash-bank`);
  await getPage(`/c/${C}/accounting/expenses?status=approved`);
  await getPage(`/c/${C}/crm/followups?scope=mine`);

  // ---------- 13. Sign-out removes the session ----------
  ACTIONS.logoutAction.path = "/dashboard";
  r = await act("logoutAction", {}, N);
  const clearing = lastSetCookies.find((c) => c.startsWith("bms_session=")) ?? "";
  check("sign-out clears the sign-in cookie", /expires=Thu, 01 Jan 1970/i.test(clearing), clearing || "no cookie sent");
  const afterSignOut = await http("GET", "/dashboard");
  check("after sign-out, the dashboard asks for sign-in again", afterSignOut.status === 307 && (afterSignOut.headers.get("location") ?? "").includes("/login"), `status ${afterSignOut.status}`);

  // ---------- Summary ----------
  console.log(`\n${passes} passed, ${failures} failed.`);
  if (failures > 0) process.exitCode = 1;
}

run().catch((error) => {
  console.error("Smoke test stopped with an unexpected error:", error);
  process.exitCode = 1;
});

# Database Setup Guide

The system stores everything in PostgreSQL (version 15 or newer). The connection is set in the `.env` file with one line:

`DATABASE_URL=postgresql://USER:PASSWORD@HOST:PORT/DATABASE_NAME`

## Creating the database

Using psql (the PostgreSQL command line that comes with the installer):

```
psql -U postgres -h 127.0.0.1 -p 5432
CREATE DATABASE business_system;
\q
```

Use a strong password for the `postgres` user, and do not use the default password on a live server.

## Creating the tables

Tables are created from the schema file `src/db/schema.ts`:

```
npx drizzle-kit push
```

Run this once after installation, and again after an update that changes the schema. `drizzle-kit push` only adds what is missing. It asks before anything that could remove data. Do not use the force option on a live database.

## Checking the tables

```
psql postgresql://postgres:YOUR_PASSWORD@127.0.0.1:5432/business_system -c "\dt"
```

You should see about 35 tables, including `companies`, `users`, `invoices`, `receipts`, `customers` and `audit_logs`.

## Rules the database enforces

- Each business record has a `company_id`, so data stays separated by company.
- Invoice and receipt numbers are unique per company and never reused (see `number_sequences`).
- A transaction reference (for example a bKash ID) can only be used once on an active receipt.
- A form that is submitted twice cannot create two receipts (each form carries a one-time token).
- Deleting a company is blocked by the database while it still has data. Use Deactivate instead.
- Money is stored as NUMERIC(14,2), never as floating-point numbers.

## Where the uploaded files are kept

Passports, contracts and receipts are **not** stored inside the database. They are kept in the folder set by `UPLOAD_DIR` in `.env` (default: `storage/private-uploads` inside the project). Back up that folder as well (see BACKUP_RESTORE_GUIDE.md).

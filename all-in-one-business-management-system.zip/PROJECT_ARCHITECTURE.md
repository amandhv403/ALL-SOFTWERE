# Project Architecture

## Overview

One Next.js application (App Router) serves the web pages, server actions (form handlers that run on the server) and a few API routes. PostgreSQL stores all records through Drizzle ORM. Documents are kept in a private folder on the server, not in the database.

```
Browser  ──►  Next.js server
               ├── Pages (src/app/**/page.tsx)          read data, check access, render
               ├── Server actions (src/app/actions/*)   create / change data, check access, validate
               ├── API routes (src/app/api/*)           file viewer, CSV export, health check
               └── Libraries (src/lib/*)                auth, permissions, money, numbering, ledger, storage
                        │
                        ├── PostgreSQL (src/db/schema.ts via Drizzle)
                        └── Private folder (UPLOAD_DIR) for passports and documents
```

## Folder layout

| Folder | Contents |
|---|---|
| `src/app/(app)/` | Signed-in pages. The layout checks the session and builds the menu |
| `src/app/(app)/c/[companyId]/` | Everything inside one company workspace |
| `src/app/(app)/admin/` | Owner and group administrator pages |
| `src/app/actions/` | Server actions grouped by area: auth, admin, crm, sales, visa, accounting, hr, documents |
| `src/app/api/` | `files/[id]` (protected file viewer), `export` (CSV), `health` |
| `src/components/` | Shared screens: form builder (`action-form`), app shell (menu), buttons and tables (`ui`) |
| `src/lib/` | Business rules: `permissions`, `auth`, `ledger`, `money`, `numbering`, `storage`, `audit`, `nav` |
| `src/lib/forms/` | Shared form definitions (lead and customer fields) |
| `src/db/` | Database connection and `schema.ts` (all tables) |
| `drizzle.config.ts` | Database tool settings (reads `DATABASE_URL`) |

## How a request is protected

1. **Session**: the sign-in action creates a random token, stores only its SHA-256 hash in the `sessions` table, and sends the raw token in an HTTP-only cookie. Sessions last 12 hours.
2. **Signed-in layout**: `src/app/(app)/layout.tsx` redirects anonymous visitors to the sign-in page.
3. **Company check**: `getAccess(companyId)` loads the person's role for that company and combines it with the role's permissions and their individual grants and revokes. A company that is deactivated returns no access.
4. **Module check**: a permission only counts if the module is switched on for that company (`enabledModules`).
5. **Branch check**: people with a branch assignment only see records from that branch (`branchWhere` in lists, `inBranchScope` on single records).
6. **Pages** call `requirePage(companyId, module, action)`, which redirects when access is missing.
7. **Actions** call `requireAccess(...)`, which returns a clear message when access is missing.

The menu is also filtered, but that is for convenience only. Every page and action checks again on the server.

## Key business rules in code

- **Money** (`src/lib/money.ts`): amounts are converted to whole paisa (integers) for every calculation, then stored as NUMERIC(14,2).
- **Numbering** (`src/lib/numbering.ts`): an atomic counter per company and document type (`number_sequences`). It only moves forward.
- **Invoice balances** (`src/lib/ledger.ts`): `recomputeInvoiceTx` recalculates paid, due and status from the allocations of active receipts, inside the same transaction. The invoice row is locked (`SELECT … FOR UPDATE`) first, so two payments cannot overpay the same invoice.
- **Advances and refunds**: a customer's advance is the active payments not yet applied, minus refunds (`customerAdvanceCents`).
- **Cash and bank balances**: opening balance + active receipts − refunds − approved expenses ± transfers (`accountBalances`). Pending expenses do not reduce balances.
- **Duplicate protection**: a receipt form token is unique per company, and a transaction ID is unique among active receipts. Duplicate phone or email triggers a warning on leads and customers.
- **Audit**: important actions call `logAudit` (who, what, when). The audit table has no edit or delete path in the app.

## Technology choices

| Need | Choice | Why |
|---|---|---|
| Web framework | Next.js 16 with the App Router | One codebase for pages, forms and secure server logic |
| Database | PostgreSQL with Drizzle ORM | Reliable transactions and row locks for money |
| Input checks | Zod | Same rules on the server for every form |
| Passwords | Node scrypt (built in) | No extra service needed; slow by design |
| Styling | Tailwind CSS 4 | Consistent, responsive layouts for phones and desktops |

## Extending the system

- **New module**: add its key to `MODULE_KEYS` (and to `TOGGLEABLE_MODULE_KEYS` if it can be switched off), add a menu item to `src/lib/nav.ts`, create the pages under `c/[companyId]/…`, and write the server actions with `requireAccess`.
- **New table**: add it to `src/db/schema.ts`, then run `npx drizzle-kit push`. Always include a `company_id` column.
- **New role**: add it to `SYSTEM_ROLE_TEMPLATES` in `src/lib/permissions.ts` for a built-in role, or create a custom role in the app.

# User Guide (for everyday staff)

This guide explains the system in simple English. You need only a web browser: Chrome, Edge or Safari, on a computer, tablet or phone.

## Signing in

1. Open the address your administrator gave you (for example `https://your-business-system.example`).
2. Type your email address and password, then click **Sign in**.
3. If you were given a temporary password, you will be asked to choose your own password straight away.
4. After 5 wrong attempts your account is locked for 15 minutes to protect it.

To leave the system, click **Sign out** at the bottom of the left-hand menu. Always sign out on shared computers.

## Choosing a company

The menu on the left has a box called **Company workspace**. Choose the company you want to work in. Each company has its own customers, invoices and staff. You only see the companies you have been given access to.

The **Owner dashboard** shows a summary of all your companies together.

## What you will see in the menu

Only the parts you are allowed to use are shown. If a menu item is missing, you do not have permission for it. Ask your administrator if you need it.

## Customers and sales

**Leads** are people who have shown interest but are not yet customers.

1. Click **Leads**, then **+ Add a new lead**.
2. Fill in the name and phone number. The system checks for an existing lead or customer with the same phone or email. If it finds one, open that record instead, or tick "Save even if a similar record already exists" only if it is a different person.
3. Open a lead to add notes, record calls, change its status, set a follow-up, or **Convert to customer** when it is ready.

**Customers** are the people who have bought or applied. Each customer has one profile that is shared by visa files, invoices and receipts. Open a customer to see their timeline, documents, money owed and advance.

**Follow-ups** are reminders to contact someone. Overdue ones show in red. Mark them **Done** when finished.

**Sales pipeline** shows every open lead by stage, with the total value at each stage.

**Targets and KPIs** show goals for the company, a branch, a department or a person. Achievement is calculated automatically from the records you enter.

**Marketing campaigns** let you track what each campaign cost and what it brought back.

## Quotations and invoices

1. Go to **Invoices & quotations**. Use the link at the top to switch between invoices and quotations.
2. Click **New invoice** (or **New quotation**). Choose the customer, then fill up to five items. You can pick an item from the catalogue or type your own description.
3. Tax and discounts are calculated automatically. Each document gets the next number for your company and that number is never reused.
4. For a quotation, mark it **Sent**, **Accepted** or **Rejected**. When the customer accepts, click **Convert into invoice**.
5. To print or save a PDF, open the document and click **Print / PDF**, then choose "Save as PDF" in the print window.

## Recording money received

1. Go to **Money receipts**, then **Record payment**.
2. Choose the customer. If the payment is for an invoice, choose that invoice. Otherwise leave it empty.
3. Enter the amount and how it was paid (cash, bKash, bank transfer and so on). Enter the transaction ID if there is one. Each transaction ID can only be used once.
4. Money that is more than the invoice (or is not linked to an invoice) stays with the customer as **advance**. It can be applied to an invoice later from the invoice page.
5. To print a receipt, open it and click **Print receipt**. The first print is the original. Later prints are marked as reprints.

**Refunds** pay money back from a customer's advance. They need approval from a manager or senior accountant.

**Cancelling** a receipt or invoice never deletes it. You must write a reason, and the number stays in the records.

## Expenses

1. Go to **Expenses** and click **+ Record an expense**.
2. Choose the category, amount and what it was for. You can attach the bill as a PDF or photo.
3. If you do not have approval rights, the expense waits for an approver. Only approved expenses reduce the cash and bank balances.

## Cash and bank

Shows each cash box, bank account and mobile wallet with its current balance. Click **View ledger** to see the money in and out. Use **Move money between accounts** for transfers, for example from bKash to the bank.

## Visa files

1. Go to **Visa applications**. Click **+ Open a new visa file**, choose the customer (register the customer first if they are new), the destination country and the visa category.
2. Open the file to:
   - tick off checklist items as they arrive (**Received**), and **Verify** them once checked;
   - upload passports, bank statements and other documents (PDF, JPG, PNG or WEBP, up to 10 MB);
   - update the status when something changes (for example "Submitted" or "Approved"). Every change is kept in the history.
3. Use **Invoice this file** to bill your service fee.

Passports and other personal documents are private. Only people with permission can open them, and downloads are recorded in the audit log.

## Staff, attendance and leave

- **Employees**: the staff directory. Salary details are only visible to people with the salary permission.
- **Attendance**: pick a date and record each person's status, check-in and check-out times. Late arrivals and early departures are worked out from the company's shift times and grace period.
- **Leave requests**: send a request for yourself or for someone else (if allowed). A manager approves or rejects it. You are notified of the decision.

## Tasks

The **Office tasks** board lists things to do. Choose **Mine** to see only your tasks. Move a task forward with the buttons on its row. Overdue tasks are shown in red.

## Notifications

The **Alerts** link at the top shows how many things need your attention (new assignments, approvals, decisions). Open **Notifications** to read them and mark them as read.

## Reports

Go to **Reports**, choose the period, and click **Show report**. Money figures are in Bangladeshi Taka (৳). To use the figures in Excel, click the export button for that list (CSV files open in Excel).

## Tips

- Use the search box on each list to find things quickly (name, phone, number).
- If something looks wrong, do not delete it. Add a note or cancel it with a reason, so the record stays clear.
- Keep your password private. If you think someone else knows it, tell the administrator immediately.

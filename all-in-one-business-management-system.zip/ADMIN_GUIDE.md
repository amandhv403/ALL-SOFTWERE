# Administrator and Owner Guide

This guide is for the Owner (Super Admin), Group Administrators and Company Administrators.

## The first day

1. **Create the Owner account.** On the first visit the system asks you to create it. This account can see and manage everything. Keep its password safe and do not share it.
2. **Add your businesses.** Go to **Companies**. Click **Add my 11 business workspaces** to create Dhaka Holiday, Globepath Holidays, Dhaka Educare, Globepath Education / Higher Study, Community Tourism, Ethnic & Indigenous Cultural Tourism, Nosara Traveler, Little Wonder Co., The Conversation Club, Life Profile and AI Life Companion. You can also create a new company with the form on the same page.
3. **Set up each company.** Open a company, then **Settings**:
   - company name, address, phone, email and trade licence or TIN, which print on invoices and receipts;
   - the logo (PNG, JPG or WEBP);
   - number prefixes for invoices (for example `DH-INV`), quotations, receipts and visa files;
   - working hours, grace period for late arrival, and the financial year start month;
   - which modules are switched on. Switch off what the business does not use.
4. **Add branches and departments** under **Settings → Branches & departments**.
5. **Create logins.** Go to **Administration → Users & logins** and create an account for each person with a temporary password. Tell them the password in person or by phone. They must change it at first sign-in.
6. **Give company access.** Open a company and go to **Team & access**. Choose the person, their role, and optionally a branch or department. A branch manager with a branch set sees only that branch.
7. **Create cash and bank accounts** under **Accounting → Cash & bank**, with their opening balances.
8. **Create expense categories** if the standard list does not fit (**Accounting → Expenses**).

## Roles

Built-in roles: Company Administrator, Branch Manager, Department Manager, Sales Executive, Marketing Executive, CRM Officer, Customer Service Officer, Visa Officer, Education Consultant, Document Officer, Accounts Officer, HR Officer, Data Entry Operator, Read-only User and Auditor.

Owner and Group Administrator accounts have every permission in every company (they are "top-level" roles, not company roles).

To make a custom role, go to **Administration → Roles & permissions**, tick the permissions, and save. Built-in roles cannot be deleted. A custom role can be deleted only when nobody has it.

Individual adjustments: on the **Team & access** page you can add extra permissions for one person (for example `accounting.approve`) or remove one (for example `accounting.delete`). Use the format `module.action`. The page lists the available names.

### Permission reference

Modules: company, team, crm, sales, marketing, visa, accounting, hr, hr_salary, tasks, reports, documents, audit.
Actions: view, create, edit, delete (also used for cancel), approve, reject, verify, assign, print, export, manage (all actions in that module).

Important separations built in:
- Salary information needs `hr_salary.view`. It is not included in any role except HR Officer (and the Owner).
- Cancelling invoices and receipts needs `accounting.delete`. Approving expenses needs `accounting.approve`. Refunds need `accounting.approve`.
- A person cannot approve their own expense.
- Sales staff can create invoices and quotations but cannot edit confirmed financial records.

## Switching modules and companies on or off

- **Module off**: the menu for it disappears for everyone in that company. Its data is kept.
- **Company deactivated**: nobody can open it until you reactivate it. Its data is kept. Use this instead of deleting.

## Accounts and passwords

- **Reset a password**: Administration → Users & logins → enter a new temporary password → **Set**. The person is signed out everywhere and must choose a new password.
- **Switch an account off**: the person is signed out and cannot sign in until you switch it on again.
- **Lockout**: after 5 wrong passwords the account is locked for 15 minutes. You can reset the password to unlock it sooner.

## Audit log

Administration → Audit log shows who did what and when: sign-ins, record changes, payments, cancellations, document downloads and exports. Entries cannot be edited or deleted from the system.

## Document numbers

Each company has its own counters. Numbers only go up. Cancelled invoices and receipts keep their numbers. If you change a prefix, old numbers stay as they were and new ones use the new prefix.

## Money rules to remember

- Refunds and expense approvals are controlled by permission. Use the approver role for these, not the everyday data-entry role.
- Cancelling an invoice that has payments is blocked until the related receipts are cancelled first.
- Printed receipts show balances at the time of printing.

## Backups

Read BACKUP_RESTORE_GUIDE.md. Make a database backup and a copy of the document folder regularly, and test a restore at least once.

## Support checklist for a problem

1. Note the page, the time and what you clicked.
2. Check the audit log to see what changed.
3. Check that the company and module are switched on, and that the person has the right role.
4. If the problem continues, contact the developer and send the note from step 1.

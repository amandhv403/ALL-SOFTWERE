# All-in-One Business Management System

A web application that runs several businesses from one place: customers (CRM), quotations, invoices, money receipts, expenses, cash and bank accounts, visa files with private documents, employees, attendance and leave, office tasks, targets, marketing campaigns, reports and CSV exports. Every company has its own separate records.

Version: 0.1.2 (see CHANGELOG.md). Status and missing features: DEVELOPMENT_STATUS.md. Review results: REVIEW_REPORT.md.

---

## 1. What you need

| Item | Version | Notes |
|---|---|---|
| Node.js | 22 (LTS) | https://nodejs.org |
| PostgreSQL | 15 or newer | A database and a user with rights to create tables |
| psql (optional) | same as PostgreSQL | Only needed for the smoke test and backups |
| Linux, macOS or Windows | any recent version | Commands below show Windows variants where they differ |

---

## 2. Project layout

```
package.json, package-lock.json   dependencies (install with npm ci)
drizzle.config.ts                 database tool settings (reads DATABASE_URL from .env)
.env.example                      template for the settings file (copy it to .env)
next.config.ts                    security headers and upload size limit (12 MB request)
src/app/                          pages (App Router), server actions (src/app/actions), API routes (src/app/api)
src/components/                   shared screens (forms, menu, tables)
src/lib/                          business rules: permissions, auth, money, numbering, ledger, storage, export
src/db/schema.ts                  all database tables
scripts/smoke-test.mjs            end-to-end test (only for an EMPTY test database)
docs: *.md                        guides for users, admins, deployment, backups, security and status
```

---

## 3. Settings (.env)

Create a file named `.env` in the project folder (next to `package.json`). Never commit it or share it.

| Name | Required | Example | Purpose |
|---|---|---|---|
| `DATABASE_URL` | yes | `postgresql://app_user:STRONG_PASSWORD@127.0.0.1:5432/business_system` | Database connection |
| `UPLOAD_DIR` | no | `/var/lib/business-system/uploads` | Private folder for passports and documents. Default: `storage/private-uploads` inside the project. Must be backed up |
| `COOKIE_SECURE` | yes on a live HTTPS site | `true` | Makes login cookies HTTPS-only. Use `false` only on a local test computer |
| `FRAME_ANCESTORS` | no (leave empty on a live site) | `"https://arena.ai https://*.arena.ai https://*.arena.site"` | Websites allowed to show this application inside their own window. Empty = nobody. Used only for the Arena Code preview (section 3a). Run `npm run build` after changing it |
| `PORT` | no | `3000` | Port the web server listens on (default 3000) |

---

---

## 3a. Arena Code preview (optional)

The Arena Code preview shows the application inside arena.ai. A website can only be shown inside another website if it allows that. By default this application allows nobody, which is the safe setting for a live site.

- **Live site:** leave `FRAME_ANCESTORS` empty (this is what `.env.example` does).
- **Arena preview:** in `.env`, set
  `FRAME_ANCESTORS="https://arena.ai https://*.arena.ai https://*.arena.site"`
  then run `npm run build` again and restart the application.

In preview mode the sign-in cookie uses settings that work inside another website (`SameSite=None; Secure; Partitioned`), so people stay signed in inside the preview window. Open the preview from inside Arena Code. Opening the preview address directly in a browser tab shows "Preview Unavailable", which is the preview service's own page, not an error in the application. Chrome or Edge work best for the preview; some browsers may block sign-in inside a preview window.

---

## 4. Install and run on a computer (step by step)

Run these in a terminal inside the project folder. Each command must finish before the next one starts.

**Step 1 – Install the packages (uses the exact versions in package-lock.json)**
```
npm ci
```

**Step 2 – Create the settings file**
- Linux / macOS: `cp .env.example .env`
- Windows (Command Prompt): `copy .env.example .env`

Then open `.env` and set `DATABASE_URL` to your database. For a local test, set `COOKIE_SECURE=false`.

**Step 3 – Create an empty database (once)**
```
psql "postgresql://postgres:YOUR_PASSWORD@127.0.0.1:5432/postgres" -c "CREATE DATABASE business_system;"
```

**Step 4 – Create all tables (run again after every update)**
```
npx drizzle-kit push
```
It prints `Changes applied` when it works.

**Step 5 – Build the application**
```
npm run build
```
It must end with `Compiled successfully` and a list of routes, and must not stop with an error.

**Step 6 – Start the application**
```
npm run start
```
Leave this terminal open. Stop it with Ctrl+C.

**Step 7 – Check it works**
- Open `http://localhost:3000/api/health`. It must show `{"ok":true}`.
- Open `http://localhost:3000`. On a new database it opens the **first-time setup** page. Create the Owner account there.

Upgrades: stop the server, back up the database and the upload folder, replace the project files (keep `.env` and the upload folder), then run `npm ci`, `npx drizzle-kit push`, `npm run build`, `npm run start`.

---

## 5. Test the whole system (optional, EMPTY database only)

The smoke test creates test accounts and sample records (owner `owner@test.local`). Run it only on a brand-new database, never on live data. Then reset the database before real use (section 9).

```
node scripts/smoke-test.mjs http://localhost:3000
```

Expected result: `187 passed, 0 failed.` It needs `psql` on the command line and the build from step 5.

Also available: `npm run lint` (must show no errors) and `npx tsc --noEmit` (must show no output).

---

## 6. Deploy on a live server (Linux VPS, recommended)

Any Linux server with at least 2 GB RAM works (Ubuntu 22.04/24.04 or Debian 12 tested in development).

1. **Prepare the server**: install Node.js 22, PostgreSQL 15+, Nginx, and certbot (for HTTPS). Create a database user with a strong password and a database named `business_system`. Do not open port 5432 to the internet.
2. **Copy the project** to `/srv/business-system` (unzip the ZIP there, or clone your Git repository). Do not copy `node_modules` or `.next` from another computer.
3. **Create the private upload folder** outside the project: `sudo mkdir -p /var/lib/business-system/uploads` and make it readable and writable only by the account that runs the app.
4. **Create `.env`** in `/srv/business-system` with:
   ```
   DATABASE_URL=postgresql://app_user:STRONG_PASSWORD@127.0.0.1:5432/business_system
   UPLOAD_DIR=/var/lib/business-system/uploads
   COOKIE_SECURE=true
   ```
5. **Install and prepare** (in the project folder):
   ```
   npm ci
   npx drizzle-kit push
   npm run build
   ```
6. **Run it permanently** with pm2 (restarts after a crash or reboot):
   ```
   sudo npm install -g pm2
   pm2 start "npm run start" --name business-system
   pm2 save
   pm2 startup
   ```
7. **Put Nginx in front** as a secure website. Create `/etc/nginx/sites-available/business-system`:
   ```
   server {
       server_name erp.yourcompany.com;
       client_max_body_size 12m;
       location / {
           proxy_pass http://127.0.0.1:3000;
           proxy_set_header Host $host;
           proxy_set_header X-Forwarded-Proto $scheme;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       }
   }
   ```
   Enable it (`sudo ln -s /etc/nginx/sites-available/business-system /etc/nginx/sites-enabled/`), test (`sudo nginx -t`), reload (`sudo systemctl reload nginx`), then add HTTPS: `sudo certbot --nginx -d erp.yourcompany.com`.
   `client_max_body_size 12m` is required; without it, passport and document uploads fail.
8. **Verify the live site**: `https://erp.yourcompany.com/api/health` shows `{"ok":true}`. Open the site, create the Owner account, sign in, create a company, and sign out.
9. **Set up backups** (see BACKUP_RESTORE_GUIDE.md): a daily database dump and a daily copy of the upload folder. Test one restore into a separate database.

Not recommended: Vercel or other serverless hosting for this version. It cannot keep uploaded documents between runs and cannot run the database here. A VPS or Windows server is the supported path.

Windows server: follow INSTALLATION_GUIDE.md, put Caddy or IIS in front for HTTPS, and set the same settings.

---

## 7. Get the code into GitHub (optional)

The ZIP already contains the project's Git history in a hidden `.git` folder. If you use that folder, skip `git init` and `git add .`; only add your remote and push. Never commit `.env`.

```
git init
git add .
git commit -m "Business management system 0.1.1"
git branch -M main
git remote add origin https://github.com/YOUR-ACCOUNT/business-management-system.git
git push -u origin main
```
Use a private repository. `.gitignore` already excludes `.env`, `node_modules`, `.next` and `storage`. Check with `git status` before pushing that `.env` is not listed.

---

## 8. Instructions for an AI agent deploying this project

1. Read sections 1–4 and this section. Do not change application code unless asked.
2. Confirm Node.js 22 and PostgreSQL 15+ are installed. Confirm `package-lock.json` is present.
3. Create `.env` from `.env.example`. Set `DATABASE_URL` and, for a live site, `UPLOAD_DIR` (outside the project) and `COOKIE_SECURE=true`. Leave `FRAME_ANCESTORS` empty. Never print or commit secrets.
4. Run `npm ci`, `npx drizzle-kit push`, `npm run build`, `npm run start`. Every command must succeed before the next.
5. Verify `GET /api/health` returns `{"ok":true}` and `GET /` redirects to `/setup` (new database) or `/login` (existing data).
6. Do not run `scripts/smoke-test.mjs` against a database with real data. It is for empty test databases only.
7. Never run `DROP SCHEMA`, `DROP DATABASE`, or accept data-loss prompts from `drizzle-kit push` on a live database. Take a backup first. Stop and ask a human if `drizzle-kit push` lists a column or table removal.
8. For HTTPS, put a reverse proxy in front (Nginx example in section 6) with `client_max_body_size 12m`.
9. Report back: the URL, the health result, the build result, and any warnings.

---

## 9. Going live with real data (checklist)

- [ ] `.env` has a strong database password and `COOKIE_SECURE=true`.
- [ ] `FRAME_ANCESTORS` is empty, so nobody can show the live site inside another website.
- [ ] Database port is not reachable from the internet.
- [ ] Uploads are stored outside the project folder and backed up.
- [ ] HTTPS works and `/api/health` is reachable.
- [ ] A test database was used for the smoke test, and the live database was created empty (no test owner account).
- [ ] The Owner created the first account and saved its password in a password manager.
- [ ] A backup was taken and one restore was tested.

---

## 10. Troubleshooting

| Symptom | Fix |
|---|---|
| `DATABASE_URL is required` | `.env` is missing or not in the project folder |
| `password authentication failed` | The password in `DATABASE_URL` is wrong |
| `database "business_system" does not exist` | Run step 3 |
| `relation "users" does not exist` | Run `npx drizzle-kit push` |
| Upload fails with a size error behind Nginx | Set `client_max_body_size 12m;` |
| Logins never stick on a live HTTPS site | Set `COOKIE_SECURE=true` and use HTTPS |
| "refused to connect" inside the Arena preview | Set `FRAME_ANCESTORS` as described in section 3a, run `npm run build`, then restart. The preview also updates after each build |
| Port 3000 in use | Set `PORT=3001` in the environment, then open that port |
| Build fails with a type error | Run `npm ci` again, then `npm run build` |

---

## 11. Documentation

| File | Content |
|---|---|
| INSTALLATION_GUIDE.md | Windows, step by step, for non-programmers |
| DATABASE_SETUP_GUIDE.md | Database creation and rules |
| USER_GUIDE.md | Daily use for staff |
| ADMIN_GUIDE.md | Owner and administrator tasks |
| DEPLOYMENT_GUIDE.md | Live server options |
| BACKUP_RESTORE_GUIDE.md | Backups and restores |
| PROJECT_ARCHITECTURE.md | How the code is organised |
| DATABASE_SCHEMA.md | Tables and relationships |
| SECURITY_NOTES.md | Protections and known gaps |
| TESTING_REPORT.md | What was tested and the results |
| REVIEW_REPORT.md | Two review rounds: what was checked and fixed |
| DEVELOPMENT_STATUS.md | What is finished, what is missing, next steps |
| CHANGELOG.md | Version history |

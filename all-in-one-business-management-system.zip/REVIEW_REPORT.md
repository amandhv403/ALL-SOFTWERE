# Review Report (version 0.1.1)

This report records two full review rounds of the code, what each round checked, what was found and fixed, and what is still not verified.

## Round 1 — Automated and static checks

| Check | Command or method | Result before fixes | Result after fixes |
|---|---|---|---|
| Type safety (strict TypeScript, whole project) | `npm exec tsc -- --noEmit` | Passed | Passed |
| Route type generation | `npx next typegen` | Passed | Passed |
| Code quality (lint) | `npm run lint` | 6 errors | 0 errors, 0 warnings |
| Production build | `npm run build` | Passed | Passed, no warnings |
| Permission check on every server action | Scripted scan of all exported actions | Only public actions had no check (sign-in, sign-out, first-time setup). Each of those has its own safeguard (see below) | Same, by design |
| Permission check on every company page | Scripted scan of all pages under `/c/[companyId]` | All pages call `requirePage` | Same |
| API routes | Scripted scan | Only `/api/health` has no check, by design | Same |
| SQL injection risk | Search for raw SQL | No `sql.raw` anywhere. All user values are bound parameters | Same |

Issues found in round 1 and fixed:

| # | Issue | Why it mattered | Fix |
|---|---|---|---|
| 1 | Six lint errors: a variable named `module` (5 places) that shadows a reserved name, and two places that changed a value during page rendering (dashboard totals, cash ledger balance) and one use of `Date.now()` during rendering | Code-quality rules; rendering side effects can show wrong numbers | Renamed variables, used plain loops and `reduce`, used date arithmetic instead of `Date.now()` |
| 2 | Passport numbers were shown in full on the customer profile and in the customer CSV export to anyone who could view customers | Passport numbers are sensitive personal data | Shown in full only to people with the documents permission; everyone else sees `****` plus the last 4 digits. Edit form leaves the stored number untouched for people who cannot see it (prevents accidental erasure) |
| 3 | Company logos were served only to people with company settings and documents permission, so staff who print invoices or receipts saw a broken logo | Printed documents looked wrong for most staff | Logos are viewable by anyone with access to that company. Logos are not sensitive |
| 4 | Documentation said a company with records cannot be deleted, but the database used cascade delete (it would have removed all of its records) | Could lead to silent loss of accounting records | Database rule changed to restrict. Verified: deleting a company with records fails and the company count stays the same |
| 5 | CSV export type check accepted inherited JavaScript names such as `toString` | No data exposure (the permission check still refused them), but the check was wrong | Uses an own-property check |

## Round 2 — End-to-end testing on a fresh database (run twice)

Test: `scripts/smoke-test.mjs`. It sends the same requests a browser sends to the running production build, and checks the database directly.

| Run | Database | Result |
|---|---|---|
| 1 | Fresh schema, created with `drizzle-kit push` | 187 passed, 0 failed |
| 2 | Reset to empty and created again | 187 passed, 0 failed |

Points that were checked in both runs (see TESTING_REPORT.md for the full list):
- Sign-in, lockout after 5 wrong passwords, and sessions (token stored only as a hash).
- Company creation, numbering prefixes, branches, departments, module switches, activate and deactivate.
- Lead duplicate check, conversion, follow-ups, timeline.
- Invoice totals (line tax and discount), quotation conversion, receipts (partial, advance, refund rules, double-submit protection, unique transaction IDs), balance recalculation after cancellation, cancelled numbers never reused.
- Visa file checklist, status history, refusal reason, validity dates.
- Document upload accepted only for real PDF, JPG, PNG or WEBP files (checked by file signature), viewing refused without login, downloads logged.
- Attendance late calculation (grace period), leave overlap check and approval.
- Staff restrictions: salary hidden, expenses refused, other companies refused, admin pages refused, export refused, passport digits masked.
- Every CSV export returns the right file type; exports are logged.

## Round 2 — Additional checks

- Deleting a company with records is refused by the database (checked by hand).
- The first-time setup page only opens when no user exists.
- Browser assets for the sign-in page load (HTTP 200).
- **Fresh install from the ZIP**: the ZIP was extracted to an empty folder and the README steps were followed exactly: `npm ci`, `.env` copied from `.env.example`, `npx drizzle-kit push` (on a new database), type check, lint, `npm run build` (0 warnings), `npm run start`, health check `{"ok":true}`, redirect to the setup page, and security headers present. The end-to-end test then passed 187 of 187 on that copy (a third full run).

## Not verified in this review (be aware)

- Real browser clicks, layout on phones and tablets, printed paper and PDF output. These need a human check in a browser.
- Behaviour under many simultaneous users and large data volumes.
- An external security penetration test. See SECURITY_NOTES.md for known gaps (two-factor sign-in, e-mail password reset, per-address login limits).
- Hosting on a live server. See DEPLOYMENT_GUIDE.md and README.md section 6.

import "dotenv/config";
import type { NextConfig } from "next";

// Controls which websites may show this application inside their own window (a "frame").
//
// Default (FRAME_ANCESTORS empty): nobody can frame the site. This protects users from
// "clickjacking", where a hidden copy of the page is placed under a fake button.
//
// For the Arena Code preview only, set FRAME_ANCESTORS in .env to the websites allowed to show the
// application, separated by spaces, then run `npm run build` again:
//   FRAME_ANCESTORS="https://arena.ai https://*.arena.ai https://*.arena.site"
const ORIGIN_PATTERN = /^https:\/\/(\*\.)?[a-z0-9-]+(\.[a-z0-9-]+)*(:\d{1,5})?$/i;

function framingHeaders(): { key: string; value: string }[] {
  const raw = (process.env.FRAME_ANCESTORS ?? "").trim();
  if (raw === "") {
    return [
      { key: "X-Frame-Options", value: "DENY" },
      { key: "Content-Security-Policy", value: "frame-ancestors 'none'" },
    ];
  }
  const origins = raw.split(/\s+/);
  if (!origins.every((origin) => ORIGIN_PATTERN.test(origin))) {
    throw new Error(
      "FRAME_ANCESTORS is not valid. List web addresses that start with https:// and are separated by spaces, for example: https://arena.ai https://*.arena.ai",
    );
  }
  // X-Frame-Options is left out on purpose: when it is present, browsers block framing even for the listed sites.
  return [{ key: "Content-Security-Policy", value: `frame-ancestors 'self' ${origins.join(" ")}` }];
}

const nextConfig: NextConfig = {
  poweredByHeader: false,
  experimental: {
    // Allows uploads of passports and documents up to 12 MB through server actions (the app limit is 10 MB).
    serverActions: { bodySizeLimit: "12mb" },
  },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          ...framingHeaders(),
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
        ],
      },
    ];
  },
};

export default nextConfig;

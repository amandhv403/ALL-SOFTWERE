# Backup and Restore Guide

A backup is only useful if you can restore it. Test a restore at least once after setting up backups, and every few months after that.

## What to back up

| What | Where it is | How often |
|---|---|---|
| The database (all records, users, invoices, receipts, audit log) | PostgreSQL | Daily, plus before every update |
| Uploaded documents (passports, contracts, bills, logos) | The `UPLOAD_DIR` folder (default `storage/private-uploads`) | Daily, same time as the database |
| The `.env` settings file | Project folder | Once, stored in a password manager or a safe place. Never in email or GitHub |

The program files can be downloaded again from the ZIP or the source repository, so they do not need daily backups.

## Backing up the database

With the PostgreSQL tools installed (they come with the PostgreSQL installer):

```
pg_dump "postgresql://postgres:YOUR_PASSWORD@127.0.0.1:5432/business_system" -F c -f backup-business-system-2026-01-31.dump
```

- `-F c` makes a compressed file that `pg_restore` can read.
- Give the file a date in its name.
- Copy the file to a second place (another drive, cloud storage with access control, or another computer).

## Backing up the documents

Copy the whole `storage/private-uploads` folder (or your `UPLOAD_DIR`) to the same backup place. On Windows you can use **File Explorer → copy and paste**, or a backup tool such as Windows Backup.

## Checking that a backup is good

1. Confirm the dump file is not empty (for example more than a few kilobytes if you have data).
2. List what it contains:
   ```
   pg_restore --list backup-business-system-2026-01-31.dump
   ```
   You should see table entries such as `TABLE public.invoices`.

## Restoring the database (to a new, empty database)

Restore into a **new** database first, so the live data is not touched:

```
psql "postgresql://postgres:YOUR_PASSWORD@127.0.0.1:5432/postgres" -c "CREATE DATABASE business_system_restore_test;"
pg_restore -d "postgresql://postgres:YOUR_PASSWORD@127.0.0.1:5432/business_system_restore_test" --no-owner backup-business-system-2026-01-31.dump
```

Use the connection string form as shown. The `createdb` command can wait for a password prompt that looks like the program has stopped.

Then point a test copy of `.env` at `business_system_restore_test`, start the app, and check that companies, customers and invoices appear.

Only when you are sure you want to replace live data:

1. Stop the app.
2. Rename or drop the old database (ask the developer if unsure).
3. Create an empty database with the same name and run `pg_restore` into it.
4. Start the app and check the main pages.

## Restoring documents

Copy the backed-up folder back to `UPLOAD_DIR`. Keep the same folder structure and file names. Documents are linked by file name, so renaming files breaks them.

## Retention suggestion

- Daily backups kept for 30 days.
- Monthly backups kept for 2 years (tax and audit needs may be longer; check with your accountant).

## Backup status

The system does not yet create or verify backups by itself. The owner or the IT person must run the commands above (or set up a scheduled task) and keep the records. Automatic scheduled backups and in-app backup download are on the roadmap in DEVELOPMENT_STATUS.md.

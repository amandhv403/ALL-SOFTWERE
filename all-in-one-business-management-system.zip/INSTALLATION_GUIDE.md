# Installation Guide (Windows, step by step)

This guide is written for someone who is not a programmer. Follow the steps in order. You only do this once per computer. Daily use happens in the web browser (see the USER_GUIDE).

## Before you start: what you need

1. **Node.js 22 (LTS)**. Download the Windows installer from https://nodejs.org and click through the default options. Restart the computer afterwards.
2. **PostgreSQL 15 or newer**. Download the Windows installer from https://www.postgresql.org/download/windows/. During setup, remember the password you set for the `postgres` user. Keep the default port `5432`.
3. **This project folder**. Extract the ZIP file (see below).

### Extracting the ZIP file

1. Open your **Downloads** folder and find `BUSINESS-MANAGEMENT-SYSTEM.zip`.
2. Right-click it and choose **Extract All…**.
3. Choose a simple location such as `C:\Business` and click **Extract**.
4. Open the extracted folder. You should see files such as `package.json`, `README.md` and a `src` folder.

Downloading and extracting only copies the files to your computer. It does not start the system. The system runs on your computer only after the steps below, and the live internet version (if your developer deploys one) is separate.

## Step 1: Create the database

1. Open **pgAdmin** (installed with PostgreSQL) or the **SQL Shell (psql)**.
2. Create an empty database named `business_system`.
   - In psql, type: `CREATE DATABASE business_system;` and press Enter.
3. Keep the username (usually `postgres`), the password and the port (`5432`) at hand.

More detail is in [DATABASE_SETUP_GUIDE.md](DATABASE_SETUP_GUIDE.md).

## Step 2: Create the settings file

1. Inside the project folder, find `.env.example`.
2. Copy it and rename the copy to `.env`. (If Windows hides file extensions, make sure the name is exactly `.env`.)
3. Open `.env` in Notepad and change the `DATABASE_URL` line to match your database:

   `DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@127.0.0.1:5432/business_system`

   Replace `YOUR_PASSWORD` with the PostgreSQL password. Do not share this file.

## Step 3: Install and set up (one time)

1. Open the project folder, click the address bar, type `cmd` and press Enter. A black window opens in the right place.
2. Run these commands one at a time, pressing Enter after each:

   ```
   npm install
   npx drizzle-kit push
   npm run build
   ```

   - `npm install` downloads the software parts (takes a few minutes).
   - `npx drizzle-kit push` creates all the database tables.
   - `npm run build` prepares the application.

## Step 4: Start the system

In the same black window, run:

```
npm run start
```

Leave this window open while you use the system. Then open your web browser and go to:

`http://localhost:3000`

The first time, you will see **Welcome**. Create the **Owner** account there (your name, email and a password of at least 10 characters with a letter and a number). Then sign in.

## Step 5: Stop the system

Click in the black window and press **Ctrl + C**, then type `Y` and press Enter.

## Updating to a newer version

1. Stop the system (Step 5).
2. **Back up the database first** (see [BACKUP_RESTORE_GUIDE.md](BACKUP_RESTORE_GUIDE.md)).
3. Replace the project files with the new version. Keep your `.env` file and the `storage` folder (they hold your settings and uploaded documents).
4. Run `npm install`, `npx drizzle-kit push`, `npm run build`, then `npm run start` again.

Never delete the database to update. Updates only add to the database, they do not erase records.

## Common problems

| Problem | What to do |
|---|---|
| "DATABASE_URL is required" | The `.env` file is missing or in the wrong folder. It must sit next to `package.json`. |
| "password authentication failed" | The password in `.env` does not match PostgreSQL. Correct it and try again. |
| "database does not exist" | Create the database (Step 1). |
| Browser shows "This site can't be reached" | The black window was closed. Run `npm run start` again. |
| Page says "Something went wrong" | Note the time, copy the message from the black window, and ask your developer. |

# Security Notes

This document lists the protections built into the system, and the gaps the owner should know about. It is written in plain language. A professional security review is recommended before handling a large amount of passport or payment data on a live server.

## Protections in place

| Area | What is done |
|---|---|
| Passwords | Stored as scrypt hashes with a random salt. Minimum 10 characters with a letter and a number. Plain text is never stored |
| Sign-in | Five wrong passwords lock the account for 15 minutes. Locked and switched-off accounts see the same generic message |
| Sessions | Random 256-bit token in an HTTP-only, SameSite=Lax cookie. Only its hash is stored. Expires after 12 hours. Changing a password or switching an account off signs out other sessions |
| Secure cookies | Cookies are marked Secure when the request came over HTTPS (`x-forwarded-proto`) or `COOKIE_SECURE=true` |
| Access control | Every page and every server action checks the user's company access, module switch and permission on the server |
| Company separation | Every query includes the company, so one company's records cannot appear in another company's pages |
| Branch limits | Staff limited to a branch cannot see other branches' records in lists or on record pages |
| Salary | Salary fields are hidden and not written unless the user has the salary permission. Salary is excluded from CSV exports unless permitted |
| Documents | Files are kept outside the public folder under random names. They are served only by `/api/files/[id]` after the permission and branch checks. Other companies get "not found" so existence is not revealed. Passports, IDs and downloads are logged |
| Uploads | Maximum 10 MB. Only PDF, JPG, PNG and WEBP. The real file signature is checked, not only the file name |
| Money | Duplicate receipt submissions are blocked (one-time form token and unique transaction IDs). Invoices are locked while a payment is applied |
| Audit | Sign-ins, record changes, payments, cancellations, exports and document access are logged. The app has no way to edit or delete audit entries |
| SQL safety | All database access goes through Drizzle with parameters. User text is escaped before being used in search patterns |
| CSV exports | Cells starting with = + - @ are neutralised to prevent spreadsheet formula injection |
| Passport numbers | Shown in full only to people with the documents permission. Everyone else sees only the last 4 characters, on screens and in CSV exports. The edit form does not overwrite a stored number for people who cannot see it |
| Company logos | Viewable by anyone with access to that company (they appear on printed documents). Logos are not treated as sensitive |
| Company deletion | Blocked by the database while a company has any records. The app has no delete-company button |
| Who may show the site inside another website | Nobody, by default: `X-Frame-Options: DENY` and `Content-Security-Policy: frame-ancestors 'none'`. Only the websites listed in `FRAME_ANCESTORS` may show it (used for the Arena Code preview). Leave it empty on a live site |
| Sign-in cookie | Live sites: `HttpOnly; SameSite=Lax` (and `Secure` on HTTPS). Preview mode (`FRAME_ANCESTORS` set): `SameSite=None; Secure; Partitioned`, so sign-in works inside the preview window. Sign-out overwrites the cookie with the same settings |
| Browser headers | X-Content-Type-Options nosniff, Referrer-Policy and a restricted Permissions-Policy |
| Secrets | Passwords and connection strings are read from the `.env` file, which is excluded from Git |
| Forgery | Server actions are protected by Next.js origin checks. Forms that change money also carry one-time tokens |

## Known gaps (to close before wider use)

1. **No two-factor sign-in yet.** Recommended for Owner and finance accounts.
2. **No self-service "forgot password".** The owner resets passwords from the admin page. Email delivery is not configured.
3. **Login rate limit is per account**, not per network address. Adding a limit per IP address is recommended behind a proxy.
4. **Session time limit is fixed at 12 hours.** There is no "remember this device" option and no idle timeout yet.
5. **Document access logs cover views and downloads of sensitive files and all downloads**, not every view of other files.
6. **Consent and retention rules** (for example automatic deletion of old passports) are recorded as a flag only. Data deletion must be done by the owner under the company's policy.
7. **Encryption at rest** depends on the database and disk provider. Use encrypted disks and a database with encrypted backups.
8. **Field-level encryption** of passport numbers and National ID numbers is not implemented.
9. **No malware scanning** of uploaded files yet.
10. **Penetration testing has not been done.** Plan an external test before going live.
11. **Preview mode relaxes two protections on purpose.** When `FRAME_ANCESTORS` is set, the site can be shown inside the listed websites and the sign-in cookie is sent in that cross-site window. Use it only for previews, never on the live site.

## Advice for the owner

- Use a unique, long password for the Owner account, and store it in a password manager.
- Give people the lowest role that does their job. Review access when someone leaves: use **Remove access** on the Team page and switch off their login.
- Never share one login between several people. Use separate accounts so the audit log is meaningful.
- Keep the server software and Node.js updated.
- Use HTTPS only, and set `COOKIE_SECURE=true`.
- Check the audit log every week for unusual activity such as exports or document downloads at odd hours.

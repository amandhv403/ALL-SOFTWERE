"use client";

// The main layout: sidebar navigation, company switcher, notifications and sign-out.
// Menu items are filtered by the permissions loaded on the server. Access is still enforced on the server.
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState, type ReactNode } from "react";
import { ADMIN_NAV, COMPANY_NAV, GLOBAL_NAV } from "@/lib/nav";
import { APP_NAME, isToggleable, type ActionKey, type ModuleKey } from "@/lib/constants";

export type ShellCompany = {
  id: number;
  name: string;
  businessType: string;
  enabledModules: string[];
  perms: string[] | null;
};

type Props = {
  user: { fullName: string; email: string; globalRole: string };
  companies: ShellCompany[];
  unreadCount: number;
  mustChangePassword: boolean;
  logoutAction: () => Promise<void>;
  children: ReactNode;
};

function linkClass(active: boolean): string {
  return `flex items-center justify-between rounded-lg px-3 py-2 text-sm transition ${
    active ? "bg-teal-50 font-medium text-teal-900" : "text-slate-700 hover:bg-slate-100"
  }`;
}

export function AppShell({ user, companies, unreadCount, mustChangePassword, logoutAction, children }: Props) {
  const pathname = usePathname();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);

  const match = pathname.match(/^\/c\/(\d+)/);
  const currentId = match ? Number(match[1]) : null;
  const current = companies.find((company) => company.id === currentId) ?? null;
  const isAdmin = user.globalRole === "owner" || user.globalRole === "group_admin";

  const canSee = (company: ShellCompany, module: ModuleKey, action: ActionKey = "view"): boolean => {
    if (isToggleable(module) && !company.enabledModules.includes(module)) return false;
    if (company.perms === null) return true;
    return company.perms.includes(`${module}.${action}`);
  };

  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`));

  const title = current ? current.name : "All companies";

  return (
    <div className="min-h-screen bg-slate-100">
      {menuOpen ? (
        <div className="fixed inset-0 z-30 bg-slate-900/40 lg:hidden" onClick={() => setMenuOpen(false)} />
      ) : null}

      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-slate-200 bg-white transition-transform duration-200 lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 print:hidden ${
          menuOpen ? "translate-x-0" : "-translate-x-full"
        } ${collapsed ? "lg:hidden" : "lg:flex"}`}
      >
        <div className="flex items-center gap-3 border-b border-slate-200 px-5 py-4">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-teal-700 text-sm font-bold text-white">BM</div>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-slate-900">{APP_NAME}</p>
            <p className="truncate text-xs text-slate-500">{user.fullName}</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-3 py-4">
          <div className="mb-4 px-2">
            <label htmlFor="company-switcher" className="mb-1 block text-xs font-medium uppercase tracking-wide text-slate-500">
              Company workspace
            </label>
            <select
              id="company-switcher"
              value={currentId ?? ""}
              onChange={(event) => {
                if (event.target.value) {
                  setMenuOpen(false);
                  router.push(`/c/${event.target.value}`);
                }
              }}
              className="block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm focus:border-teal-600 focus:outline-none focus:ring-2 focus:ring-teal-600/20"
            >
              <option value="">Select a company…</option>
              {companies.map((company) => (
                <option key={company.id} value={company.id}>
                  {company.name}
                </option>
              ))}
            </select>
          </div>

          <nav className="space-y-1">
            {GLOBAL_NAV.map((item) => (
              <Link key={item.href} href={item.href} onClick={() => setMenuOpen(false)} className={linkClass(isActive(item.href))}>
                <span>{item.label}</span>
                {item.href === "/notifications" && unreadCount > 0 ? (
                  <span className="rounded-full bg-red-600 px-2 py-0.5 text-xs font-semibold text-white">{unreadCount}</span>
                ) : null}
              </Link>
            ))}
          </nav>

          {current ? (
            <div className="mt-6 space-y-5">
              {COMPANY_NAV.map((section) => {
                const items = section.items.filter((item) => canSee(current, item.module, item.action ?? "view"));
                if (items.length === 0) return null;
                return (
                  <div key={section.title}>
                    <p className="px-3 text-xs font-semibold uppercase tracking-wide text-slate-400">{section.title}</p>
                    <div className="mt-1 space-y-0.5">
                      {items.map((item) => {
                        const href = `/c/${current.id}${item.path}`;
                        const active = item.path === "" ? pathname === href : isActive(href);
                        return (
                          <Link key={href} href={href} onClick={() => setMenuOpen(false)} className={linkClass(active)}>
                            {item.label}
                          </Link>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : null}

          {isAdmin ? (
            <div className="mt-6">
              <p className="px-3 text-xs font-semibold uppercase tracking-wide text-slate-400">Administration</p>
              <div className="mt-1 space-y-0.5">
                {ADMIN_NAV.map((item) => (
                  <Link key={item.href} href={item.href} onClick={() => setMenuOpen(false)} className={linkClass(isActive(item.href))}>
                    {item.label}
                  </Link>
                ))}
              </div>
            </div>
          ) : null}
        </div>

        <div className="border-t border-slate-200 p-4">
          <p className="truncate text-xs text-slate-500">{user.email}</p>
          <form action={logoutAction} className="mt-2">
            <button type="submit" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
              Sign out
            </button>
          </form>
        </div>
      </aside>

      <div className={`min-h-screen ${collapsed ? "" : "lg:pl-0"}`}>
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-slate-200 bg-white/90 px-4 py-3 backdrop-blur print:hidden sm:px-6">
          <button
            type="button"
            aria-label="Open menu"
            onClick={() => setMenuOpen((open) => !open)}
            className="rounded-lg border border-slate-300 px-2.5 py-1.5 text-sm text-slate-700 lg:hidden"
          >
            Menu
          </button>
          <button
            type="button"
            aria-label="Collapse or expand sidebar"
            onClick={() => setCollapsed((value) => !value)}
            className="hidden rounded-lg border border-slate-300 px-2.5 py-1.5 text-sm text-slate-700 lg:inline-flex"
          >
            {collapsed ? "Show menu" : "Hide menu"}
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-slate-900">{title}</p>
          </div>
          <Link href="/notifications" className="relative rounded-lg px-2.5 py-1.5 text-sm text-slate-700 hover:bg-slate-100">
            Alerts
            {unreadCount > 0 ? (
              <span className="absolute -right-1 -top-1 rounded-full bg-red-600 px-1.5 text-[10px] font-semibold text-white">
                {unreadCount}
              </span>
            ) : null}
          </Link>
          <Link href="/account" className="hidden rounded-lg px-2.5 py-1.5 text-sm text-slate-700 hover:bg-slate-100 sm:inline-flex">
            {user.fullName}
          </Link>
        </header>

        <main className="min-w-0 p-4 sm:p-6 lg:p-8">
          {mustChangePassword ? (
            <div className="mb-5 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
              For your security, please change your temporary password now.{" "}
              <Link href="/account" className="font-semibold underline">
                Change password
              </Link>
            </div>
          ) : null}
          {children}
        </main>
      </div>
    </div>
  );
}

// Shared visual building blocks. Safe to use from both server and client components (no hooks, no server code).
import Link from "next/link";
import type { ReactNode } from "react";
import { humanize } from "@/lib/constants";

export const btnPrimary =
  "inline-flex items-center justify-center gap-2 rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-teal-800 disabled:cursor-not-allowed disabled:opacity-60 print:hidden";
export const btnSecondary =
  "inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-800 shadow-sm transition hover:bg-slate-50 print:hidden";
export const btnDanger =
  "inline-flex items-center justify-center rounded-lg bg-red-600 px-3 py-1.5 text-sm font-medium text-white transition hover:bg-red-700 print:hidden";
export const btnSmall =
  "inline-flex items-center justify-center rounded-md border border-slate-300 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 transition hover:bg-slate-50 print:hidden";
export const inputClass =
  "mt-1 block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm placeholder:text-slate-400 focus:border-teal-600 focus:outline-none focus:ring-2 focus:ring-teal-600/20 disabled:bg-slate-100";
export const labelClass = "block text-sm font-medium text-slate-700";
export const tableClass = "min-w-full divide-y divide-slate-200 text-sm";
export const thClass =
  "whitespace-nowrap bg-slate-50 px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide text-slate-500";
export const tdClass = "px-3 py-2 align-top text-slate-800";
export const cardClass = "rounded-2xl border border-slate-200 bg-white shadow-sm";

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-950">{title}</h1>
        {description ? <p className="mt-1 max-w-3xl text-sm text-slate-600">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function Card({
  title,
  description,
  actions,
  children,
  className = "",
}: {
  title?: string;
  description?: string;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`${cardClass} p-5 ${className}`}>
      {title || actions ? (
        <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
          <div>
            {title ? <h2 className="text-base font-semibold text-slate-900">{title}</h2> : null}
            {description ? <p className="mt-0.5 text-sm text-slate-600">{description}</p> : null}
          </div>
          {actions}
        </div>
      ) : null}
      {children}
    </section>
  );
}

export function Stat({
  label,
  value,
  hint,
  href,
  tone = "slate",
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  href?: string;
  tone?: Tone;
}) {
  const body = (
    <div className={`${cardClass} p-4 transition hover:shadow-md`}>
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className={`mt-2 text-2xl font-semibold tracking-tight ${tone === "red" ? "text-red-700" : "text-slate-950"}`}>
        {value}
      </p>
      {hint ? <p className="mt-1 text-xs text-slate-500">{hint}</p> : null}
    </div>
  );
  return href ? <Link href={href}>{body}</Link> : body;
}

export type Tone = "slate" | "green" | "amber" | "red" | "blue" | "teal";

const TONE_CLASSES: Record<Tone, string> = {
  slate: "bg-slate-100 text-slate-700 ring-slate-200",
  green: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  amber: "bg-amber-50 text-amber-800 ring-amber-200",
  red: "bg-red-50 text-red-700 ring-red-200",
  blue: "bg-sky-50 text-sky-700 ring-sky-200",
  teal: "bg-teal-50 text-teal-800 ring-teal-200",
};

const GREEN_STATUSES = [
  "paid",
  "approved",
  "active",
  "converted",
  "delivered",
  "accepted",
  "present",
  "done",
  "verified",
  "received",
  "completed",
  "passport_ready",
];
const RED_STATUSES = [
  "cancelled",
  "rejected",
  "refused",
  "lost",
  "not_interested",
  "terminated",
  "resigned",
  "absent",
  "urgent",
];
const AMBER_STATUSES = [
  "pending",
  "partially_paid",
  "additional_documents_requested",
  "documents_pending",
  "waiting",
  "late",
  "half_day",
  "on_leave",
  "paused",
  "probation",
  "high",
  "draft",
];
const BLUE_STATUSES = ["new", "open", "issued", "submitted", "in_progress", "sent", "planned", "todo"];

export function toneFor(status: string | null | undefined): Tone {
  if (!status) return "slate";
  if (GREEN_STATUSES.includes(status)) return "green";
  if (RED_STATUSES.includes(status)) return "red";
  if (AMBER_STATUSES.includes(status)) return "amber";
  if (BLUE_STATUSES.includes(status)) return "blue";
  return "slate";
}

export function Badge({ tone = "slate", children }: { tone?: Tone; children: ReactNode }) {
  return (
    <span
      className={`inline-flex items-center whitespace-nowrap rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset ${TONE_CLASSES[tone]}`}
    >
      {children}
    </span>
  );
}

export function StatusBadge({ status, label }: { status: string | null | undefined; label?: string }) {
  return <Badge tone={toneFor(status)}>{label ?? humanize(status)}</Badge>;
}

export function Flash({ notice, error }: { notice?: string; error?: string }) {
  if (!notice && !error) return null;
  return (
    <div className="mb-5 space-y-2">
      {notice ? (
        <div role="status" className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          {notice}
        </div>
      ) : null}
      {error ? (
        <div role="alert" className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          {error}
        </div>
      ) : null}
    </div>
  );
}

export function EmptyState({ title, text }: { title: string; text?: string }) {
  return (
    <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50/60 px-6 py-10 text-center">
      <p className="text-sm font-medium text-slate-800">{title}</p>
      {text ? <p className="mx-auto mt-1 max-w-md text-sm text-slate-500">{text}</p> : null}
    </div>
  );
}

export function DetailList({ items }: { items: { label: string; value: ReactNode }[] }) {
  return (
    <dl className="grid gap-x-6 gap-y-4 sm:grid-cols-2">
      {items.map((item) => (
        <div key={item.label}>
          <dt className="text-xs font-medium uppercase tracking-wide text-slate-500">{item.label}</dt>
          <dd className="mt-0.5 break-words text-sm text-slate-900">{item.value ?? "—"}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Pagination({
  basePath,
  page,
  pageSize,
  total,
  query,
}: {
  basePath: string;
  page: number;
  pageSize: number;
  total: number;
  query: Record<string, string>;
}) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const href = (target: number) => {
    const params = new URLSearchParams({ ...query, page: String(target) });
    return `${basePath}?${params.toString()}`;
  };
  return (
    <nav className="mt-4 flex flex-wrap items-center justify-between gap-3 text-sm text-slate-600 print:hidden">
      <span>
        Page {page} of {pages} · {total} record{total === 1 ? "" : "s"}
      </span>
      <div className="flex gap-2">
        {page > 1 ? (
          <Link href={href(page - 1)} className={btnSmall}>
            Previous
          </Link>
        ) : null}
        {page < pages ? (
          <Link href={href(page + 1)} className={btnSmall}>
            Next
          </Link>
        ) : null}
      </div>
    </nav>
  );
}

export function SearchBar({ placeholder, defaultValue, name = "q" }: { placeholder: string; defaultValue?: string; name?: string }) {
  return (
    <div className="flex flex-wrap gap-2">
      <input
        name={name}
        defaultValue={defaultValue}
        placeholder={placeholder}
        className="block w-full min-w-[14rem] flex-1 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-teal-600 focus:outline-none focus:ring-2 focus:ring-teal-600/20 sm:max-w-sm"
      />
      <button type="submit" className={btnSecondary}>
        Search
      </button>
    </div>
  );
}

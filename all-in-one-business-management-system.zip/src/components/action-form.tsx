"use client";

// A reusable form. It shows validation errors next to each field and keeps what the user typed if something fails.
import { useActionState, type ReactNode } from "react";
import { btnPrimary, btnSecondary, inputClass, labelClass } from "@/components/ui";
import type { FormState } from "@/lib/form-state";

export type FieldOption = { value: string; label: string };

export type FieldDef = {
  name: string;
  label: string;
  type?:
    | "text"
    | "email"
    | "tel"
    | "number"
    | "date"
    | "datetime-local"
    | "textarea"
    | "select"
    | "checkbox"
    | "password"
    | "file"
    | "heading"
    | "note";
  required?: boolean;
  options?: FieldOption[];
  defaultValue?: string;
  checked?: boolean;
  placeholder?: string;
  help?: string;
  wide?: boolean;
  step?: string;
  min?: string;
  max?: string;
  accept?: string;
  suggestions?: string[];
  rows?: number;
};

export type ActionFn = (prev: FormState, formData: FormData) => Promise<FormState>;

type Props = {
  action: ActionFn;
  fields: FieldDef[];
  submitLabel?: string;
  pendingLabel?: string;
  hidden?: Record<string, string>;
  cancelHref?: string;
  columns?: 1 | 2;
};

export function ActionForm({
  action,
  fields,
  submitLabel = "Save",
  pendingLabel = "Saving…",
  hidden,
  cancelHref,
  columns = 2,
}: Props) {
  const [state, formAction, pending] = useActionState(action, null);
  const hasValues = state?.values !== undefined;

  const valueOf = (field: FieldDef): string =>
    hasValues ? (state?.values?.[field.name] ?? "") : (field.defaultValue ?? "");

  return (
    // The key changes after every submission so the inputs refresh with the returned values.
    <form key={state?.nonce ?? "initial"} action={formAction} className="space-y-4">
      {hidden
        ? Object.entries(hidden).map(([name, value]) => <input key={name} type="hidden" name={name} value={value} />)
        : null}

      {state?.error ? (
        <div role="alert" className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          {state.error}
        </div>
      ) : null}
      {state?.ok && state.message ? (
        <div role="status" className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          {state.message}
        </div>
      ) : null}

      <div className={columns === 2 ? "grid gap-4 sm:grid-cols-2" : "grid gap-4"}>
        {fields.map((field) => {
          if (field.type === "heading") {
            return (
              <h3
                key={field.name}
                className="border-b border-slate-200 pb-1 pt-2 text-sm font-semibold text-slate-900 sm:col-span-2"
              >
                {field.label}
              </h3>
            );
          }
          if (field.type === "note") {
            return (
              <p key={field.name} className="text-sm text-slate-600 sm:col-span-2">
                {field.label}
              </p>
            );
          }

          const id = `field-${field.name}`;
          const error = state?.fieldErrors?.[field.name];
          const errorClass = error ? " !border-red-500" : "";
          const wide = field.wide || field.type === "textarea" || field.type === "file";
          let control: ReactNode;

          if (field.type === "checkbox") {
            const checked = hasValues ? state?.values?.[field.name] === "on" : Boolean(field.checked);
            return (
              <div key={field.name} className={wide ? "sm:col-span-2" : ""}>
                <label htmlFor={id} className="flex items-center gap-2 text-sm text-slate-800">
                  <input
                    id={id}
                    type="checkbox"
                    name={field.name}
                    defaultChecked={checked}
                    className="h-4 w-4 rounded border-slate-300 text-teal-700 focus:ring-teal-600"
                  />
                  {field.label}
                </label>
                {field.help ? <p className="mt-1 text-xs text-slate-500">{field.help}</p> : null}
              </div>
            );
          }

          if (field.type === "select") {
            control = (
              <select
                id={id}
                name={field.name}
                required={field.required}
                defaultValue={valueOf(field)}
                className={inputClass + errorClass}
              >
                {(field.options ?? []).map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            );
          } else if (field.type === "textarea") {
            control = (
              <textarea
                id={id}
                name={field.name}
                required={field.required}
                rows={field.rows ?? 3}
                defaultValue={valueOf(field)}
                placeholder={field.placeholder}
                className={inputClass + errorClass}
              />
            );
          } else if (field.type === "file") {
            control = (
              <input
                id={id}
                type="file"
                name={field.name}
                required={field.required}
                accept={field.accept}
                className="mt-1 block w-full text-sm text-slate-700 file:mr-3 file:rounded-lg file:border-0 file:bg-teal-50 file:px-3 file:py-2 file:text-sm file:font-medium file:text-teal-800 hover:file:bg-teal-100"
              />
            );
          } else {
            const listId = field.suggestions ? `${id}-list` : undefined;
            control = (
              <>
                <input
                  id={id}
                  type={field.type ?? "text"}
                  name={field.name}
                  required={field.required}
                  defaultValue={valueOf(field)}
                  placeholder={field.placeholder}
                  step={field.step}
                  min={field.min}
                  max={field.max}
                  list={listId}
                  autoComplete="off"
                  className={inputClass + errorClass}
                />
                {field.suggestions ? (
                  <datalist id={listId}>
                    {field.suggestions.map((item) => (
                      <option key={item} value={item} />
                    ))}
                  </datalist>
                ) : null}
              </>
            );
          }

          return (
            <div key={field.name} className={wide ? "sm:col-span-2" : ""}>
              <label htmlFor={id} className={labelClass}>
                {field.label}
                {field.required ? <span className="text-red-600"> *</span> : null}
              </label>
              {control}
              {field.help && !error ? <p className="mt-1 text-xs text-slate-500">{field.help}</p> : null}
              {error ? <p className="mt-1 text-xs font-medium text-red-600">{error}</p> : null}
            </div>
          );
        })}
      </div>

      <div className="flex flex-wrap items-center gap-3 pt-2">
        <button type="submit" disabled={pending} className={btnPrimary}>
          {pending ? pendingLabel : submitLabel}
        </button>
        {cancelHref ? (
          <a href={cancelHref} className={btnSecondary}>
            Cancel
          </a>
        ) : null}
      </div>
    </form>
  );
}

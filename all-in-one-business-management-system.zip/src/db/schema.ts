// Database schema for the all-in-one business management system.
// Every business record belongs to one company (company_id), so company data stays separated.
import { sql } from "drizzle-orm";
import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  type AnyPgColumn,
} from "drizzle-orm/pg-core";
import type {
  ActivityType,
  AccountType,
  AttendanceStatus,
  BusinessType,
  CampaignChannel,
  CampaignStatus,
  ChecklistStatus,
  CustomerCategory,
  DocType,
  DocumentCategory,
  DocumentModule,
  EmploymentStatus,
  ExpenseStatus,
  FollowUpStatus,
  GlobalRole,
  InvoiceStatus,
  LeadSource,
  LeadStatus,
  LeaveStatus,
  LeaveType,
  PaymentMethod,
  ReceiptKind,
  ReceiptStatus,
  ServiceKind,
  TargetMetric,
  TargetPeriod,
  TargetScope,
  TaskPriority,
  TaskStatus,
  VisaStatus,
} from "@/lib/constants";

// ---------- Helpers ----------
const pk = () => serial("id").primaryKey();
const timestamps = {
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
};
const createdOnly = {
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
};
const money = (name: string) => numeric(name, { precision: 14, scale: 2 });
const percentage = (name: string) => numeric(name, { precision: 5, scale: 2 });
const companyRef = () =>
  integer("company_id")
    .notNull()
    .references(() => companies.id, { onDelete: "restrict" });
const userRef = (name: string) => integer(name).references(() => users.id, { onDelete: "set null" });

// ---------- Identity and access ----------
export const users = pgTable(
  "users",
  {
    id: pk(),
    fullName: text("full_name").notNull(),
    email: text("email").notNull(),
    phone: text("phone"),
    passwordHash: text("password_hash").notNull(),
    globalRole: text("global_role").$type<GlobalRole>().notNull().default("staff"),
    isActive: boolean("is_active").notNull().default(true),
    mustChangePassword: boolean("must_change_password").notNull().default(false),
    failedLoginCount: integer("failed_login_count").notNull().default(0),
    lockedUntil: timestamp("locked_until", { withTimezone: true }),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    ...timestamps,
  },
  (t) => [uniqueIndex("users_email_uq").on(t.email)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(), // SHA-256 hash of the session token. The raw token is never stored.
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    ...createdOnly,
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export const companies = pgTable(
  "companies",
  {
    id: pk(),
    name: text("name").notNull(),
    legalName: text("legal_name"),
    businessType: text("business_type").$type<BusinessType>().notNull().default("general"),
    registrationNo: text("registration_no"),
    taxId: text("tax_id"),
    address: text("address"),
    city: text("city"),
    phone: text("phone"),
    email: text("email"),
    website: text("website"),
    brandColor: text("brand_color").notNull().default("#0f766e"),
    logoDocumentId: integer("logo_document_id"),
    currency: text("currency").notNull().default("BDT"),
    financialYearStartMonth: integer("fy_start_month").notNull().default(7),
    invoicePrefix: text("invoice_prefix").notNull().default("INV"),
    quotationPrefix: text("quotation_prefix").notNull().default("QTN"),
    receiptPrefix: text("receipt_prefix").notNull().default("RCT"),
    visaPrefix: text("visa_prefix").notNull().default("VISA"),
    invoiceFooter: text("invoice_footer"),
    receiptFooter: text("receipt_footer"),
    shiftStart: text("shift_start").notNull().default("09:00"),
    shiftEnd: text("shift_end").notNull().default("18:00"),
    graceMinutes: integer("grace_minutes").notNull().default(10),
    enabledModules: jsonb("enabled_modules")
      .$type<string[]>()
      .notNull()
      .default(sql`'[]'::jsonb`),
    isActive: boolean("is_active").notNull().default(true),
    createdById: userRef("created_by_id"),
    ...timestamps,
  },
  (t) => [uniqueIndex("companies_name_uq").on(t.name)],
);

export const branches = pgTable(
  "branches",
  {
    id: pk(),
    companyId: companyRef(),
    name: text("name").notNull(),
    address: text("address"),
    phone: text("phone"),
    isActive: boolean("is_active").notNull().default(true),
    ...timestamps,
  },
  (t) => [uniqueIndex("branches_company_name_uq").on(t.companyId, t.name)],
);

export const departments = pgTable(
  "departments",
  {
    id: pk(),
    companyId: companyRef(),
    name: text("name").notNull(),
    description: text("description"),
    isActive: boolean("is_active").notNull().default(true),
    ...timestamps,
  },
  (t) => [uniqueIndex("departments_company_name_uq").on(t.companyId, t.name)],
);

export const roles = pgTable(
  "roles",
  {
    id: pk(),
    key: text("key").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    permissions: jsonb("permissions")
      .$type<string[]>()
      .notNull()
      .default(sql`'[]'::jsonb`),
    isSystem: boolean("is_system").notNull().default(false),
    isActive: boolean("is_active").notNull().default(true),
    ...timestamps,
  },
  (t) => [uniqueIndex("roles_key_uq").on(t.key)],
);

export type AccessOverrides = { grant: string[]; revoke: string[] };

export const userCompanyAccess = pgTable(
  "user_company_access",
  {
    id: pk(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    companyId: companyRef(),
    roleId: integer("role_id")
      .notNull()
      .references(() => roles.id, { onDelete: "restrict" }),
    branchId: integer("branch_id").references(() => branches.id, { onDelete: "set null" }),
    departmentId: integer("department_id").references(() => departments.id, { onDelete: "set null" }),
    overrides: jsonb("overrides")
      .$type<AccessOverrides>()
      .notNull()
      .default(sql`'{"grant":[],"revoke":[]}'::jsonb`),
    isActive: boolean("is_active").notNull().default(true),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("uca_user_company_uq").on(t.userId, t.companyId),
    index("uca_company_idx").on(t.companyId),
  ],
);

export const numberSequences = pgTable(
  "number_sequences",
  {
    id: pk(),
    companyId: companyRef(),
    key: text("key").notNull(),
    lastNumber: integer("last_number").notNull().default(0),
  },
  (t) => [uniqueIndex("number_sequences_uq").on(t.companyId, t.key)],
);

// ---------- CRM ----------
export const campaigns = pgTable(
  "campaigns",
  {
    id: pk(),
    companyId: companyRef(),
    name: text("name").notNull(),
    channel: text("channel").$type<CampaignChannel>().notNull().default("facebook"),
    objective: text("objective"),
    startDate: date("start_date", { mode: "string" }),
    endDate: date("end_date", { mode: "string" }),
    budget: money("budget").notNull().default("0"),
    status: text("status").$type<CampaignStatus>().notNull().default("planned"),
    ownerUserId: userRef("owner_user_id"),
    notes: text("notes"),
    createdById: userRef("created_by_id"),
    ...timestamps,
  },
  (t) => [index("campaigns_company_idx").on(t.companyId)],
);

export const customers = pgTable(
  "customers",
  {
    id: pk(),
    companyId: companyRef(),
    code: text("code").notNull(),
    fullName: text("full_name").notNull(),
    phone: text("phone"),
    altPhone: text("alt_phone"),
    email: text("email"),
    address: text("address"),
    city: text("city"),
    country: text("country"),
    nationality: text("nationality"),
    dateOfBirth: date("date_of_birth", { mode: "string" }),
    occupation: text("occupation"),
    category: text("category").$type<CustomerCategory>().notNull().default("individual"),
    leadSource: text("lead_source").$type<LeadSource>(),
    interestedService: text("interested_service"),
    passportNumber: text("passport_number"),
    passportExpiry: date("passport_expiry", { mode: "string" }),
    branchId: integer("branch_id").references(() => branches.id, { onDelete: "set null" }),
    assignedUserId: userRef("assigned_user_id"),
    consentMarketing: boolean("consent_marketing").notNull().default(false),
    notes: text("notes"),
    isArchived: boolean("is_archived").notNull().default(false),
    createdById: userRef("created_by_id"),
    updatedById: userRef("updated_by_id"),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("customers_company_code_uq").on(t.companyId, t.code),
    index("customers_company_phone_idx").on(t.companyId, t.phone),
    index("customers_company_email_idx").on(t.companyId, t.email),
    index("customers_company_name_idx").on(t.companyId, t.fullName),
  ],
);

export const leads = pgTable(
  "leads",
  {
    id: pk(),
    companyId: companyRef(),
    code: text("code").notNull(),
    fullName: text("full_name").notNull(),
    phone: text("phone"),
    email: text("email"),
    city: text("city"),
    leadSource: text("lead_source").$type<LeadSource>().notNull().default("other"),
    interestedService: text("interested_service"),
    campaignId: integer("campaign_id").references(() => campaigns.id, { onDelete: "set null" }),
    status: text("status").$type<LeadStatus>().notNull().default("new"),
    expectedValue: money("expected_value").notNull().default("0"),
    branchId: integer("branch_id").references(() => branches.id, { onDelete: "set null" }),
    assignedUserId: userRef("assigned_user_id"),
    lostReason: text("lost_reason"),
    notes: text("notes"),
    customerId: integer("customer_id").references(() => customers.id, { onDelete: "set null" }),
    convertedAt: timestamp("converted_at", { withTimezone: true }),
    createdById: userRef("created_by_id"),
    updatedById: userRef("updated_by_id"),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("leads_company_code_uq").on(t.companyId, t.code),
    index("leads_company_status_idx").on(t.companyId, t.status),
    index("leads_company_phone_idx").on(t.companyId, t.phone),
    index("leads_company_assigned_idx").on(t.companyId, t.assignedUserId),
  ],
);

export const followUps = pgTable(
  "follow_ups",
  {
    id: pk(),
    companyId: companyRef(),
    leadId: integer("lead_id").references(() => leads.id, { onDelete: "cascade" }),
    customerId: integer("customer_id").references(() => customers.id, { onDelete: "cascade" }),
    assignedUserId: userRef("assigned_user_id"),
    title: text("title").notNull(),
    notes: text("notes"),
    dueAt: timestamp("due_at", { withTimezone: true }).notNull(),
    status: text("status").$type<FollowUpStatus>().notNull().default("open"),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdById: userRef("created_by_id"),
    ...timestamps,
  },
  (t) => [
    index("follow_ups_company_status_idx").on(t.companyId, t.status, t.dueAt),
    index("follow_ups_assigned_idx").on(t.assignedUserId, t.status),
  ],
);

export const activities = pgTable(
  "activities",
  {
    id: pk(),
    companyId: companyRef(),
    leadId: integer("lead_id").references(() => leads.id, { onDelete: "cascade" }),
    customerId: integer("customer_id").references(() => customers.id, { onDelete: "cascade" }),
    visaApplicationId: integer("visa_application_id").references(() => visaApplications.id, { onDelete: "cascade" }),
    type: text("type").$type<ActivityType>().notNull(),
    summary: text("summary").notNull(),
    details: text("details"),
    createdById: userRef("created_by_id"),
    ...createdOnly,
  },
  (t) => [
    index("activities_company_customer_idx").on(t.companyId, t.customerId),
    index("activities_company_lead_idx").on(t.companyId, t.leadId),
  ],
);

export const services = pgTable(
  "services",
  {
    id: pk(),
    companyId: companyRef(),
    kind: text("kind").$type<ServiceKind>().notNull().default("service"),
    name: text("name").notNull(),
    category: text("category"),
    description: text("description"),
    unitPrice: money("unit_price").notNull().default("0"),
    taxRate: percentage("tax_rate").notNull().default("0"),
    unitLabel: text("unit_label").notNull().default("each"),
    isActive: boolean("is_active").notNull().default(true),
    ...timestamps,
  },
  (t) => [index("services_company_idx").on(t.companyId)],
);

// ---------- Sales documents and invoices ----------
export const invoices = pgTable(
  "invoices",
  {
    id: pk(),
    companyId: companyRef(),
    branchId: integer("branch_id").references(() => branches.id, { onDelete: "set null" }),
    customerId: integer("customer_id")
      .notNull()
      .references(() => customers.id, { onDelete: "restrict" }),
    visaApplicationId: integer("visa_application_id").references(() => visaApplications.id, { onDelete: "set null" }),
    docType: text("doc_type").$type<DocType>().notNull(),
    number: text("number").notNull(),
    status: text("status").$type<InvoiceStatus>().notNull(),
    issueDate: date("issue_date", { mode: "string" }).notNull(),
    dueDate: date("due_date", { mode: "string" }),
    serviceReference: text("service_reference"),
    subtotal: money("subtotal").notNull().default("0"),
    discountAmount: money("discount_amount").notNull().default("0"),
    taxAmount: money("tax_amount").notNull().default("0"),
    total: money("total").notNull().default("0"),
    paidAmount: money("paid_amount").notNull().default("0"),
    dueAmount: money("due_amount").notNull().default("0"),
    currency: text("currency").notNull().default("BDT"),
    sourceQuotationId: integer("source_quotation_id"),
    notes: text("notes"),
    terms: text("terms"),
    cancelReason: text("cancel_reason"),
    cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
    cancelledById: userRef("cancelled_by_id"),
    createdById: userRef("created_by_id"),
    updatedById: userRef("updated_by_id"),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("invoices_company_doc_number_uq").on(t.companyId, t.docType, t.number),
    index("invoices_company_status_idx").on(t.companyId, t.status),
    index("invoices_company_customer_idx").on(t.companyId, t.customerId),
    index("invoices_company_issue_idx").on(t.companyId, t.issueDate),
  ],
);

export const invoiceItems = pgTable(
  "invoice_items",
  {
    id: pk(),
    invoiceId: integer("invoice_id")
      .notNull()
      .references(() => invoices.id, { onDelete: "cascade" }),
    serviceId: integer("service_id").references(() => services.id, { onDelete: "set null" }),
    description: text("description").notNull(),
    quantity: numeric("quantity", { precision: 12, scale: 2 }).notNull().default("1"),
    unitPrice: money("unit_price").notNull().default("0"),
    discountAmount: money("discount_amount").notNull().default("0"),
    taxRate: percentage("tax_rate").notNull().default("0"),
    taxAmount: money("tax_amount").notNull().default("0"),
    lineTotal: money("line_total").notNull().default("0"),
    sortOrder: integer("sort_order").notNull().default(0),
  },
  (t) => [index("invoice_items_invoice_idx").on(t.invoiceId)],
);

// ---------- Cash, bank and receipts ----------
export const cashAccounts = pgTable(
  "cash_accounts",
  {
    id: pk(),
    companyId: companyRef(),
    name: text("name").notNull(),
    accountType: text("account_type").$type<AccountType>().notNull().default("cash"),
    providerName: text("provider_name"),
    accountNumberMasked: text("account_number_masked"),
    openingBalance: money("opening_balance").notNull().default("0"),
    isActive: boolean("is_active").notNull().default(true),
    ...timestamps,
  },
  (t) => [uniqueIndex("cash_accounts_company_name_uq").on(t.companyId, t.name)],
);

export const accountTransfers = pgTable(
  "account_transfers",
  {
    id: pk(),
    companyId: companyRef(),
    fromAccountId: integer("from_account_id")
      .notNull()
      .references(() => cashAccounts.id, { onDelete: "restrict" }),
    toAccountId: integer("to_account_id")
      .notNull()
      .references(() => cashAccounts.id, { onDelete: "restrict" }),
    amount: money("amount").notNull(),
    transferDate: date("transfer_date", { mode: "string" }).notNull(),
    reference: text("reference"),
    notes: text("notes"),
    createdById: userRef("created_by_id"),
    ...createdOnly,
  },
  (t) => [index("account_transfers_company_idx").on(t.companyId)],
);

export const receipts = pgTable(
  "receipts",
  {
    id: pk(),
    companyId: companyRef(),
    branchId: integer("branch_id").references(() => branches.id, { onDelete: "set null" }),
    customerId: integer("customer_id")
      .notNull()
      .references(() => customers.id, { onDelete: "restrict" }),
    accountId: integer("account_id").references(() => cashAccounts.id, { onDelete: "set null" }),
    number: text("number").notNull(),
    kind: text("kind").$type<ReceiptKind>().notNull().default("payment"),
    status: text("status").$type<ReceiptStatus>().notNull().default("active"),
    receiptDate: date("receipt_date", { mode: "string" }).notNull(),
    amount: money("amount").notNull(),
    paymentMethod: text("payment_method").$type<PaymentMethod>().notNull(),
    transactionRef: text("transaction_ref"),
    receivedByName: text("received_by_name"),
    notes: text("notes"),
    formToken: text("form_token"),
    reprintCount: integer("reprint_count").notNull().default(0),
    cancelReason: text("cancel_reason"),
    cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
    cancelledById: userRef("cancelled_by_id"),
    createdById: userRef("created_by_id"),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("receipts_company_number_uq").on(t.companyId, t.number),
    uniqueIndex("receipts_company_form_token_uq").on(t.companyId, t.formToken),
    uniqueIndex("receipts_company_txn_uq")
      .on(t.companyId, t.transactionRef)
      .where(sql`status = 'active' and transaction_ref is not null`),
    index("receipts_company_date_idx").on(t.companyId, t.receiptDate),
    index("receipts_company_customer_idx").on(t.companyId, t.customerId),
  ],
);

export const paymentAllocations = pgTable(
  "payment_allocations",
  {
    id: pk(),
    companyId: companyRef(),
    receiptId: integer("receipt_id")
      .notNull()
      .references(() => receipts.id, { onDelete: "cascade" }),
    invoiceId: integer("invoice_id")
      .notNull()
      .references(() => invoices.id, { onDelete: "restrict" }),
    amount: money("amount").notNull(),
    createdById: userRef("created_by_id"),
    ...createdOnly,
  },
  (t) => [
    index("payment_allocations_invoice_idx").on(t.invoiceId),
    index("payment_allocations_receipt_idx").on(t.receiptId),
  ],
);

export const expenseCategories = pgTable(
  "expense_categories",
  {
    id: pk(),
    companyId: companyRef(),
    name: text("name").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    ...createdOnly,
  },
  (t) => [uniqueIndex("expense_categories_company_name_uq").on(t.companyId, t.name)],
);

export const expenses = pgTable(
  "expenses",
  {
    id: pk(),
    companyId: companyRef(),
    branchId: integer("branch_id").references(() => branches.id, { onDelete: "set null" }),
    categoryId: integer("category_id")
      .notNull()
      .references(() => expenseCategories.id, { onDelete: "restrict" }),
    campaignId: integer("campaign_id").references(() => campaigns.id, { onDelete: "set null" }),
    accountId: integer("account_id").references(() => cashAccounts.id, { onDelete: "set null" }),
    expenseDate: date("expense_date", { mode: "string" }).notNull(),
    amount: money("amount").notNull(),
    payeeName: text("payee_name"),
    description: text("description").notNull(),
    paymentMethod: text("payment_method").$type<PaymentMethod>().notNull().default("cash"),
    reference: text("reference"),
    status: text("status").$type<ExpenseStatus>().notNull().default("pending"),
    decidedById: userRef("decided_by_id"),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
    decisionNote: text("decision_note"),
    createdById: userRef("created_by_id"),
    ...timestamps,
  },
  (t) => [
    index("expenses_company_status_idx").on(t.companyId, t.status),
    index("expenses_company_date_idx").on(t.companyId, t.expenseDate),
  ],
);

// ---------- Visa management ----------
export const visaApplications = pgTable(
  "visa_applications",
  {
    id: pk(),
    companyId: companyRef(),
    branchId: integer("branch_id").references(() => branches.id, { onDelete: "set null" }),
    customerId: integer("customer_id")
      .notNull()
      .references(() => customers.id, { onDelete: "restrict" }),
    code: text("code").notNull(),
    destinationCountry: text("destination_country").notNull(),
    visaCategory: text("visa_category").notNull(),
    travelPurpose: text("travel_purpose"),
    travelDate: date("travel_date", { mode: "string" }),
    returnDate: date("return_date", { mode: "string" }),
    embassy: text("embassy"),
    applicationDate: date("application_date", { mode: "string" }).notNull(),
    submissionDate: date("submission_date", { mode: "string" }),
    appointmentAt: timestamp("appointment_at", { withTimezone: true }),
    status: text("status").$type<VisaStatus>().notNull().default("new"),
    statusNote: text("status_note"),
    refusalReason: text("refusal_reason"),
    approvalDate: date("approval_date", { mode: "string" }),
    validFrom: date("valid_from", { mode: "string" }),
    validUntil: date("valid_until", { mode: "string" }),
    passportDeliveredAt: timestamp("passport_delivered_at", { withTimezone: true }),
    assignedUserId: userRef("assigned_user_id"),
    serviceFee: money("service_fee").notNull().default("0"),
    notes: text("notes"),
    createdById: userRef("created_by_id"),
    updatedById: userRef("updated_by_id"),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("visa_company_code_uq").on(t.companyId, t.code),
    index("visa_company_status_idx").on(t.companyId, t.status),
    index("visa_company_customer_idx").on(t.companyId, t.customerId),
    index("visa_company_appointment_idx").on(t.companyId, t.appointmentAt),
  ],
);

export const visaStatusHistory = pgTable(
  "visa_status_history",
  {
    id: pk(),
    visaApplicationId: integer("visa_application_id")
      .notNull()
      .references(() => visaApplications.id, { onDelete: "cascade" }),
    fromStatus: text("from_status"),
    toStatus: text("to_status").$type<VisaStatus>().notNull(),
    note: text("note"),
    changedById: userRef("changed_by_id"),
    ...createdOnly,
  },
  (t) => [index("visa_history_application_idx").on(t.visaApplicationId)],
);

export const visaChecklistItems = pgTable(
  "visa_checklist_items",
  {
    id: pk(),
    visaApplicationId: integer("visa_application_id")
      .notNull()
      .references(() => visaApplications.id, { onDelete: "cascade" }),
    label: text("label").notNull(),
    isRequired: boolean("is_required").notNull().default(true),
    status: text("status").$type<ChecklistStatus>().notNull().default("pending"),
    verifiedById: userRef("verified_by_id"),
    verifiedAt: timestamp("verified_at", { withTimezone: true }),
    sortOrder: integer("sort_order").notNull().default(0),
    ...createdOnly,
  },
  (t) => [index("visa_checklist_application_idx").on(t.visaApplicationId)],
);

// ---------- Documents (private files) ----------
export const documents = pgTable(
  "documents",
  {
    id: pk(),
    companyId: companyRef(),
    module: text("module").$type<DocumentModule>().notNull(),
    category: text("category").$type<DocumentCategory>().notNull(),
    title: text("title").notNull(),
    fileName: text("file_name").notNull(),
    mimeType: text("mime_type").notNull(),
    sizeBytes: integer("size_bytes").notNull(),
    storageKey: text("storage_key").notNull(),
    isSensitive: boolean("is_sensitive").notNull().default(false),
    customerId: integer("customer_id").references(() => customers.id, { onDelete: "set null" }),
    visaApplicationId: integer("visa_application_id").references(() => visaApplications.id, { onDelete: "set null" }),
    employeeId: integer("employee_id").references(() => employees.id, { onDelete: "set null" }),
    expenseId: integer("expense_id").references(() => expenses.id, { onDelete: "set null" }),
    uploadedById: userRef("uploaded_by_id"),
    ...createdOnly,
  },
  (t) => [
    uniqueIndex("documents_storage_key_uq").on(t.storageKey),
    index("documents_company_module_idx").on(t.companyId, t.module),
    index("documents_company_customer_idx").on(t.companyId, t.customerId),
  ],
);

// ---------- HR ----------
export const employees = pgTable(
  "employees",
  {
    id: pk(),
    companyId: companyRef(),
    code: text("code").notNull(),
    userId: userRef("user_id"),
    fullName: text("full_name").notNull(),
    phone: text("phone"),
    email: text("email"),
    address: text("address"),
    nationalId: text("national_id"),
    dateOfBirth: date("date_of_birth", { mode: "string" }),
    branchId: integer("branch_id").references(() => branches.id, { onDelete: "set null" }),
    departmentId: integer("department_id").references(() => departments.id, { onDelete: "set null" }),
    designation: text("designation").notNull(),
    joinDate: date("join_date", { mode: "string" }).notNull(),
    employmentStatus: text("employment_status").$type<EmploymentStatus>().notNull().default("active"),
    reportingManagerId: integer("reporting_manager_id").references((): AnyPgColumn => employees.id, {
      onDelete: "set null",
    }),
    basicSalary: money("basic_salary").notNull().default("0"),
    notes: text("notes"),
    createdById: userRef("created_by_id"),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("employees_company_code_uq").on(t.companyId, t.code),
    index("employees_company_status_idx").on(t.companyId, t.employmentStatus),
  ],
);

export const attendance = pgTable(
  "attendance",
  {
    id: pk(),
    companyId: companyRef(),
    employeeId: integer("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    attendanceDate: date("attendance_date", { mode: "string" }).notNull(),
    status: text("status").$type<AttendanceStatus>().notNull(),
    checkIn: text("check_in"),
    checkOut: text("check_out"),
    lateMinutes: integer("late_minutes").notNull().default(0),
    earlyLeaveMinutes: integer("early_leave_minutes").notNull().default(0),
    notes: text("notes"),
    recordedById: userRef("recorded_by_id"),
    ...timestamps,
  },
  (t) => [
    uniqueIndex("attendance_employee_date_uq").on(t.employeeId, t.attendanceDate),
    index("attendance_company_date_idx").on(t.companyId, t.attendanceDate),
  ],
);

export const leaveRequests = pgTable(
  "leave_requests",
  {
    id: pk(),
    companyId: companyRef(),
    employeeId: integer("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    leaveType: text("leave_type").$type<LeaveType>().notNull(),
    startDate: date("start_date", { mode: "string" }).notNull(),
    endDate: date("end_date", { mode: "string" }).notNull(),
    days: integer("days").notNull(),
    reason: text("reason"),
    status: text("status").$type<LeaveStatus>().notNull().default("pending"),
    decidedById: userRef("decided_by_id"),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
    decisionNote: text("decision_note"),
    createdById: userRef("created_by_id"),
    ...timestamps,
  },
  (t) => [
    index("leave_company_status_idx").on(t.companyId, t.status),
    index("leave_employee_idx").on(t.employeeId),
  ],
);

// ---------- Targets, tasks and campaign tracking ----------
export const targets = pgTable(
  "targets",
  {
    id: pk(),
    companyId: companyRef(),
    label: text("label").notNull(),
    scopeType: text("scope_type").$type<TargetScope>().notNull(),
    scopeId: integer("scope_id"),
    metric: text("metric").$type<TargetMetric>().notNull(),
    periodType: text("period_type").$type<TargetPeriod>().notNull(),
    periodStart: date("period_start", { mode: "string" }).notNull(),
    periodEnd: date("period_end", { mode: "string" }).notNull(),
    targetValue: money("target_value").notNull(),
    createdById: userRef("created_by_id"),
    ...timestamps,
  },
  (t) => [index("targets_company_idx").on(t.companyId)],
);

export const tasks = pgTable(
  "tasks",
  {
    id: pk(),
    companyId: companyRef(),
    title: text("title").notNull(),
    description: text("description"),
    priority: text("priority").$type<TaskPriority>().notNull().default("medium"),
    status: text("status").$type<TaskStatus>().notNull().default("todo"),
    assignedUserId: userRef("assigned_user_id"),
    dueDate: date("due_date", { mode: "string" }),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdById: userRef("created_by_id"),
    ...timestamps,
  },
  (t) => [
    index("tasks_company_status_idx").on(t.companyId, t.status),
    index("tasks_company_assigned_idx").on(t.companyId, t.assignedUserId),
  ],
);

// ---------- Notifications and audit ----------
export const notifications = pgTable(
  "notifications",
  {
    id: pk(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    companyId: integer("company_id").references(() => companies.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    body: text("body"),
    link: text("link"),
    isRead: boolean("is_read").notNull().default(false),
    ...createdOnly,
  },
  (t) => [index("notifications_user_idx").on(t.userId, t.isRead)],
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: pk(),
    companyId: integer("company_id").references(() => companies.id, { onDelete: "set null" }),
    userId: userRef("user_id"),
    action: text("action").notNull(),
    entityType: text("entity_type").notNull(),
    entityId: text("entity_id"),
    summary: text("summary").notNull(),
    ...createdOnly,
  },
  (t) => [index("audit_company_created_idx").on(t.companyId, t.createdAt), index("audit_user_idx").on(t.userId)],
);

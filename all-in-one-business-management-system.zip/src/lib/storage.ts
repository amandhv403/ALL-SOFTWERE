// Private file storage. Files are saved outside the public folder with random names.
// They are only delivered through login-protected routes after a permission check.
import { randomBytes } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { AppError } from "@/lib/action";

export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;
export const UPLOAD_ACCEPT = ".pdf,.jpg,.jpeg,.png,.webp";

export function storageRoot(): string {
  const configured = process.env.UPLOAD_DIR;
  return configured ? path.resolve(configured) : path.join(process.cwd(), "storage", "private-uploads");
}

/** Checks the real file signature (not just the file name) so disguised files are rejected. */
export function detectFileType(buffer: Buffer): { mime: string; ext: string } | null {
  if (buffer.length >= 4 && buffer.subarray(0, 4).toString("ascii") === "%PDF") {
    return { mime: "application/pdf", ext: "pdf" };
  }
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return { mime: "image/jpeg", ext: "jpg" };
  }
  const pngSignature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(pngSignature)) {
    return { mime: "image/png", ext: "png" };
  }
  if (
    buffer.length >= 12 &&
    buffer.subarray(0, 4).toString("ascii") === "RIFF" &&
    buffer.subarray(8, 12).toString("ascii") === "WEBP"
  ) {
    return { mime: "image/webp", ext: "webp" };
  }
  return null;
}

export function sanitizeFileName(name: string): string {
  const cleaned = name.replace(/[^\w.\- ()]/g, "_").replace(/\s+/g, " ").trim();
  return cleaned.slice(0, 120) || "file";
}

export async function saveUpload(
  file: File,
): Promise<{ storageKey: string; mimeType: string; sizeBytes: number; fileName: string }> {
  if (file.size === 0) throw new AppError("The selected file is empty.");
  if (file.size > MAX_UPLOAD_BYTES) throw new AppError("The file is too large. The maximum size is 10 MB.");
  const buffer = Buffer.from(await file.arrayBuffer());
  const type = detectFileType(buffer);
  if (!type) {
    throw new AppError("This file type is not allowed. Please upload a PDF, JPG, PNG or WEBP file.");
  }
  const storageKey = `${randomBytes(24).toString("hex")}.${type.ext}`;
  const dir = storageRoot();
  await mkdir(dir, { recursive: true });
  // The turbopackIgnore comment tells the bundler that this path is a runtime location, not a source file.
  await writeFile(path.join(/*turbopackIgnore: true*/ dir, storageKey), buffer, { mode: 0o600 });
  return { storageKey, mimeType: type.mime, sizeBytes: buffer.length, fileName: sanitizeFileName(file.name) };
}

export async function readUpload(storageKey: string): Promise<Buffer> {
  if (!/^[a-f0-9]{48}\.(pdf|jpg|png|webp)$/.test(storageKey)) {
    throw new AppError("Invalid file reference.");
  }
  return readFile(path.join(/*turbopackIgnore: true*/ storageRoot(), storageKey));
}

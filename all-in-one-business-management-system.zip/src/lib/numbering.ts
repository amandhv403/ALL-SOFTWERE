// Company-specific document numbers (invoice, receipt, customer and so on).
// Numbers come from an atomic counter that only moves forward. Cancelled documents keep their number,
// so a number is never reused.
import { sql } from "drizzle-orm";
import type { db } from "@/db";

export type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

/** Takes the next number from a company counter. Must be called inside a transaction. */
export async function nextSequence(tx: Tx, companyId: number, key: string): Promise<number> {
  const result = await tx.execute(sql`
    insert into number_sequences (company_id, key, last_number)
    values (${companyId}, ${key}, 1)
    on conflict (company_id, key)
    do update set last_number = number_sequences.last_number + 1
    returning last_number
  `);
  const row = (result.rows as { last_number: number }[])[0];
  return Number(row.last_number);
}

export function formatDocNumber(prefix: string, sequence: number, width = 5): string {
  return `${prefix}-${String(sequence).padStart(width, "0")}`;
}

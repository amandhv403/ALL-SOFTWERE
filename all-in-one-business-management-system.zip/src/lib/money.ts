// Decimal-safe money helpers.
// Amounts are stored in PostgreSQL as NUMERIC(14,2). In the application they are
// handled as whole "cents" (integers) so additions, discounts and taxes never drift.

export type Cents = number;

const DECIMAL_PATTERN = /^-?\d+(\.\d{1,2})?$/;

/** Converts user input such as "1,250.5" into cents (125050). Returns null when invalid. */
export function parseToCents(input: unknown): Cents | null {
  if (input === null || input === undefined) return null;
  const raw = String(input).trim().replace(/,/g, "");
  if (raw === "" || !DECIMAL_PATTERN.test(raw)) return null;
  const negative = raw.startsWith("-");
  const unsigned = negative ? raw.slice(1) : raw;
  const [whole, fraction = ""] = unsigned.split(".");
  const cents = Number(whole) * 100 + Number(`${fraction}00`.slice(0, 2));
  return negative ? -cents : cents;
}

/** Converts cents into a database-ready decimal string such as "1250.50". */
export function centsToDb(cents: Cents): string {
  const abs = Math.abs(Math.round(cents));
  const text = `${Math.floor(abs / 100)}.${String(abs % 100).padStart(2, "0")}`;
  return cents < 0 ? `-${text}` : text;
}

/** Converts a database decimal (string or number) into cents. */
export function dbToCents(value: string | number | null | undefined): Cents {
  if (value === null || value === undefined || value === "") return 0;
  return parseToCents(value) ?? Math.round(Number(value) * 100);
}

/**
 * Calculates one invoice line.
 * quantityHundredths: quantity x 100 (e.g. 1.5 -> 150).
 * unitCents: unit price in cents.
 * taxHundredths: tax percentage x 100 (e.g. 15% -> 1500).
 */
export function lineTotals(quantityHundredths: number, unitCents: Cents, taxHundredths: number) {
  const gross = Math.round((quantityHundredths * unitCents) / 100);
  const tax = Math.round((gross * taxHundredths) / 10000);
  return { gross, tax, total: gross + tax };
}

export function sumCents(values: Cents[]): Cents {
  return values.reduce((total, value) => total + value, 0);
}

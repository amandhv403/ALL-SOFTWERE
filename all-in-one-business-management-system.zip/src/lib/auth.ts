// Authentication: password hashing, login sessions and the current signed-in user.
import { createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { cookies, headers } from "next/headers";
import { cache } from "react";
import { and, eq, gt, ne } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import type { GlobalRole } from "@/lib/constants";

const scryptAsync = promisify(scryptCallback) as unknown as (
  password: string,
  salt: Buffer,
  keylen: number,
  options: { N: number; r: number; p: number; maxmem: number },
) => Promise<Buffer>;

const SCRYPT_OPTIONS = { N: 16384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };
const KEY_LENGTH = 64;

/** Hashes a password with scrypt and a random salt. Plain-text passwords are never stored. */
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await scryptAsync(password, salt, KEY_LENGTH, SCRYPT_OPTIONS);
  return `scrypt$${salt.toString("base64")}$${key.toString("base64")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [algorithm, saltText, hashText] = stored.split("$");
  if (algorithm !== "scrypt" || !saltText || !hashText) return false;
  const expected = Buffer.from(hashText, "base64");
  const actual = await scryptAsync(password, Buffer.from(saltText, "base64"), expected.length, SCRYPT_OPTIONS);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export const passwordSchema = z
  .string()
  .min(10, "Password must be at least 10 characters long.")
  .max(128, "Password must be 128 characters or fewer.")
  .refine((value) => /[A-Za-z]/.test(value) && /\d/.test(value), {
    message: "Password must include at least one letter and one number.",
  });

export const SESSION_COOKIE = "bms_session";
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;

export type SessionUser = {
  id: number;
  fullName: string;
  email: string;
  globalRole: GlobalRole;
  mustChangePassword: boolean;
  isActive: boolean;
};

function hashToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

/** Cookies are marked Secure when the site is reached over HTTPS. */
export async function isSecureRequest(): Promise<boolean> {
  const requestHeaders = await headers();
  return requestHeaders.get("x-forwarded-proto") === "https" || process.env.COOKIE_SECURE === "true";
}

/**
 * True when FRAME_ANCESTORS is set, which means the application is shown inside another website's
 * window (the Arena Code preview). Browsers then treat the sign-in cookie as "cross-site", so it must be
 * SameSite=None, Secure and Partitioned to keep people signed in inside that window.
 * On a live site (FRAME_ANCESTORS empty) the stricter SameSite=Lax cookie is used.
 */
export function isFramedPreview(): boolean {
  return (process.env.FRAME_ANCESTORS ?? "").trim() !== "";
}

type SessionCookieOptions = {
  httpOnly: boolean;
  sameSite: "lax" | "none";
  secure: boolean;
  partitioned: boolean;
  path: string;
  expires?: Date;
};

async function sessionCookieOptions(expires?: Date): Promise<SessionCookieOptions> {
  const framed = isFramedPreview();
  return {
    httpOnly: true,
    sameSite: framed ? "none" : "lax",
    secure: framed ? true : await isSecureRequest(),
    partitioned: framed,
    path: "/",
    ...(expires ? { expires } : {}),
  };
}

export async function createSession(userId: number): Promise<void> {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  await db.insert(sessions).values({ id: hashToken(token), userId, expiresAt });
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, await sessionCookieOptions(expiresAt));
}

export async function currentSessionId(): Promise<string | null> {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  return token ? hashToken(token) : null;
}

/** Returns the signed-in user, or null. Cached for the duration of one request. */
export const getSessionUser = cache(async (): Promise<SessionUser | null> => {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const [row] = await db
    .select({
      id: users.id,
      fullName: users.fullName,
      email: users.email,
      globalRole: users.globalRole,
      mustChangePassword: users.mustChangePassword,
      isActive: users.isActive,
    })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.id, hashToken(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  if (!row || !row.isActive) return null;
  return row;
});

export async function destroyCurrentSession(): Promise<void> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.id, hashToken(token)));
  }
  // Overwrite the cookie with an expired copy that has the same settings, so the browser removes it.
  jar.set(SESSION_COOKIE, "", await sessionCookieOptions(new Date(0)));
}

/** Signs a user out everywhere (for example after a password reset), optionally keeping the current session. */
export async function revokeUserSessions(userId: number, keepSessionId?: string | null): Promise<void> {
  await db
    .delete(sessions)
    .where(and(eq(sessions.userId, userId), keepSessionId ? ne(sessions.id, keepSessionId) : undefined));
}

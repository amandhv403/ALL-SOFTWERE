// Navigation menu definitions. Pure data, used by the sidebar. Access is always checked again on the server.
import type { ActionKey, ModuleKey } from "@/lib/constants";

export type NavItem = { label: string; path: string; module: ModuleKey; action?: ActionKey };
export type NavSection = { title: string; items: NavItem[] };

export const COMPANY_NAV: NavSection[] = [
  {
    title: "Overview",
    items: [{ label: "Company dashboard", path: "", module: "company" }],
  },
  {
    title: "Customers & sales",
    items: [
      { label: "Leads", path: "/crm/leads", module: "crm" },
      { label: "Customers", path: "/crm/customers", module: "crm" },
      { label: "Follow-ups", path: "/crm/followups", module: "crm" },
      { label: "Sales pipeline", path: "/sales/pipeline", module: "sales" },
      { label: "Targets & KPIs", path: "/sales/targets", module: "sales" },
      { label: "Marketing campaigns", path: "/marketing/campaigns", module: "marketing" },
    ],
  },
  {
    title: "Visa",
    items: [{ label: "Visa applications", path: "/visa/applications", module: "visa" }],
  },
  {
    title: "Accounting",
    items: [
      { label: "Invoices & quotations", path: "/accounting/invoices", module: "accounting" },
      { label: "Money receipts", path: "/accounting/receipts", module: "accounting" },
      { label: "Expenses", path: "/accounting/expenses", module: "accounting" },
      { label: "Cash & bank", path: "/accounting/cash-bank", module: "accounting" },
    ],
  },
  {
    title: "People & office",
    items: [
      { label: "Employees", path: "/hr/employees", module: "hr" },
      { label: "Attendance", path: "/hr/attendance", module: "hr" },
      { label: "Leave requests", path: "/hr/leave", module: "hr" },
      { label: "Office tasks", path: "/tasks", module: "tasks" },
    ],
  },
  {
    title: "Insight",
    items: [{ label: "Reports", path: "/reports", module: "reports" }],
  },
  {
    title: "Settings",
    items: [
      { label: "Company profile", path: "/settings", module: "company" },
      { label: "Branches & departments", path: "/settings/structure", module: "company" },
      { label: "Team & access", path: "/team", module: "team" },
    ],
  },
];

export const GLOBAL_NAV: { label: string; href: string }[] = [
  { label: "Owner dashboard", href: "/dashboard" },
  { label: "Companies", href: "/companies" },
  { label: "Notifications", href: "/notifications" },
  { label: "My account", href: "/account" },
];

export const ADMIN_NAV: { label: string; href: string }[] = [
  { label: "Users & logins", href: "/admin/users" },
  { label: "Roles & permissions", href: "/admin/roles" },
  { label: "Audit log", href: "/admin/audit" },
];

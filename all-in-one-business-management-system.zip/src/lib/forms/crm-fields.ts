// Form definitions for leads and customers. Shared by the list pages and the detail pages.
import type { FieldDef } from "@/components/action-form";
import { CUSTOMER_CATEGORY_KEYS, LEAD_SOURCE_KEYS, optionsOf } from "@/lib/constants";

type Option = { value: string; label: string };

export const SERVICE_SUGGESTIONS = [
  "Visa consultation",
  "Visa processing",
  "Air ticket",
  "Umrah package",
  "Tour package",
  "Honeymoon package",
  "Group tour",
  "Study abroad consultation",
  "University admission",
  "Homestay booking",
  "Product order",
  "Session booking",
];

export function leadFieldDefs(input: { members: Option[]; branches: Option[]; campaigns: Option[] }): FieldDef[] {
  return [
    { name: "h-person", label: "Person", type: "heading" },
    { name: "fullName", label: "Full name", required: true, placeholder: "e.g. Nusrat Jahan" },
    { name: "phone", label: "Phone (WhatsApp if possible)", type: "tel", help: "Used to check for duplicates." },
    { name: "email", label: "Email", type: "email" },
    { name: "city", label: "City" },
    { name: "h-interest", label: "Interest and source", type: "heading" },
    { name: "leadSource", label: "Where did this lead come from?", type: "select", options: optionsOf(LEAD_SOURCE_KEYS), defaultValue: "other" },
    { name: "interestedService", label: "Interested service or destination", suggestions: SERVICE_SUGGESTIONS },
    { name: "expectedValue", label: "Expected value (৳)", type: "number", step: "0.01", min: "0", defaultValue: "0" },
    { name: "campaignId", label: "Marketing campaign", type: "select", options: [{ value: "", label: "No campaign" }, ...input.campaigns] },
    { name: "branchId", label: "Branch", type: "select", options: [{ value: "", label: "Not set" }, ...input.branches] },
    { name: "assignedUserId", label: "Assign to", type: "select", options: [{ value: "", label: "Me (default)" }, ...input.members] },
    { name: "notes", label: "Notes", type: "textarea", wide: true },
    {
      name: "allowDuplicate",
      label: "Save even if a similar record already exists",
      type: "checkbox",
      wide: true,
      help: "Only tick this if you are sure it is a different person.",
    },
  ];
}

export function customerFieldDefs(input: {
  members: Option[];
  defaults?: Record<string, string>;
  creating?: boolean;
  /** Passport fields are left off the form for people who may not see passport numbers. */
  includePassport?: boolean;
}): FieldDef[] {
  const d = (name: string) => input.defaults?.[name] ?? "";
  const fields: FieldDef[] = [
    { name: "h-identity", label: "Identity and contact", type: "heading" },
    { name: "fullName", label: "Full name", required: true, defaultValue: d("fullName") },
    { name: "phone", label: "Phone", type: "tel", defaultValue: d("phone") },
    { name: "altPhone", label: "Alternative phone", type: "tel", defaultValue: d("altPhone") },
    { name: "email", label: "Email", type: "email", defaultValue: d("email") },
    { name: "dateOfBirth", label: "Date of birth", type: "date", defaultValue: d("dateOfBirth") },
    { name: "h-address", label: "Address and background", type: "heading" },
    { name: "address", label: "Address", type: "textarea", wide: true, defaultValue: d("address") },
    { name: "city", label: "City", defaultValue: d("city") },
    { name: "country", label: "Country", defaultValue: d("country") || "Bangladesh" },
    { name: "nationality", label: "Nationality", defaultValue: d("nationality") || "Bangladeshi" },
    { name: "occupation", label: "Occupation", defaultValue: d("occupation") },
    { name: "h-travel", label: "Travel documents", type: "heading" },
    { name: "passportNumber", label: "Passport number", defaultValue: d("passportNumber") },
    { name: "passportExpiry", label: "Passport expiry date", type: "date", defaultValue: d("passportExpiry") },
    { name: "h-relationship", label: "Relationship", type: "heading" },
    {
      name: "category",
      label: "Customer category",
      type: "select",
      options: optionsOf(CUSTOMER_CATEGORY_KEYS),
      defaultValue: d("category") || "individual",
    },
    { name: "interestedService", label: "Main interest", suggestions: SERVICE_SUGGESTIONS, defaultValue: d("interestedService") },
    {
      name: "assignedUserId",
      label: "Relationship manager",
      type: "select",
      options: [{ value: "", label: "Not assigned" }, ...input.members],
      defaultValue: d("assignedUserId"),
    },
    { name: "notes", label: "Notes", type: "textarea", wide: true, defaultValue: d("notes") },
    {
      name: "consentMarketing",
      label: "Customer agreed to receive offers and updates",
      type: "checkbox",
      wide: true,
      checked: d("consentMarketing") === "true",
    },
  ];
  if (input.creating) {
    fields.push({
      name: "allowDuplicate",
      label: "Save even if a similar record already exists",
      type: "checkbox",
      wide: true,
      help: "The system checks phone and email. Only tick this if it is a different person.",
    });
  }
  if (input.includePassport === false) {
    return fields.filter((f) => !["h-travel", "passportNumber", "passportExpiry"].includes(f.name));
  }
  return fields;
}

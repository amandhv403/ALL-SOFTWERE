// Audit trail and in-app notifications (server-side only).
import { db } from "@/db";
import { auditLogs, notifications } from "@/db/schema";

export type AuditEntry = {
  companyId?: number | null;
  userId?: number | null;
  action: string;
  entityType: string;
  entityId?: string | number | null;
  summary: string;
};

/** Records an important action (who did what, and when). Audit records are never edited or deleted from the app. */
export async function logAudit(entry: AuditEntry): Promise<void> {
  await db.insert(auditLogs).values({
    companyId: entry.companyId ?? null,
    userId: entry.userId ?? null,
    action: entry.action,
    entityType: entry.entityType,
    entityId: entry.entityId === null || entry.entityId === undefined ? null : String(entry.entityId),
    summary: entry.summary.slice(0, 500),
  });
}

export type NotificationInput = {
  companyId?: number | null;
  title: string;
  body?: string;
  link?: string;
};

export async function notifyMany(userIds: number[], input: NotificationInput, exceptUserId?: number | null): Promise<void> {
  const recipients = [...new Set(userIds)].filter((id) => id !== exceptUserId);
  if (recipients.length === 0) return;
  await db.insert(notifications).values(
    recipients.map((userId) => ({
      userId,
      companyId: input.companyId ?? null,
      title: input.title.slice(0, 200),
      body: input.body ? input.body.slice(0, 1000) : null,
      link: input.link ?? null,
    })),
  );
}

export async function notify(userId: number, input: NotificationInput): Promise<void> {
  await notifyMany([userId], input);
}

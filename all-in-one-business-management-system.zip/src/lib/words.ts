// Converts an amount into English words in the Bangladeshi style (Lakh and Crore), for printed receipts.
const ONES = [
  "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
  "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen",
];
const TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

function underHundred(n: number): string {
  if (n < 20) return ONES[n];
  return `${TENS[Math.floor(n / 10)]}${n % 10 ? ` ${ONES[n % 10]}` : ""}`;
}

function underThousand(n: number): string {
  const hundreds = Math.floor(n / 100);
  const rest = n % 100;
  return [hundreds ? `${ONES[hundreds]} Hundred` : "", rest ? underHundred(rest) : ""].filter(Boolean).join(" ");
}

/** Example: 125000.50 -> "One Lakh Twenty-Five Thousand Taka and Fifty Paisa Only". */
export function amountInWordsBDT(amount: number): string {
  const cents = Math.round(Math.abs(amount) * 100);
  const taka = Math.floor(cents / 100);
  const paisa = cents % 100;
  if (taka === 0 && paisa === 0) return "Zero Taka Only";
  if (taka >= 1_000_000_000) return `${taka} Taka${paisa ? ` and ${underHundred(paisa)} Paisa` : ""} Only`;

  const parts: string[] = [];
  const crore = Math.floor(taka / 10_000_000);
  let rest = taka % 10_000_000;
  const lakh = Math.floor(rest / 100_000);
  rest %= 100_000;
  const thousand = Math.floor(rest / 1_000);
  rest %= 1_000;
  if (crore) parts.push(`${underHundred(crore)} Crore`);
  if (lakh) parts.push(`${underHundred(lakh)} Lakh`);
  if (thousand) parts.push(`${underHundred(thousand)} Thousand`);
  if (rest) parts.push(underThousand(rest));

  let text = `${parts.join(" ")} Taka`;
  if (paisa) text += ` and ${underHundred(paisa)} Paisa`;
  return `${text} Only`;
}

// Permission engine: role templates, per-company access, branch scope and server-side checks.
// Every page and every server action must call one of these helpers. The user interface is never trusted alone.
import { and, asc, count, eq, inArray } from "drizzle-orm";
import type { SQL } from "drizzle-orm";
import type { AnyPgColumn } from "drizzle-orm/pg-core";
import { redirect } from "next/navigation";
import { cache } from "react";
import { db } from "@/db";
import { companies, roles, userCompanyAccess, users, type AccessOverrides } from "@/db/schema";
import { AppError, flashUrl } from "@/lib/action";
import { getSessionUser, type SessionUser } from "@/lib/auth";
import {
  ACTION_KEYS,
  ACTION_LABELS,
  MODULE_KEYS,
  MODULE_LABELS,
  isToggleable,
  type ActionKey,
  type ModuleKey,
} from "@/lib/constants";

export const ALL_PERMISSION_KEYS: string[] = MODULE_KEYS.flatMap((module) =>
  ACTION_KEYS.map((action) => `${module}.${action}`),
);

/** Expands "crm.manage" into every CRM action. Returns a set such as {"crm.view", "crm.create", ...}. */
export function expandPermissions(keys: readonly string[]): Set<string> {
  const out = new Set<string>();
  for (const key of keys) {
    const [module, action] = key.split(".");
    if (!module || !action) continue;
    if (action === "manage") {
      for (const a of ACTION_KEYS) out.add(`${module}.${a}`);
    } else {
      out.add(key);
    }
  }
  return out;
}

/** Applies individual user grants and revokes on top of the role permissions. */
export function applyOverrides(base: Set<string>, overrides: AccessOverrides | null | undefined): Set<string> {
  const out = new Set(base);
  for (const key of expandPermissions(overrides?.grant ?? [])) out.add(key);
  for (const key of expandPermissions(overrides?.revoke ?? [])) out.delete(key);
  return out;
}

// ---------- Built-in role templates ----------
type Grant = Partial<Record<ModuleKey, readonly (ActionKey | "manage")[]>>;

function grantToKeys(grant: Grant): string[] {
  return Object.entries(grant).flatMap(([module, actions]) => (actions ?? []).map((action) => `${module}.${action}`));
}

export const SYSTEM_ROLE_TEMPLATES: { key: string; name: string; description: string; grant: Grant }[] = [
  {
    key: "company_admin",
    name: "Company Administrator",
    description: "Runs one company day to day. Full business control, but no confidential salary access by default.",
    grant: {
      company: ["manage"], team: ["manage"], crm: ["manage"], sales: ["manage"], marketing: ["manage"],
      visa: ["manage"], accounting: ["manage"], hr: ["manage"], tasks: ["manage"], reports: ["manage"],
      documents: ["manage"], audit: ["view"],
    },
  },
  {
    key: "branch_manager",
    name: "Branch Manager",
    description: "Sees only the assigned branch. Approves leave and expenses within the branch.",
    grant: {
      company: ["view"], team: ["view"],
      crm: ["view", "create", "edit", "assign", "print", "export"],
      sales: ["view", "create", "edit", "assign", "print"], marketing: ["view"],
      visa: ["view", "create", "edit", "assign", "print"],
      accounting: ["view", "create", "print", "approve", "reject"],
      hr: ["view", "approve", "reject"], tasks: ["manage"],
      reports: ["view", "export", "print"], documents: ["view", "create"],
    },
  },
  {
    key: "department_manager",
    name: "Department Manager",
    description: "Manages the team inside one department, including tasks and leave decisions.",
    grant: {
      company: ["view"], crm: ["view", "create", "edit", "assign"], sales: ["view", "create", "edit", "assign"],
      marketing: ["view"], visa: ["view", "create", "edit"], accounting: ["view"],
      hr: ["view", "approve", "reject"], tasks: ["manage"], reports: ["view"], documents: ["view", "create"],
    },
  },
  {
    key: "sales_executive",
    name: "Sales Executive",
    description: "Works leads, follow-ups, quotations and targets. Cannot change confirmed financial records.",
    grant: {
      company: ["view"], crm: ["view", "create", "edit", "print"], sales: ["view", "create", "edit", "print"],
      marketing: ["view"], visa: ["view"], accounting: ["view", "create"],
      tasks: ["view", "create", "edit"], reports: ["view"], documents: ["view", "create"],
    },
  },
  {
    key: "marketing_executive",
    name: "Marketing Executive",
    description: "Plans campaigns and tracks leads by source.",
    grant: {
      company: ["view"], crm: ["view", "create"], marketing: ["manage"], sales: ["view"], reports: ["view"],
      tasks: ["view", "create", "edit"], documents: ["view", "create"],
    },
  },
  {
    key: "crm_officer",
    name: "CRM Officer",
    description: "Maintains customer records, lead assignments and follow-ups.",
    grant: {
      company: ["view"], crm: ["view", "create", "edit", "assign", "print"], sales: ["view"],
      tasks: ["view", "create", "edit"], documents: ["view", "create"], reports: ["view"],
    },
  },
  {
    key: "customer_service_officer",
    name: "Customer Service Officer",
    description: "Handles customer enquiries, complaints and tasks.",
    grant: {
      company: ["view"], crm: ["view", "create", "edit"], tasks: ["view", "create", "edit", "assign"],
      documents: ["view", "create"],
    },
  },
  {
    key: "visa_officer",
    name: "Visa Officer",
    description: "Prepares visa files, tracks documents and status, and records embassy outcomes.",
    grant: {
      company: ["view"], visa: ["view", "create", "edit", "assign", "print", "verify"],
      crm: ["view", "create", "edit"], documents: ["view", "create", "verify"], accounting: ["view"],
      tasks: ["view", "create", "edit"],
    },
  },
  {
    key: "education_consultant",
    name: "Education Consultant",
    description: "Counsels students and tracks applications and follow-ups.",
    grant: {
      company: ["view"], crm: ["view", "create", "edit"], sales: ["view"], documents: ["view", "create"],
      tasks: ["view", "create", "edit"],
    },
  },
  {
    key: "document_officer",
    name: "Document Officer",
    description: "Checks, verifies and maintains customer and visa documents.",
    grant: {
      company: ["view"], documents: ["view", "create", "edit", "verify", "delete"], visa: ["view"], crm: ["view"],
    },
  },
  {
    key: "accounts_officer",
    name: "Accounts Officer",
    description: "Creates invoices, receipts and expenses. Cancellations and expense approval need a senior role.",
    grant: {
      company: ["view"], accounting: ["view", "create", "edit", "print", "export", "verify"],
      sales: ["view"], crm: ["view"], reports: ["view", "export", "print"], documents: ["view", "create"],
    },
  },
  {
    key: "hr_officer",
    name: "HR Officer",
    description: "Manages employees, attendance and leave. Can see salary information.",
    grant: {
      company: ["view"], hr: ["manage"], hr_salary: ["view", "edit"], documents: ["view", "create", "edit"],
      tasks: ["view", "create", "edit", "assign"], reports: ["view", "export", "print"],
    },
  },
  {
    key: "data_entry_operator",
    name: "Data Entry Operator",
    description: "Enters leads, customers and visa records. Cannot edit or delete existing records.",
    grant: {
      company: ["view"], crm: ["view", "create"], visa: ["view", "create"], documents: ["view", "create"],
      tasks: ["view"],
    },
  },
  {
    key: "read_only",
    name: "Read-only User",
    description: "Can look at most information but change nothing.",
    grant: {
      company: ["view"], crm: ["view"], sales: ["view"], marketing: ["view"], visa: ["view"],
      accounting: ["view"], hr: ["view"], tasks: ["view"], reports: ["view"], documents: ["view"],
    },
  },
  {
    key: "auditor",
    name: "Auditor",
    description: "Reviews records, reports and the audit log. Cannot change anything.",
    grant: {
      company: ["view"], team: ["view"], crm: ["view"], sales: ["view"], visa: ["view"],
      accounting: ["view", "export", "print"], hr: ["view"], documents: ["view"],
      reports: ["view", "export", "print"], audit: ["view", "export"],
    },
  },
];

/** Makes sure the built-in roles exist in the database. Checks the database each time, so a reset database is repaired. */
export async function ensureSystemRoles(): Promise<void> {
  const [{ value }] = await db.select({ value: count() }).from(roles).where(eq(roles.isSystem, true));
  if (Number(value) >= SYSTEM_ROLE_TEMPLATES.length) return;
  for (const template of SYSTEM_ROLE_TEMPLATES) {
    const permissions = grantToKeys(template.grant);
    await db
      .insert(roles)
      .values({ key: template.key, name: template.name, description: template.description, permissions, isSystem: true })
      .onConflictDoUpdate({
        target: roles.key,
        set: { name: template.name, description: template.description, permissions, isSystem: true, updatedAt: new Date() },
      });
  }
}

// ---------- Access context ----------
export type AccessContext = {
  user: SessionUser;
  company: typeof companies.$inferSelect;
  roleName: string;
  isGlobalAdmin: boolean;
  branchId: number | null;
  departmentId: number | null;
  permissions: Set<string>;
  can: (module: ModuleKey, action?: ActionKey) => boolean;
};

/**
 * Loads what the signed-in user may do inside one company.
 * Returns null when the user has no active access, or the company is inactive.
 */
export const getAccess = cache(async (companyId: number): Promise<AccessContext | null> => {
  const user = await getSessionUser();
  if (!user) return null;

  const [company] = await db.select().from(companies).where(eq(companies.id, companyId)).limit(1);
  if (!company || !company.isActive) return null;

  const isGlobalAdmin = user.globalRole === "owner" || user.globalRole === "group_admin";
  let permissions: Set<string>;
  let roleName: string;
  let branchId: number | null = null;
  let departmentId: number | null = null;

  if (isGlobalAdmin) {
    permissions = new Set(ALL_PERMISSION_KEYS);
    roleName = user.globalRole === "owner" ? "Owner" : "Group Administrator";
  } else {
    const [row] = await db
      .select({ access: userCompanyAccess, role: roles })
      .from(userCompanyAccess)
      .innerJoin(roles, eq(roles.id, userCompanyAccess.roleId))
      .where(
        and(
          eq(userCompanyAccess.userId, user.id),
          eq(userCompanyAccess.companyId, companyId),
          eq(userCompanyAccess.isActive, true),
        ),
      )
      .limit(1);
    if (!row) return null;
    permissions = applyOverrides(expandPermissions(row.role.permissions), row.access.overrides);
    roleName = row.role.name;
    branchId = row.access.branchId;
    departmentId = row.access.departmentId;
  }

  const enabledModules = new Set(company.enabledModules);
  const can = (module: ModuleKey, action: ActionKey = "view") => {
    if (isToggleable(module) && !enabledModules.has(module)) return false;
    return permissions.has(`${module}.${action}`);
  };

  return { user, company, roleName, isGlobalAdmin, branchId, departmentId, permissions, can };
});

/** Used by server actions. Throws a friendly error that the form shows to the user. */
export async function requireAccess(companyId: number, module: ModuleKey, action: ActionKey = "view"): Promise<AccessContext> {
  const ctx = await getAccess(companyId);
  if (!ctx) {
    throw new AppError("You do not have access to this company, or the company is inactive.");
  }
  if (!ctx.can(module, action)) {
    throw new AppError(
      `You do not have permission to ${ACTION_LABELS[action].toLowerCase()} in ${MODULE_LABELS[module].toLowerCase()}. Please ask your administrator.`,
    );
  }
  return ctx;
}

/** Used by server-rendered pages. Redirects instead of showing an error page. */
export async function requirePage(companyId: number, module: ModuleKey, action: ActionKey = "view"): Promise<AccessContext> {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const ctx = await getAccess(companyId);
  if (!ctx) redirect(flashUrl("/dashboard", "error", "You do not have access to that company."));
  if (!ctx.can(module, action)) {
    redirect(flashUrl(`/c/${companyId}`, "error", "You do not have permission to open that page."));
  }
  return ctx;
}

/** A user limited to one branch can only see records of that branch. */
export function inBranchScope(ctx: AccessContext, branchId: number | null | undefined): boolean {
  if (!ctx.branchId) return true;
  return branchId === ctx.branchId;
}

export function branchWhere(ctx: AccessContext, column: AnyPgColumn): SQL | undefined {
  return ctx.branchId ? eq(column, ctx.branchId) : undefined;
}

/** Active people who work in a company, for assignment dropdowns. */
export async function listCompanyMembers(companyId: number) {
  return db
    .select({
      id: users.id,
      fullName: users.fullName,
      email: users.email,
      roleName: roles.name,
      branchId: userCompanyAccess.branchId,
      departmentId: userCompanyAccess.departmentId,
    })
    .from(userCompanyAccess)
    .innerJoin(users, eq(users.id, userCompanyAccess.userId))
    .innerJoin(roles, eq(roles.id, userCompanyAccess.roleId))
    .where(
      and(eq(userCompanyAccess.companyId, companyId), eq(userCompanyAccess.isActive, true), eq(users.isActive, true)),
    )
    .orderBy(asc(users.fullName));
}

/** User IDs that hold a permission in a company (used to notify approvers). */
export async function usersWithPermission(companyId: number, module: ModuleKey, action: ActionKey): Promise<number[]> {
  const key = `${module}.${action}`;
  const rows = await db
    .select({
      userId: userCompanyAccess.userId,
      permissions: roles.permissions,
      overrides: userCompanyAccess.overrides,
      isActive: users.isActive,
    })
    .from(userCompanyAccess)
    .innerJoin(roles, eq(roles.id, userCompanyAccess.roleId))
    .innerJoin(users, eq(users.id, userCompanyAccess.userId))
    .where(and(eq(userCompanyAccess.companyId, companyId), eq(userCompanyAccess.isActive, true)));

  const ids = rows
    .filter((row) => row.isActive && applyOverrides(expandPermissions(row.permissions), row.overrides).has(key))
    .map((row) => row.userId);

  const admins = await db
    .select({ id: users.id })
    .from(users)
    .where(and(inArray(users.globalRole, ["owner", "group_admin"]), eq(users.isActive, true)));

  return [...new Set([...ids, ...admins.map((admin) => admin.id)])];
}

export type CompanyNavEntry = {
  id: number;
  name: string;
  businessType: string;
  enabledModules: string[];
  /** null means "everything" (owner and group administrators). */
  perms: string[] | null;
};

/** Companies the user can open, with the permissions needed to build the navigation menu. */
export async function loadNavCompanies(user: SessionUser): Promise<CompanyNavEntry[]> {
  if (user.globalRole === "owner" || user.globalRole === "group_admin") {
    const rows = await db.select().from(companies).where(eq(companies.isActive, true)).orderBy(asc(companies.name));
    return rows.map((c) => ({
      id: c.id,
      name: c.name,
      businessType: c.businessType,
      enabledModules: c.enabledModules,
      perms: null,
    }));
  }

  const rows = await db
    .select({ company: companies, role: roles, access: userCompanyAccess })
    .from(userCompanyAccess)
    .innerJoin(companies, eq(companies.id, userCompanyAccess.companyId))
    .innerJoin(roles, eq(roles.id, userCompanyAccess.roleId))
    .where(
      and(
        eq(userCompanyAccess.userId, user.id),
        eq(userCompanyAccess.isActive, true),
        eq(companies.isActive, true),
      ),
    )
    .orderBy(asc(companies.name));

  return rows.map((row) => ({
    id: row.company.id,
    name: row.company.name,
    businessType: row.company.businessType,
    enabledModules: row.company.enabledModules,
    perms: [...applyOverrides(expandPermissions(row.role.permissions), row.access.overrides)],
  }));
}

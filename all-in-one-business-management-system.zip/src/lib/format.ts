// Formatting and date helpers. All business dates use the Bangladesh time zone.
import { APP_TIMEZONE } from "@/lib/constants";

const bdtFormatter = new Intl.NumberFormat("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const countFormatter = new Intl.NumberFormat("en-IN");

export function todayISO(): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: APP_TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

export function monthStartISO(iso: string = todayISO()): string {
  return `${iso.slice(0, 7)}-01`;
}

export function addDaysISO(iso: string, days: number): string {
  const date = new Date(`${iso}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

/** Whole days from one ISO date to another (to - from). */
export function daysBetweenISO(from: string, to: string): number {
  return Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86_400_000);
}

/** Converts "YYYY-MM-DD" or "YYYY-MM-DDTHH:MM" (Bangladesh time) into a Date. */
export function dhakaToDate(value: string): Date {
  const normalized = value.length === 10 ? `${value}T00:00` : value;
  return new Date(`${normalized}:00+06:00`);
}

export function endOfDayDhaka(iso: string): Date {
  return dhakaToDate(`${iso}T23:59`);
}

export function formatDate(value: string | Date | null | undefined): string {
  if (!value) return "—";
  const date = typeof value === "string" ? dhakaToDate(value) : value;
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    timeZone: APP_TIMEZONE,
  }).format(date);
}

export function formatDateTime(value: string | Date | null | undefined): string {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: APP_TIMEZONE,
  }).format(date);
}

/** Formats an amount in Bangladeshi Taka, using lakh-style digit grouping. */
export function formatBDT(value: string | number | null | undefined): string {
  const amount = Number(value ?? 0);
  return `৳ ${bdtFormatter.format(Number.isFinite(amount) ? amount : 0)}`;
}

export function formatCount(value: number): string {
  return countFormatter.format(value);
}

export function percent(part: number, whole: number): number {
  return whole > 0 ? Math.round((part / whole) * 100) : 0;
}

export function normalizePhone(value: string | null | undefined): string | null {
  if (!value) return null;
  const cleaned = value.replace(/[^\d+]/g, "");
  return cleaned.length > 0 ? cleaned : null;
}

export function normalizeEmail(value: string | null | undefined): string | null {
  const cleaned = value?.trim().toLowerCase();
  return cleaned ? cleaned : null;
}

export function parseId(value: string | null | undefined): number | null {
  if (!value || !/^\d{1,9}$/.test(value)) return null;
  const parsed = Number(value);
  return parsed > 0 ? parsed : null;
}

export function parsePage(value: string | null | undefined): number {
  const parsed = Number(value ?? "1");
  return Number.isFinite(parsed) && parsed >= 1 ? Math.floor(parsed) : 1;
}

/** Hides all but the last 4 characters of a sensitive number such as a passport number. */
export function maskIdentifier(value: string | null | undefined): string | null {
  if (!value) return null;
  return `${"*".repeat(Math.max(value.length - 4, 0))}${value.slice(-4)}`;
}

/** Escapes text so it can be used safely inside a SQL LIKE pattern. */
export function escapeLike(value: string): string {
  return value.replace(/[\\%_]/g, (match) => `\\${match}`);
}

export function firstParam(value: string | string[] | undefined): string {
  if (Array.isArray(value)) return value[0] ?? "";
  return value ?? "";
}

/** Formats a date for a "datetime-local" form field, in Bangladesh time. */
export function toDhakaInput(value: Date | null | undefined): string {
  if (!value) return "";
  const parts = new Intl.DateTimeFormat("sv-SE", {
    timeZone: APP_TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(value);
  return parts.replace(" ", "T");
}

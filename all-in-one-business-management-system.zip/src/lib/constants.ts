// Shared constants, labels and option lists.
// Pure data only, so it can be imported by both server and client code.

export const APP_NAME = "Business Management System";
export const APP_TIMEZONE = "Asia/Dhaka";
export const CURRENCY_CODE = "BDT";
export const PAGE_SIZE = 25;

const LABEL_OVERRIDES: Record<string, string> = {
  bkash: "bKash",
  nagad: "Nagad",
  upay: "Upay",
  vip: "VIP",
  nid: "National ID",
  whatsapp: "WhatsApp",
  facebook: "Facebook",
  instagram: "Instagram",
  email: "Email",
  hr: "HR",
  crm: "CRM",
  tin: "TIN",
  id: "ID",
};

/** Turns a database key such as "quotation_sent" into "Quotation sent". */
export function humanize(key: string | null | undefined): string {
  if (!key) return "—";
  if (LABEL_OVERRIDES[key]) return LABEL_OVERRIDES[key];
  const spaced = key.replace(/_/g, " ");
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

export function optionsOf<K extends string>(keys: readonly K[]): { value: K; label: string }[] {
  return keys.map((value) => ({ value, label: humanize(value) }));
}

// ---------- Global roles (across all companies) ----------
export const GLOBAL_ROLE_KEYS = ["owner", "group_admin", "staff"] as const;
export type GlobalRole = (typeof GLOBAL_ROLE_KEYS)[number];
export const GLOBAL_ROLE_LABELS: Record<GlobalRole, string> = {
  owner: "Owner (Super Admin)",
  group_admin: "Group Administrator",
  staff: "Staff",
};

// ---------- Company / business types ----------
export const BUSINESS_TYPE_KEYS = [
  "travel_agency",
  "education_consultancy",
  "tourism",
  "travel_experience",
  "retail_products",
  "service_sessions",
  "digital_services",
  "general",
] as const;
export type BusinessType = (typeof BUSINESS_TYPE_KEYS)[number];
export const BUSINESS_TYPE_LABELS: Record<BusinessType, string> = {
  travel_agency: "Travel, visa & ticketing agency",
  education_consultancy: "Education consultancy",
  tourism: "Community & cultural tourism",
  travel_experience: "Travel experience & hospitality",
  retail_products: "Baby & children's products",
  service_sessions: "Sessions, wellbeing & assessments",
  digital_services: "Digital & AI services",
  general: "General business",
};

/** The owner's current business portfolio. Can be added in one click from the Companies page. */
export const PORTFOLIO_COMPANIES: { name: string; businessType: BusinessType }[] = [
  { name: "Dhaka Holiday", businessType: "travel_agency" },
  { name: "Globepath Holidays", businessType: "travel_agency" },
  { name: "Dhaka Educare", businessType: "education_consultancy" },
  { name: "Globepath Education / Higher Study", businessType: "education_consultancy" },
  { name: "Community Tourism", businessType: "tourism" },
  { name: "Ethnic & Indigenous Cultural Tourism", businessType: "tourism" },
  { name: "Nosara Traveler", businessType: "travel_experience" },
  { name: "Little Wonder Co.", businessType: "retail_products" },
  { name: "The Conversation Club", businessType: "service_sessions" },
  { name: "Life Profile", businessType: "service_sessions" },
  { name: "AI Life Companion", businessType: "digital_services" },
];

// ---------- Modules and permissions ----------
export const MODULE_KEYS = [
  "company",
  "team",
  "crm",
  "sales",
  "marketing",
  "visa",
  "accounting",
  "hr",
  "hr_salary",
  "tasks",
  "reports",
  "documents",
  "audit",
] as const;
export type ModuleKey = (typeof MODULE_KEYS)[number];
export const MODULE_LABELS: Record<ModuleKey, string> = {
  company: "Company settings",
  team: "Team & access",
  crm: "CRM (leads & customers)",
  sales: "Sales & targets",
  marketing: "Marketing",
  visa: "Visa management",
  accounting: "Accounting",
  hr: "HR & attendance",
  hr_salary: "Salary information (confidential)",
  tasks: "Office tasks",
  reports: "Reports",
  documents: "Documents",
  audit: "Audit log",
};

export const ACTION_KEYS = [
  "view",
  "create",
  "edit",
  "delete",
  "approve",
  "reject",
  "verify",
  "assign",
  "print",
  "export",
  "manage",
] as const;
export type ActionKey = (typeof ACTION_KEYS)[number];
export const ACTION_LABELS: Record<ActionKey, string> = {
  view: "View",
  create: "Create",
  edit: "Edit",
  delete: "Delete / cancel",
  approve: "Approve",
  reject: "Reject",
  verify: "Verify",
  assign: "Assign",
  print: "Print",
  export: "Export",
  manage: "Manage (all actions)",
};

/** Modules the owner can switch on or off per company. */
export const TOGGLEABLE_MODULE_KEYS = [
  "crm",
  "sales",
  "marketing",
  "visa",
  "accounting",
  "hr",
  "tasks",
  "reports",
  "documents",
] as const;
export type ToggleableModule = (typeof TOGGLEABLE_MODULE_KEYS)[number];
export function isToggleable(module: string): module is ToggleableModule {
  return (TOGGLEABLE_MODULE_KEYS as readonly string[]).includes(module);
}

// ---------- CRM ----------
export const LEAD_STATUS_KEYS = [
  "new",
  "contacted",
  "interested",
  "consultation",
  "quotation_sent",
  "follow_up",
  "converted",
  "lost",
  "not_interested",
] as const;
export type LeadStatus = (typeof LEAD_STATUS_KEYS)[number];
export const OPEN_LEAD_STATUSES: LeadStatus[] = [
  "new",
  "contacted",
  "interested",
  "consultation",
  "quotation_sent",
  "follow_up",
];

export const LEAD_SOURCE_KEYS = [
  "facebook",
  "instagram",
  "whatsapp",
  "website",
  "phone_call",
  "walk_in",
  "referral",
  "existing_customer",
  "other",
] as const;
export type LeadSource = (typeof LEAD_SOURCE_KEYS)[number];

export const CUSTOMER_CATEGORY_KEYS = ["individual", "family", "corporate", "group", "vip", "other"] as const;
export type CustomerCategory = (typeof CUSTOMER_CATEGORY_KEYS)[number];

export const ACTIVITY_TYPE_KEYS = [
  "note",
  "call",
  "meeting",
  "whatsapp",
  "email",
  "status_change",
  "follow_up",
  "system",
] as const;
export type ActivityType = (typeof ACTIVITY_TYPE_KEYS)[number];

export const FOLLOW_UP_STATUS_KEYS = ["open", "done", "cancelled"] as const;
export type FollowUpStatus = (typeof FOLLOW_UP_STATUS_KEYS)[number];

export const CAMPAIGN_CHANNEL_KEYS = [
  "facebook",
  "instagram",
  "whatsapp",
  "website",
  "email",
  "offline",
  "referral",
  "other",
] as const;
export type CampaignChannel = (typeof CAMPAIGN_CHANNEL_KEYS)[number];
export const CAMPAIGN_STATUS_KEYS = ["planned", "active", "paused", "completed"] as const;
export type CampaignStatus = (typeof CAMPAIGN_STATUS_KEYS)[number];

export const SERVICE_KIND_KEYS = ["service", "product"] as const;
export type ServiceKind = (typeof SERVICE_KIND_KEYS)[number];

export const TARGET_METRIC_KEYS = [
  "revenue",
  "new_leads",
  "leads_converted",
  "visa_applications",
  "visas_approved",
  "tasks_completed",
] as const;
export type TargetMetric = (typeof TARGET_METRIC_KEYS)[number];
export const TARGET_PERIOD_KEYS = ["daily", "weekly", "monthly", "quarterly", "yearly"] as const;
export type TargetPeriod = (typeof TARGET_PERIOD_KEYS)[number];
export const TARGET_SCOPE_KEYS = ["company", "branch", "department", "employee"] as const;
export type TargetScope = (typeof TARGET_SCOPE_KEYS)[number];

// ---------- Accounting ----------
export const DOC_TYPE_KEYS = ["invoice", "quotation"] as const;
export type DocType = (typeof DOC_TYPE_KEYS)[number];
export const INVOICE_STATUS_KEYS = ["issued", "partially_paid", "paid", "cancelled"] as const;
export const QUOTATION_STATUS_KEYS = ["draft", "sent", "accepted", "rejected", "converted", "cancelled"] as const;
export type InvoiceStatus = (typeof INVOICE_STATUS_KEYS)[number] | (typeof QUOTATION_STATUS_KEYS)[number];

export const RECEIPT_KIND_KEYS = ["payment", "refund"] as const;
export type ReceiptKind = (typeof RECEIPT_KIND_KEYS)[number];
export const RECEIPT_STATUS_KEYS = ["active", "cancelled"] as const;
export type ReceiptStatus = (typeof RECEIPT_STATUS_KEYS)[number];

export const PAYMENT_METHOD_KEYS = [
  "cash",
  "bank_transfer",
  "bkash",
  "nagad",
  "rocket",
  "upay",
  "card",
  "cheque",
  "other",
] as const;
export type PaymentMethod = (typeof PAYMENT_METHOD_KEYS)[number];

export const ACCOUNT_TYPE_KEYS = ["cash", "bank", "mobile_wallet"] as const;
export type AccountType = (typeof ACCOUNT_TYPE_KEYS)[number];

export const EXPENSE_STATUS_KEYS = ["pending", "approved", "rejected"] as const;
export type ExpenseStatus = (typeof EXPENSE_STATUS_KEYS)[number];

export const DEFAULT_EXPENSE_CATEGORIES = [
  "Rent",
  "Utilities",
  "Salaries & wages (general)",
  "Marketing & advertising",
  "Travel & transport",
  "Office supplies",
  "Government fees",
  "Visa & embassy fees",
  "Commission",
  "Bank & mobile charges",
  "Miscellaneous",
];

// ---------- Visa ----------
export const VISA_STATUS_KEYS = [
  "new",
  "consultation",
  "documents_pending",
  "documents_received",
  "under_preparation",
  "ready_for_submission",
  "submitted",
  "embassy_processing",
  "additional_documents_requested",
  "approved",
  "refused",
  "passport_ready",
  "delivered",
  "cancelled",
] as const;
export type VisaStatus = (typeof VISA_STATUS_KEYS)[number];

export const CHECKLIST_STATUS_KEYS = ["pending", "received", "verified"] as const;
export type ChecklistStatus = (typeof CHECKLIST_STATUS_KEYS)[number];

export const VISA_CATEGORY_SUGGESTIONS = [
  "Tourist / visit",
  "Business",
  "Student",
  "Work / employment",
  "Family / spouse",
  "Transit",
  "Medical",
  "Umrah / Hajj",
  "Other",
];

export const DESTINATION_SUGGESTIONS = [
  "Malaysia",
  "Singapore",
  "Thailand",
  "Japan",
  "South Korea",
  "China",
  "India",
  "Nepal",
  "Bhutan",
  "Sri Lanka",
  "Maldives",
  "United Arab Emirates",
  "Saudi Arabia",
  "Qatar",
  "Oman",
  "Bahrain",
  "Kuwait",
  "Turkey",
  "United Kingdom",
  "United States",
  "Canada",
  "Australia",
  "New Zealand",
  "Schengen (Europe)",
  "Italy",
  "Germany",
  "France",
  "Spain",
  "Russia",
  "Indonesia",
  "Egypt",
];

export const DEFAULT_VISA_CHECKLIST = [
  "Valid passport (at least 6 months validity)",
  "Passport copy (bio page)",
  "Passport-size photographs (as per embassy rules)",
  "Signed visa application form",
  "National ID (NID) copy",
  "Bank statement (last 6 months)",
  "Income proof / tax return (TIN)",
  "Flight reservation (tentative)",
  "Hotel booking / accommodation proof",
  "Travel insurance",
  "Invitation or sponsor letter (if applicable)",
];

// ---------- HR ----------
export const EMPLOYMENT_STATUS_KEYS = ["probation", "active", "on_leave", "resigned", "terminated"] as const;
export type EmploymentStatus = (typeof EMPLOYMENT_STATUS_KEYS)[number];
export const ATTENDANCE_STATUS_KEYS = ["present", "late", "absent", "half_day", "leave", "holiday"] as const;
export type AttendanceStatus = (typeof ATTENDANCE_STATUS_KEYS)[number];
export const LEAVE_TYPE_KEYS = ["annual", "sick", "casual", "unpaid", "other"] as const;
export type LeaveType = (typeof LEAVE_TYPE_KEYS)[number];
export const LEAVE_STATUS_KEYS = ["pending", "approved", "rejected", "cancelled"] as const;
export type LeaveStatus = (typeof LEAVE_STATUS_KEYS)[number];

// ---------- Office ----------
export const TASK_PRIORITY_KEYS = ["low", "medium", "high", "urgent"] as const;
export type TaskPriority = (typeof TASK_PRIORITY_KEYS)[number];
export const TASK_STATUS_KEYS = ["todo", "in_progress", "waiting", "done", "cancelled"] as const;
export type TaskStatus = (typeof TASK_STATUS_KEYS)[number];

// ---------- Documents ----------
export const DOCUMENT_MODULE_KEYS = ["crm", "visa", "hr", "accounting", "company", "general"] as const;
export type DocumentModule = (typeof DOCUMENT_MODULE_KEYS)[number];
export const DOCUMENT_CATEGORY_KEYS = [
  "passport",
  "visa_document",
  "photo",
  "nid",
  "contract",
  "receipt",
  "logo",
  "other",
] as const;
export type DocumentCategory = (typeof DOCUMENT_CATEGORY_KEYS)[number];

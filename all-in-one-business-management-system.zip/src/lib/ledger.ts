// Money ledger helpers: how much is paid against each invoice, and how much advance a customer holds.
// Only active receipts count. Cancelled receipts are kept for history but never add to balances.
import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { accountTransfers, cashAccounts, expenses, invoices, paymentAllocations, receipts } from "@/db/schema";
import type { Tx } from "@/lib/numbering";
import { centsToDb, dbToCents, type Cents } from "@/lib/money";

/** Locks an invoice row until the surrounding transaction ends, so two payments cannot overpay it. */
export async function lockInvoiceTx(tx: Tx, invoiceId: number): Promise<typeof invoices.$inferSelect | null> {
  const rows: (typeof invoices.$inferSelect)[] = await tx
    .select()
    .from(invoices)
    .where(eq(invoices.id, invoiceId))
    .limit(1)
    .for("update");
  return rows.length > 0 ? rows[0] : null;
}

export async function invoicePaidCents(invoiceId: number): Promise<Cents> {
  const [row] = await db
    .select({ total: sql<string>`coalesce(sum(${paymentAllocations.amount}), 0)` })
    .from(paymentAllocations)
    .innerJoin(receipts, eq(receipts.id, paymentAllocations.receiptId))
    .where(and(eq(paymentAllocations.invoiceId, invoiceId), eq(receipts.status, "active")));
  return dbToCents(row?.total);
}

/** Money received on a receipt that has not yet been applied to an invoice. */
export async function receiptUnallocatedCents(receiptId: number, receiptAmount: string): Promise<Cents> {
  const [row] = await db
    .select({ total: sql<string>`coalesce(sum(${paymentAllocations.amount}), 0)` })
    .from(paymentAllocations)
    .where(eq(paymentAllocations.receiptId, receiptId));
  return dbToCents(receiptAmount) - dbToCents(row?.total);
}

/** A customer's advance balance: payments not yet applied, minus refunds paid out. */
export async function customerAdvanceCents(companyId: number, customerId: number): Promise<Cents> {
  const payments = await db
    .select({ id: receipts.id, amount: receipts.amount })
    .from(receipts)
    .where(
      and(
        eq(receipts.companyId, companyId),
        eq(receipts.customerId, customerId),
        eq(receipts.kind, "payment"),
        eq(receipts.status, "active"),
      ),
    );
  const refunds = await db
    .select({ amount: receipts.amount })
    .from(receipts)
    .where(
      and(
        eq(receipts.companyId, companyId),
        eq(receipts.customerId, customerId),
        eq(receipts.kind, "refund"),
        eq(receipts.status, "active"),
      ),
    );

  const received = payments.reduce((sum, row) => sum + dbToCents(row.amount), 0);
  const refunded = refunds.reduce((sum, row) => sum + dbToCents(row.amount), 0);
  let applied = 0;
  if (payments.length > 0) {
    const [row] = await db
      .select({ total: sql<string>`coalesce(sum(${paymentAllocations.amount}), 0)` })
      .from(paymentAllocations)
      .where(inArray(paymentAllocations.receiptId, payments.map((p) => p.id)));
    applied = dbToCents(row?.total);
  }
  return received - applied - refunded;
}

/** Current balance of every cash, bank and mobile wallet account, from opening balance plus all movements. */
export async function accountBalances(companyId: number): Promise<Map<number, Cents>> {
  const accounts = await db
    .select({ id: cashAccounts.id, opening: cashAccounts.openingBalance })
    .from(cashAccounts)
    .where(eq(cashAccounts.companyId, companyId));
  const balances = new Map<number, Cents>(accounts.map((a) => [a.id, dbToCents(a.opening)]));
  const add = (accountId: number | null, amount: Cents) => {
    if (accountId !== null && balances.has(accountId)) balances.set(accountId, (balances.get(accountId) ?? 0) + amount);
  };

  const movements = await db
    .select({ accountId: receipts.accountId, kind: receipts.kind, amount: receipts.amount })
    .from(receipts)
    .where(and(eq(receipts.companyId, companyId), eq(receipts.status, "active")));
  for (const m of movements) add(m.accountId, m.kind === "refund" ? -dbToCents(m.amount) : dbToCents(m.amount));

  const spent = await db
    .select({ accountId: expenses.accountId, amount: expenses.amount })
    .from(expenses)
    .where(and(eq(expenses.companyId, companyId), eq(expenses.status, "approved")));
  for (const e of spent) add(e.accountId, -dbToCents(e.amount));

  const transfers = await db
    .select({ from: accountTransfers.fromAccountId, to: accountTransfers.toAccountId, amount: accountTransfers.amount })
    .from(accountTransfers)
    .where(eq(accountTransfers.companyId, companyId));
  for (const t of transfers) {
    add(t.from, -dbToCents(t.amount));
    add(t.to, dbToCents(t.amount));
  }
  return balances;
}

/**
 * Recalculates paid, due and status of an invoice from its allocations.
 * Call this inside the same transaction after any receipt, allocation or cancellation changes.
 */
export async function recomputeInvoiceTx(tx: Tx, invoiceId: number): Promise<void> {
  const [invoice] = await tx.select().from(invoices).where(eq(invoices.id, invoiceId)).limit(1);
  if (!invoice || invoice.docType !== "invoice" || invoice.status === "cancelled") return;

  const [row] = await tx
    .select({ total: sql<string>`coalesce(sum(${paymentAllocations.amount}), 0)` })
    .from(paymentAllocations)
    .innerJoin(receipts, eq(receipts.id, paymentAllocations.receiptId))
    .where(and(eq(paymentAllocations.invoiceId, invoiceId), eq(receipts.status, "active")));

  const paid = dbToCents(row?.total);
  const total = dbToCents(invoice.total);
  const due = Math.max(total - paid, 0);
  const status = paid >= total && total > 0 ? "paid" : paid > 0 ? "partially_paid" : "issued";

  await tx
    .update(invoices)
    .set({ paidAmount: centsToDb(paid), dueAmount: centsToDb(due), status, updatedAt: new Date() })
    .where(eq(invoices.id, invoiceId));
}

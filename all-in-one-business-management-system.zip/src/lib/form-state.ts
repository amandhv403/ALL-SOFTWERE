// The shape returned by server actions to forms. Kept in a plain module so client components can import it.
export type FormState = {
  ok?: boolean;
  error?: string;
  message?: string;
  fieldErrors?: Record<string, string>;
  values?: Record<string, string>;
  nonce?: number;
} | null;

// Helpers shared by all server actions (server-side only).
import { revalidatePath } from "next/cache";
import { ZodError } from "zod";
import type { FormState } from "@/lib/form-state";

/** An error with a message that is safe to show to the user. */
export class AppError extends Error {
  fieldErrors?: Record<string, string>;

  constructor(message: string, fieldErrors?: Record<string, string>) {
    super(message);
    this.name = "AppError";
    this.fieldErrors = fieldErrors;
  }
}

export type ActionResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: string; fieldErrors?: Record<string, string> };

export function zodFieldErrors(error: ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "form");
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}

/**
 * Runs an action body and turns any failure into a friendly result.
 * Never call redirect() inside this function: do it after it returns.
 */
export async function safeAction<T>(fn: () => Promise<T>): Promise<ActionResult<T>> {
  try {
    return { ok: true, data: await fn() };
  } catch (err) {
    if (err instanceof AppError) {
      return { ok: false, error: err.message, fieldErrors: err.fieldErrors };
    }
    if (err instanceof ZodError) {
      return { ok: false, error: "Please check the highlighted fields.", fieldErrors: zodFieldErrors(err) };
    }
    const code = (err as { code?: string } | null)?.code ?? (err as { cause?: { code?: string } } | null)?.cause?.code;
    if (code === "23505") {
      return { ok: false, error: "This record already exists or was just saved. Please check for duplicates." };
    }
    console.error("[action error]", err);
    return { ok: false, error: "Something went wrong while saving. Please try again." };
  }
}

export function formValues(formData: FormData): Record<string, string> {
  const out: Record<string, string> = {};
  formData.forEach((value, key) => {
    if (typeof value === "string") out[key] = value;
  });
  return out;
}

export function readText(values: Record<string, string>, key: string): string {
  return (values[key] ?? "").trim();
}

export function readFlag(values: Record<string, string>, key: string): boolean {
  return values[key] === "on" || values[key] === "true";
}

export function failure(error: string, values?: Record<string, string>, fieldErrors?: Record<string, string>): FormState {
  return { ok: false, error, values, fieldErrors, nonce: Date.now() };
}

export function success(message: string): FormState {
  return { ok: true, message, nonce: Date.now() };
}

/** Refreshes every page after data changes, so lists show the newest records. */
export function refreshAll(): void {
  revalidatePath("/", "layout");
}

export function flashUrl(path: string, kind: "notice" | "error", message: string): string {
  const separator = path.includes("?") ? "&" : "?";
  return `${path}${separator}${kind}=${encodeURIComponent(message)}`;
}

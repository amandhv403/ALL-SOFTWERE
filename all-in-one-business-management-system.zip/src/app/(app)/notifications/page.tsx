import { desc, eq } from "drizzle-orm";
import Link from "next/link";
import { redirect } from "next/navigation";
import { markAllNotificationsRead } from "@/app/actions/auth";
import { Badge, Card, EmptyState, Flash, PageHeader, btnPrimary } from "@/components/ui";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { firstParam, formatDateTime } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function NotificationsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const sp = await searchParams;
  const rows = await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, user.id))
    .orderBy(desc(notifications.createdAt))
    .limit(100);
  const unread = rows.filter((n) => !n.isRead).length;

  return (
    <>
      <PageHeader
        title="Notifications"
        description="Things that need your attention: new assignments, approvals, follow-ups and status changes."
        actions={
          unread > 0 ? (
            <form action={markAllNotificationsRead}>
              <button type="submit" className={btnPrimary}>
                Mark all as read
              </button>
            </form>
          ) : null
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />
      <Card>
        {rows.length === 0 ? (
          <EmptyState title="No notifications" text="You will see new assignments and approval requests here." />
        ) : (
          <ul className="divide-y divide-slate-100">
            {rows.map((n) => (
              <li key={n.id} className="flex items-start justify-between gap-4 py-3">
                <div className="min-w-0">
                  <p className={`text-sm ${n.isRead ? "text-slate-700" : "font-semibold text-slate-950"}`}>{n.title}</p>
                  {n.body ? <p className="text-sm text-slate-600">{n.body}</p> : null}
                  <p className="mt-1 text-xs text-slate-500">{formatDateTime(n.createdAt)}</p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  {!n.isRead ? <Badge tone="red">New</Badge> : null}
                  {n.link ? (
                    <Link href={n.link} className="text-sm font-medium text-teal-800 hover:underline">
                      Open
                    </Link>
                  ) : null}
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </>
  );
}

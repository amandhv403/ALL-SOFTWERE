import { asc, eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { createUserAccount, resetUserPassword, setUserActive, setUserGlobalRole } from "@/app/actions/admin";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Badge, Card, Flash, PageHeader, btnSmall, inputClass, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { GLOBAL_ROLE_KEYS, GLOBAL_ROLE_LABELS } from "@/lib/constants";
import { firstParam, formatDateTime } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AdminUsersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const me = await getSessionUser();
  if (!me) redirect("/login");
  if (me.globalRole !== "owner" && me.globalRole !== "group_admin") {
    redirect("/dashboard?error=" + encodeURIComponent("Only the owner or a group administrator can manage logins."));
  }
  const sp = await searchParams;
  const isOwner = me.globalRole === "owner";
  const rows = await db.select().from(users).orderBy(asc(users.fullName));

  const roleOptions = GLOBAL_ROLE_KEYS.filter((r) => isOwner || r === "staff").map((r) => ({ value: r, label: GLOBAL_ROLE_LABELS[r] }));
  const createFields: FieldDef[] = [
    { name: "fullName", label: "Full name", required: true },
    { name: "email", label: "Email (used to sign in)", type: "email", required: true },
    { name: "phone", label: "Phone", type: "tel" },
    { name: "globalRole", label: "Top-level role", type: "select", options: roleOptions, defaultValue: "staff" },
    {
      name: "tempPassword",
      label: "Temporary password",
      type: "password",
      required: true,
      help: "At least 10 characters with a letter and a number. The person must change it at first sign-in.",
    },
  ];

  return (
    <>
      <PageHeader
        title="Users and logins"
        description="Create sign-in accounts, reset passwords and switch accounts on or off. Give people access to companies from each company's Team page."
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <Card className="mb-6 overflow-x-auto p-0">
        <table className={tableClass}>
          <thead>
            <tr>
              <th className={thClass}>Name</th>
              <th className={thClass}>Email</th>
              <th className={thClass}>Top-level role</th>
              <th className={thClass}>Status</th>
              <th className={thClass}>Last sign-in</th>
              <th className={thClass}>Reset password</th>
              <th className={thClass}>Switch on / off</th>
              {isOwner ? <th className={thClass}>Change role</th> : null}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((u) => {
              const isSelf = u.id === me.id;
              const protectedOwner = u.globalRole === "owner" && !isOwner;
              return (
                <tr key={u.id}>
                  <td className={tdClass}>
                    <p className="font-medium text-slate-900">{u.fullName}</p>
                    {u.mustChangePassword ? <Badge tone="amber">Must change password</Badge> : null}
                  </td>
                  <td className={tdClass}>{u.email}</td>
                  <td className={tdClass}>{GLOBAL_ROLE_LABELS[u.globalRole]}</td>
                  <td className={tdClass}>
                    <Badge tone={u.isActive ? "green" : "red"}>{u.isActive ? "Active" : "Switched off"}</Badge>
                  </td>
                  <td className={tdClass}>{formatDateTime(u.lastLoginAt)}</td>
                  <td className={tdClass}>
                    {protectedOwner ? (
                      <span className="text-xs text-slate-500">Owner only</span>
                    ) : (
                      <form action={resetUserPassword} className="flex gap-1.5">
                        <input type="hidden" name="userId" value={u.id} />
                        <input name="tempPassword" type="password" placeholder="New temp password" className="w-36 rounded-md border border-slate-300 px-2 py-1 text-xs" required minLength={10} />
                        <button type="submit" className={btnSmall}>Set</button>
                      </form>
                    )}
                  </td>
                  <td className={tdClass}>
                    {isSelf || protectedOwner ? (
                      <span className="text-xs text-slate-500">{isSelf ? "That is you" : "Owner only"}</span>
                    ) : (
                      <form action={setUserActive}>
                        <input type="hidden" name="userId" value={u.id} />
                        <input type="hidden" name="active" value={u.isActive ? "0" : "1"} />
                        <button type="submit" className={btnSmall}>{u.isActive ? "Switch off" : "Switch on"}</button>
                      </form>
                    )}
                  </td>
                  {isOwner ? (
                    <td className={tdClass}>
                      {isSelf ? (
                        <span className="text-xs text-slate-500">That is you</span>
                      ) : (
                        <form action={setUserGlobalRole} className="flex gap-1.5">
                          <input type="hidden" name="userId" value={u.id} />
                          <select name="globalRole" defaultValue={u.globalRole} className={`${inputClass} !mt-0 !py-1 text-xs`}>
                            {GLOBAL_ROLE_KEYS.map((r) => (
                              <option key={r} value={r}>
                                {GLOBAL_ROLE_LABELS[r]}
                              </option>
                            ))}
                          </select>
                          <button type="submit" className={btnSmall}>Save</button>
                        </form>
                      )}
                    </td>
                  ) : null}
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>

      <Card title="Create a new login" description="The person can sign in straight away with the temporary password, then must choose their own password.">
        <ActionForm action={createUserAccount} submitLabel="Create login" fields={createFields} />
      </Card>
    </>
  );
}

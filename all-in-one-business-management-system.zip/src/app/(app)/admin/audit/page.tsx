import { desc, eq, ilike, or, type SQL, and } from "drizzle-orm";
import { redirect } from "next/navigation";
import { Card, EmptyState, Flash, PageHeader, SearchBar, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { auditLogs, companies, users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { escapeLike, firstParam, formatDateTime, parseId } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AuditLogPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const me = await getSessionUser();
  if (!me) redirect("/login");
  if (me.globalRole !== "owner" && me.globalRole !== "group_admin") {
    redirect("/dashboard?error=" + encodeURIComponent("Only the owner or a group administrator can view the audit log."));
  }
  const sp = await searchParams;
  const q = firstParam(sp.q).trim();
  const companyId = parseId(firstParam(sp.companyId));

  const conditions: (SQL | undefined)[] = [];
  if (companyId) conditions.push(eq(auditLogs.companyId, companyId));
  if (q) {
    const like = `%${escapeLike(q)}%`;
    conditions.push(or(ilike(auditLogs.summary, like), ilike(auditLogs.action, like), ilike(auditLogs.entityType, like)));
  }

  const [rows, companyRows] = await Promise.all([
    db
      .select({ log: auditLogs, userName: users.fullName, companyName: companies.name })
      .from(auditLogs)
      .leftJoin(users, eq(users.id, auditLogs.userId))
      .leftJoin(companies, eq(companies.id, auditLogs.companyId))
      .where(and(...conditions))
      .orderBy(desc(auditLogs.createdAt))
      .limit(300),
    db.select({ id: companies.id, name: companies.name }).from(companies).orderBy(companies.name),
  ]);

  return (
    <>
      <PageHeader
        title="Audit log"
        description="A record of important actions: sign-ins, record creation, status changes, payments, cancellations and access changes. Entries cannot be edited or deleted."
      />
      <Flash notice={undefined} error={undefined} />

      <Card>
        <form method="get" className="mb-5 flex flex-wrap items-center gap-3">
          <select name="companyId" defaultValue={companyId ? String(companyId) : ""} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="">All companies</option>
            {companyRows.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <SearchBar placeholder="Search what happened" defaultValue={q} />
        </form>
        {rows.length === 0 ? (
          <EmptyState title="No entries match" text="Try a different search or company." />
        ) : (
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>When</th>
                  <th className={thClass}>Who</th>
                  <th className={thClass}>Company</th>
                  <th className={thClass}>Action</th>
                  <th className={thClass}>What happened</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rows.map(({ log, userName, companyName }) => (
                  <tr key={log.id}>
                    <td className={tdClass}>{formatDateTime(log.createdAt)}</td>
                    <td className={tdClass}>{userName ?? "System"}</td>
                    <td className={tdClass}>{companyName ?? "—"}</td>
                    <td className={tdClass}>
                      <code className="text-xs text-slate-700">{log.action}</code>
                    </td>
                    <td className={tdClass}>{log.summary}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}

import { asc, eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { createCustomRole, deleteCustomRole } from "@/app/actions/admin";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Badge, Card, Flash, PageHeader, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { roles } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { ACTION_KEYS, ACTION_LABELS, MODULE_KEYS, MODULE_LABELS } from "@/lib/constants";
import { firstParam } from "@/lib/format";
import { ensureSystemRoles } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function AdminRolesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const me = await getSessionUser();
  if (!me) redirect("/login");
  if (me.globalRole !== "owner") redirect("/dashboard?error=" + encodeURIComponent("Only the owner can manage roles."));
  const sp = await searchParams;

  await ensureSystemRoles();
  const roleRows = await db.select().from(roles).orderBy(asc(roles.name));

  const fields: FieldDef[] = [
    { name: "name", label: "Role name", required: true, placeholder: "e.g. Senior Visa Consultant" },
    { name: "description", label: "What this role is for", wide: true },
  ];
  for (const moduleKey of MODULE_KEYS) {
    fields.push({ name: `h-${moduleKey}`, label: MODULE_LABELS[moduleKey], type: "heading" });
    for (const action of ACTION_KEYS) {
      fields.push({ name: `p_${moduleKey}_${action}`, label: ACTION_LABELS[action], type: "checkbox" });
    }
  }

  return (
    <>
      <PageHeader
        title="Roles and permissions"
        description="A role is a set of permissions. Built-in roles cover the usual jobs. Create custom roles for anything else, then give them to people from each company's Team page."
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <Card className="mb-6 overflow-x-auto p-0">
        <table className={tableClass}>
          <thead>
            <tr>
              <th className={thClass}>Role</th>
              <th className={thClass}>Type</th>
              <th className={thClass}>Permissions</th>
              <th className={thClass}>Description</th>
              <th className={thClass}></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {roleRows.map((r) => (
              <tr key={r.id}>
                <td className={tdClass}>
                  <p className="font-medium text-slate-900">{r.name}</p>
                  <p className="text-xs text-slate-500">{r.key}</p>
                </td>
                <td className={tdClass}>{r.isSystem ? <Badge tone="blue">Built-in</Badge> : <Badge tone="teal">Custom</Badge>}</td>
                <td className={tdClass}>{r.permissions.length}</td>
                <td className={tdClass}>{r.description ?? "—"}</td>
                <td className={tdClass}>
                  {!r.isSystem ? (
                    <form action={deleteCustomRole}>
                      <input type="hidden" name="roleId" value={r.id} />
                      <button type="submit" className={btnSmall}>Delete</button>
                    </form>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Card title="Create a custom role" description="Tick what this role may do. Remember: 'Delete / cancel' is the most sensitive permission.">
        <ActionForm action={createCustomRole} submitLabel="Create role" fields={fields} columns={2} />
      </Card>
    </>
  );
}

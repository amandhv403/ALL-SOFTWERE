import { and, count, desc, eq, inArray, isNotNull, sql } from "drizzle-orm";
import { notFound } from "next/navigation";
import { createCampaign, updateCampaignStatus } from "@/app/actions/sales";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Card, Flash, PageHeader, StatusBadge, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { campaigns, expenses, leads, receipts, users } from "@/db/schema";
import { CAMPAIGN_CHANNEL_KEYS, CAMPAIGN_STATUS_KEYS, humanize, optionsOf } from "@/lib/constants";
import { firstParam, formatBDT, formatCount, parseId, todayISO } from "@/lib/format";
import { centsToDb, dbToCents } from "@/lib/money";
import { listCompanyMembers, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function CampaignsPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "marketing", "view");
  const sp = await searchParams;

  const [rows, spendRows, members] = await Promise.all([
    db
      .select({ campaign: campaigns, ownerName: users.fullName })
      .from(campaigns)
      .leftJoin(users, eq(users.id, campaigns.ownerUserId))
      .where(eq(campaigns.companyId, companyId))
      .orderBy(desc(campaigns.createdAt)),
    db
      .select({ campaignId: expenses.campaignId, total: sql<string>`coalesce(sum(${expenses.amount}), 0)` })
      .from(expenses)
      .where(and(eq(expenses.companyId, companyId), eq(expenses.status, "approved"), isNotNull(expenses.campaignId)))
      .groupBy(expenses.campaignId),
    listCompanyMembers(companyId),
  ]);

  const leadCounts = await db
    .select({ campaignId: leads.campaignId, value: count(), converted: sql<number>`count(*) filter (where ${leads.status} = 'converted')` })
    .from(leads)
    .where(and(eq(leads.companyId, companyId), isNotNull(leads.campaignId)))
    .groupBy(leads.campaignId);

  const spendMap = new Map(spendRows.map((r) => [r.campaignId, dbToCents(r.total)]));
  const leadMap = new Map(leadCounts.map((r) => [r.campaignId, { total: Number(r.value), converted: Number(r.converted) }]));

  // Revenue from customers who came in through each campaign (active payments only).
  const revenueByCampaign = new Map<number, number>();
  for (const campaign of rows) {
    const customerIds = await db
      .select({ id: leads.customerId })
      .from(leads)
      .where(and(eq(leads.companyId, companyId), eq(leads.campaignId, campaign.campaign.id), isNotNull(leads.customerId)));
    const ids = customerIds.map((c) => c.id).filter((id): id is number => id !== null);
    if (ids.length === 0) {
      revenueByCampaign.set(campaign.campaign.id, 0);
      continue;
    }
    const [row] = await db
      .select({ total: sql<string>`coalesce(sum(${receipts.amount}), 0)` })
      .from(receipts)
      .where(and(eq(receipts.companyId, companyId), eq(receipts.kind, "payment"), eq(receipts.status, "active"), inArray(receipts.customerId, ids)));
    revenueByCampaign.set(campaign.campaign.id, dbToCents(row?.total));
  }

  const fields: FieldDef[] = [
    { name: "name", label: "Campaign name", required: true, placeholder: "e.g. Umrah Ramadan offer" },
    { name: "channel", label: "Channel", type: "select", options: optionsOf(CAMPAIGN_CHANNEL_KEYS), defaultValue: "facebook" },
    { name: "status", label: "Status", type: "select", options: optionsOf(CAMPAIGN_STATUS_KEYS), defaultValue: "planned" },
    { name: "budget", label: "Budget (৳)", type: "number", step: "0.01", min: "0", defaultValue: "0" },
    { name: "startDate", label: "Start date", type: "date", defaultValue: todayISO() },
    { name: "endDate", label: "End date", type: "date" },
    {
      name: "ownerUserId",
      label: "Campaign owner",
      type: "select",
      options: [{ value: "", label: "Me" }, ...members.map((m) => ({ value: String(m.id), label: m.fullName }))],
    },
    { name: "objective", label: "Objective", type: "textarea", wide: true, placeholder: "e.g. 50 new Umrah enquiries in November" },
  ];

  return (
    <>
      <PageHeader
        title="Marketing campaigns"
        description="Track what each campaign costs and what it brings back. Spend comes from approved expenses linked to the campaign. Leads come from the CRM."
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2" title="Campaign results">
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Campaign</th>
                  <th className={thClass}>Status</th>
                  <th className={thClass}>Budget</th>
                  <th className={thClass}>Spent</th>
                  <th className={thClass}>Leads</th>
                  <th className={thClass}>Converted</th>
                  <th className={thClass}>Cost per lead</th>
                  <th className={thClass}>Revenue</th>
                  <th className={thClass}>Return</th>
                  {ctx.can("marketing", "edit") ? <th className={thClass}></th> : null}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rows.length === 0 ? (
                  <tr>
                    <td className={tdClass} colSpan={10}>
                      No campaigns yet. Create your first campaign on the right.
                    </td>
                  </tr>
                ) : null}
                {rows.map(({ campaign }) => {
                  const spent = spendMap.get(campaign.id) ?? 0;
                  const leadStats = leadMap.get(campaign.id) ?? { total: 0, converted: 0 };
                  const revenue = revenueByCampaign.get(campaign.id) ?? 0;
                  const costPerLead = leadStats.total > 0 ? spent / leadStats.total : null;
                  const roi = spent > 0 ? Math.round(((revenue - spent) / spent) * 100) : null;
                  return (
                    <tr key={campaign.id}>
                      <td className={tdClass}>
                        <p className="font-medium text-slate-900">{campaign.name}</p>
                        <p className="text-xs text-slate-500">{humanize(campaign.channel)}</p>
                      </td>
                      <td className={tdClass}>
                        <StatusBadge status={campaign.status} />
                      </td>
                      <td className={tdClass}>{formatBDT(campaign.budget)}</td>
                      <td className={tdClass}>{formatBDT(centsToDb(spent))}</td>
                      <td className={tdClass}>{formatCount(leadStats.total)}</td>
                      <td className={tdClass}>{formatCount(leadStats.converted)}</td>
                      <td className={tdClass}>{costPerLead === null ? "—" : formatBDT(centsToDb(Math.round(costPerLead)))}</td>
                      <td className={tdClass}>{formatBDT(centsToDb(revenue))}</td>
                      <td className={tdClass}>{roi === null ? "—" : `${roi}%`}</td>
                      {ctx.can("marketing", "edit") ? (
                        <td className={tdClass}>
                          <form action={updateCampaignStatus} className="flex gap-1">
                            <input type="hidden" name="companyId" value={companyId} />
                            <input type="hidden" name="campaignId" value={campaign.id} />
                            <select name="status" defaultValue={campaign.status} className="rounded-md border border-slate-300 px-1.5 py-1 text-xs">
                              {CAMPAIGN_STATUS_KEYS.map((s) => (
                                <option key={s} value={s}>
                                  {humanize(s)}
                                </option>
                              ))}
                            </select>
                            <button type="submit" className={btnSmall}>
                              Save
                            </button>
                          </form>
                        </td>
                      ) : null}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="mt-4 text-xs text-slate-500">
            Return = (revenue − spend) ÷ spend. Revenue counts payments from customers who came from the campaign&apos;s leads.
          </p>
        </Card>

        {ctx.can("marketing", "create") ? (
          <Card title="New campaign">
            <ActionForm action={createCampaign} columns={1} hidden={{ companyId: String(companyId) }} submitLabel="Save campaign" fields={fields} />
          </Card>
        ) : null}
      </div>
    </>
  );
}

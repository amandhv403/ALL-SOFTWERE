import { and, asc, eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { assignTeamAccess, removeTeamAccess } from "@/app/actions/admin";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Badge, Card, Flash, PageHeader, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { branches, departments, roles, userCompanyAccess, users } from "@/db/schema";
import { ensureSystemRoles, requirePage } from "@/lib/permissions";
import { firstParam, parseId } from "@/lib/format";
import { ACTION_KEYS, MODULE_KEYS, humanize } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function TeamPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "team", "view");
  const sp = await searchParams;
  const canManage = ctx.can("team", "manage");

  await ensureSystemRoles();

  const [members, activeUsers, roleRows, branchRows, departmentRows] = await Promise.all([
    db
      .select({
        userId: userCompanyAccess.userId,
        isActive: userCompanyAccess.isActive,
        fullName: users.fullName,
        email: users.email,
        roleName: roles.name,
        branchName: branches.name,
        departmentName: departments.name,
        overrides: userCompanyAccess.overrides,
      })
      .from(userCompanyAccess)
      .innerJoin(users, eq(users.id, userCompanyAccess.userId))
      .innerJoin(roles, eq(roles.id, userCompanyAccess.roleId))
      .leftJoin(branches, eq(branches.id, userCompanyAccess.branchId))
      .leftJoin(departments, eq(departments.id, userCompanyAccess.departmentId))
      .where(eq(userCompanyAccess.companyId, companyId))
      .orderBy(asc(users.fullName)),
    db
      .select({ id: users.id, fullName: users.fullName, email: users.email })
      .from(users)
      .where(eq(users.isActive, true))
      .orderBy(asc(users.fullName)),
    db.select({ id: roles.id, name: roles.name, description: roles.description }).from(roles).where(eq(roles.isActive, true)).orderBy(asc(roles.name)),
    db.select({ id: branches.id, name: branches.name }).from(branches).where(and(eq(branches.companyId, companyId), eq(branches.isActive, true))).orderBy(asc(branches.name)),
    db.select({ id: departments.id, name: departments.name }).from(departments).where(and(eq(departments.companyId, companyId), eq(departments.isActive, true))).orderBy(asc(departments.name)),
  ]);

  const assignFields: FieldDef[] = [
    {
      name: "userId",
      label: "Person",
      type: "select",
      required: true,
      options: [{ value: "", label: "Choose a person…" }, ...activeUsers.map((u) => ({ value: String(u.id), label: `${u.fullName} (${u.email})` }))],
    },
    {
      name: "roleId",
      label: "Role in this company",
      type: "select",
      required: true,
      options: roleRows.map((r) => ({ value: String(r.id), label: r.name })),
    },
    {
      name: "branchId",
      label: "Branch (leave empty for all branches)",
      type: "select",
      options: [{ value: "", label: "All branches" }, ...branchRows.map((b) => ({ value: String(b.id), label: b.name }))],
    },
    {
      name: "departmentId",
      label: "Department (optional)",
      type: "select",
      options: [{ value: "", label: "No department" }, ...departmentRows.map((d) => ({ value: String(d.id), label: d.name }))],
    },
    {
      name: "grants",
      label: "Extra permissions for this person (optional)",
      wide: true,
      placeholder: "e.g. accounting.approve, hr.export",
      help: `Add permissions beyond the role. Format: module.action. Modules: ${MODULE_KEYS.join(", ")}. Actions: ${ACTION_KEYS.join(", ")}.`,
    },
    {
      name: "revokes",
      label: "Permissions to remove from this role (optional)",
      wide: true,
      placeholder: "e.g. accounting.delete",
      help: "Use the same format. Removed permissions stop working for this person in this company only.",
    },
  ];

  return (
    <>
      <PageHeader
        title="Team and access"
        description="Decide who works in this company, what role they have, and which branch or department they can see. The owner and group administrators can open every company."
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2" title="People with access" description={`${members.length} person(s) listed for this company`}>
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Person</th>
                  <th className={thClass}>Role</th>
                  <th className={thClass}>Branch</th>
                  <th className={thClass}>Department</th>
                  <th className={thClass}>Extra rights</th>
                  <th className={thClass}>Status</th>
                  {canManage ? <th className={thClass}>Action</th> : null}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {members.length === 0 ? (
                  <tr>
                    <td className={tdClass} colSpan={7}>
                      Nobody has been given access yet. Use the form on the right.
                    </td>
                  </tr>
                ) : null}
                {members.map((m) => (
                  <tr key={m.userId}>
                    <td className={tdClass}>
                      <p className="font-medium text-slate-900">{m.fullName}</p>
                      <p className="text-xs text-slate-500">{m.email}</p>
                    </td>
                    <td className={tdClass}>{m.roleName}</td>
                    <td className={tdClass}>{m.branchName ?? "All branches"}</td>
                    <td className={tdClass}>{m.departmentName ?? "—"}</td>
                    <td className={tdClass}>
                      {m.overrides.grant.length + m.overrides.revoke.length === 0
                        ? "—"
                        : [...m.overrides.grant.map((k) => `+${k}`), ...m.overrides.revoke.map((k) => `−${k}`)].join(", ")}
                    </td>
                    <td className={tdClass}>
                      <Badge tone={m.isActive ? "green" : "slate"}>{m.isActive ? "Active" : "Removed"}</Badge>
                    </td>
                    {canManage ? (
                      <td className={tdClass}>
                        {m.isActive ? (
                          <form action={removeTeamAccess}>
                            <input type="hidden" name="companyId" value={companyId} />
                            <input type="hidden" name="userId" value={m.userId} />
                            <button type="submit" className={btnSmall}>
                              Remove access
                            </button>
                          </form>
                        ) : null}
                      </td>
                    ) : null}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-6 rounded-xl bg-slate-50 p-4 text-sm text-slate-700">
            <p className="font-medium text-slate-900">Roles at a glance</p>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              {roleRows.map((r) => (
                <li key={r.id}>
                  <span className="font-medium">{r.name}</span>
                </li>
              ))}
            </ul>
            <p className="mt-2 text-xs text-slate-500">Need a role that does not exist? The owner can create custom roles from Roles &amp; permissions.</p>
          </div>
        </Card>

        <Card title="Give or change access" description="Choose a person, then a role. Saving again updates their access.">
          {canManage ? (
            <ActionForm
              action={assignTeamAccess}
              columns={1}
              hidden={{ companyId: String(companyId) }}
              submitLabel="Save access"
              fields={assignFields}
            />
          ) : (
            <p className="text-sm text-slate-600">You can view the team, but only a company administrator can change access.</p>
          )}
          <p className="mt-4 text-xs text-slate-500">
            Role examples: {roleRows.slice(0, 4).map((r) => humanize(r.name)).join(", ")} and more.
          </p>
        </Card>
      </div>
    </>
  );
}

import { and, count, desc, eq, ilike, or, type SQL } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { createCustomer } from "@/app/actions/crm";
import { ActionForm } from "@/components/action-form";
import { Card, Flash, PageHeader, Pagination, btnPrimary, btnSecondary, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { branches, customers, users } from "@/db/schema";
import { customerFieldDefs } from "@/lib/forms/crm-fields";
import { CUSTOMER_CATEGORY_KEYS, PAGE_SIZE, humanize, optionsOf, type CustomerCategory } from "@/lib/constants";
import { escapeLike, firstParam, formatDate, parseId, parsePage } from "@/lib/format";
import { branchWhere, listCompanyMembers, requirePage } from "@/lib/permissions";
import { daysBetweenISO, todayISO, addDaysISO } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function CustomersPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "crm", "view");
  const sp = await searchParams;

  const q = firstParam(sp.q).trim();
  const category = firstParam(sp.category);
  const page = parsePage(firstParam(sp.page));

  const conditions: (SQL | undefined)[] = [
    eq(customers.companyId, companyId),
    eq(customers.isArchived, false),
    branchWhere(ctx, customers.branchId),
  ];
  if (q) {
    const like = `%${escapeLike(q)}%`;
    conditions.push(or(ilike(customers.fullName, like), ilike(customers.phone, like), ilike(customers.email, like), ilike(customers.code, like), ilike(customers.passportNumber, like)));
  }
  if ((CUSTOMER_CATEGORY_KEYS as readonly string[]).includes(category)) {
    conditions.push(eq(customers.category, category as CustomerCategory));
  }
  const where = and(...conditions);

  const [rows, totalRows, members] = await Promise.all([
    db
      .select({ customer: customers, assigneeName: users.fullName })
      .from(customers)
      .leftJoin(users, eq(users.id, customers.assignedUserId))
      .where(where)
      .orderBy(desc(customers.createdAt))
      .limit(PAGE_SIZE)
      .offset((page - 1) * PAGE_SIZE),
    db.select({ value: count() }).from(customers).where(where),
    listCompanyMembers(companyId),
  ]);
  const total = Number(totalRows[0]?.value ?? 0);
  const today = todayISO();
  const sixMonths = addDaysISO(today, 182);
  const memberOptions = members.map((m) => ({ value: String(m.id), label: `${m.fullName} (${m.roleName})` }));

  const branchRows = await db
    .select({ id: branches.id, name: branches.name })
    .from(branches)
    .where(and(eq(branches.companyId, companyId), eq(branches.isActive, true)));

  return (
    <>
      <PageHeader
        title="Customers"
        description="Everyone who has become a customer. Each customer has one profile that is shared by visas, invoices, receipts and follow-ups."
        actions={
          ctx.can("crm", "export") ? (
            <a href={`/api/export?companyId=${companyId}&type=customers`} className={btnSecondary}>
              Export CSV
            </a>
          ) : null
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      {ctx.can("crm", "create") ? (
        <details className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <summary className="cursor-pointer select-none text-base font-semibold text-slate-900">+ Register a new customer</summary>
          <div className="mt-5">
            <ActionForm
              action={createCustomer}
              hidden={{ companyId: String(companyId) }}
              submitLabel="Save customer"
              fields={customerFieldDefs({
                members: memberOptions,
                creating: true,
                defaults: {},
              }).concat(
                branchRows.length > 0 && !ctx.branchId
                  ? [{ name: "branchId", label: "Branch", type: "select" as const, options: [{ value: "", label: "Not set" }, ...branchRows.map((b) => ({ value: String(b.id), label: b.name }))] }]
                  : [],
              )}
            />
          </div>
        </details>
      ) : null}

      <Card>
        <form method="get" className="mb-5 grid gap-3 md:grid-cols-[1fr_14rem_auto]">
          <input
            name="q"
            defaultValue={q}
            placeholder="Search name, phone, email, code or passport number"
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm"
          />
          <select name="category" defaultValue={category} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="">All categories</option>
            {optionsOf(CUSTOMER_CATEGORY_KEYS).map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <button type="submit" className={btnPrimary}>
            Search
          </button>
        </form>

        <div className="overflow-x-auto">
          <table className={tableClass}>
            <thead>
              <tr>
                <th className={thClass}>Code</th>
                <th className={thClass}>Name</th>
                <th className={thClass}>Phone</th>
                <th className={thClass}>Category</th>
                <th className={thClass}>Relationship manager</th>
                <th className={thClass}>Passport expiry</th>
                <th className={thClass}>Since</th>
                <th className={thClass}></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.length === 0 ? (
                <tr>
                  <td className={tdClass} colSpan={8}>
                    No customers found. Convert a lead or register a customer to start.
                  </td>
                </tr>
              ) : null}
              {rows.map(({ customer, assigneeName }) => {
                const expiring = customer.passportExpiry && customer.passportExpiry <= sixMonths;
                return (
                  <tr key={customer.id} className="hover:bg-slate-50">
                    <td className={tdClass}>
                      <Link href={`/c/${companyId}/crm/customers/${customer.id}`} className="font-medium text-teal-800 hover:underline">
                        {customer.code}
                      </Link>
                    </td>
                    <td className={tdClass}>
                      <p className="font-medium text-slate-900">{customer.fullName}</p>
                      <p className="text-xs text-slate-500">{customer.email ?? ""}</p>
                    </td>
                    <td className={tdClass}>{customer.phone ?? "—"}</td>
                    <td className={tdClass}>{humanize(customer.category)}</td>
                    <td className={tdClass}>{assigneeName ?? "—"}</td>
                    <td className={tdClass}>
                      {customer.passportExpiry ? (
                        <span className={expiring ? "font-medium text-red-700" : ""}>
                          {formatDate(customer.passportExpiry)}
                          {expiring ? ` (${Math.max(daysBetweenISO(today, customer.passportExpiry), 0)} days)` : ""}
                        </span>
                      ) : (
                        "—"
                      )}
                    </td>
                    <td className={tdClass}>{formatDate(customer.createdAt)}</td>
                    <td className={tdClass}>
                      <Link href={`/c/${companyId}/crm/customers/${customer.id}`} className={btnSmall}>
                        Open
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <Pagination basePath={`/c/${companyId}/crm/customers`} page={page} pageSize={PAGE_SIZE} total={total} query={{ q, category }} />
      </Card>
    </>
  );
}

import { and, asc, desc, eq, inArray, ne, sql } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { addActivity, scheduleFollowUp, updateCustomer } from "@/app/actions/crm";
import { uploadDocument } from "@/app/actions/documents";
import { ActionForm } from "@/components/action-form";
import { Badge, Card, DetailList, Flash, PageHeader, Stat, StatusBadge, btnSmall } from "@/components/ui";
import { db } from "@/db";
import { activities, documents, followUps, invoices, leads, receipts, users, visaApplications, customers, branches } from "@/db/schema";
import { customerFieldDefs } from "@/lib/forms/crm-fields";
import { customerAdvanceCents } from "@/lib/ledger";
import { CUSTOMER_CATEGORY_KEYS, DOCUMENT_CATEGORY_KEYS, humanize, optionsOf } from "@/lib/constants";
import { firstParam, formatBDT, formatDate, formatDateTime, maskIdentifier, parseId } from "@/lib/format";
import { centsToDb, dbToCents } from "@/lib/money";
import { branchWhere, inBranchScope, listCompanyMembers, requirePage } from "@/lib/permissions";
import { UPLOAD_ACCEPT } from "@/lib/storage";

export const dynamic = "force-dynamic";

export default async function CustomerDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string; customerId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const routeParams = await params;
  const companyId = parseId(routeParams.companyId);
  const customerId = parseId(routeParams.customerId);
  if (!companyId || !customerId) notFound();
  const ctx = await requirePage(companyId, "crm", "view");
  const sp = await searchParams;

  const [customer] = await db
    .select({ customer: customers, assigneeName: users.fullName })
    .from(customers)
    .leftJoin(users, eq(users.id, customers.assignedUserId))
    .where(and(eq(customers.id, customerId), eq(customers.companyId, companyId)))
    .limit(1);
  if (!customer || !inBranchScope(ctx, customer.customer.branchId)) notFound();
  const c = customer.customer;

  const canEdit = ctx.can("crm", "edit");
  const canCreate = ctx.can("crm", "create");
  const canSeeAccounts = ctx.can("accounting", "view");
  const canSeeVisa = ctx.can("visa", "view");
  const canSeeDocs = ctx.can("documents", "view");
  const canSeePassport = canSeeDocs;

  const [members, timeline, customerFollowUps, visaRows, invoiceRows, receiptRows, documentRows, leadRows, branchRows, advance] =
    await Promise.all([
      listCompanyMembers(companyId),
      db
        .select({ activity: activities, actorName: users.fullName })
        .from(activities)
        .leftJoin(users, eq(users.id, activities.createdById))
        .where(and(eq(activities.companyId, companyId), eq(activities.customerId, customerId)))
        .orderBy(desc(activities.createdAt))
        .limit(60),
      db
        .select()
        .from(followUps)
        .where(and(eq(followUps.companyId, companyId), eq(followUps.customerId, customerId), eq(followUps.status, "open")))
        .orderBy(asc(followUps.dueAt))
        .limit(20),
      canSeeVisa
        ? db
            .select()
            .from(visaApplications)
            .where(and(eq(visaApplications.companyId, companyId), eq(visaApplications.customerId, customerId), branchWhere(ctx, visaApplications.branchId)))
            .orderBy(desc(visaApplications.createdAt))
        : Promise.resolve([]),
      canSeeAccounts
        ? db
            .select()
            .from(invoices)
            .where(and(eq(invoices.companyId, companyId), eq(invoices.customerId, customerId), branchWhere(ctx, invoices.branchId)))
            .orderBy(desc(invoices.issueDate))
            .limit(50)
        : Promise.resolve([]),
      canSeeAccounts
        ? db
            .select()
            .from(receipts)
            .where(and(eq(receipts.companyId, companyId), eq(receipts.customerId, customerId), branchWhere(ctx, receipts.branchId)))
            .orderBy(desc(receipts.receiptDate))
            .limit(50)
        : Promise.resolve([]),
      canSeeDocs
        ? db
            .select()
            .from(documents)
            .where(and(eq(documents.companyId, companyId), eq(documents.customerId, customerId)))
            .orderBy(desc(documents.createdAt))
        : Promise.resolve([]),
      db
        .select({ id: leads.id, code: leads.code, status: leads.status, fullName: leads.fullName })
        .from(leads)
        .where(and(eq(leads.companyId, companyId), eq(leads.customerId, customerId)))
        .orderBy(desc(leads.createdAt))
        .limit(10),
      db.select({ id: branches.id, name: branches.name }).from(branches).where(and(eq(branches.companyId, companyId), eq(branches.isActive, true))),
      canSeeAccounts ? customerAdvanceCents(companyId, customerId) : Promise.resolve(0),
    ]);

  // Balances from real invoice and receipt records.
  const billedCents = invoiceRows
    .filter((i) => i.docType === "invoice" && i.status !== "cancelled")
    .reduce((sum, i) => sum + dbToCents(i.total), 0);
  const outstandingCents = invoiceRows
    .filter((i) => i.docType === "invoice" && (i.status === "issued" || i.status === "partially_paid"))
    .reduce((sum, i) => sum + dbToCents(i.dueAmount), 0);
  const paidCents = receiptRows
    .filter((r) => r.status === "active" && r.kind === "payment")
    .reduce((sum, r) => sum + dbToCents(r.amount), 0);
  const refundedCents = receiptRows
    .filter((r) => r.status === "active" && r.kind === "refund")
    .reduce((sum, r) => sum + dbToCents(r.amount), 0);

  const memberOptions = members.map((m) => ({ value: String(m.id), label: `${m.fullName} (${m.roleName})` }));
  const customerDefaults: Record<string, string> = {
    fullName: c.fullName,
    phone: c.phone ?? "",
    altPhone: c.altPhone ?? "",
    email: c.email ?? "",
    dateOfBirth: c.dateOfBirth ?? "",
    address: c.address ?? "",
    city: c.city ?? "",
    country: c.country ?? "",
    nationality: c.nationality ?? "",
    occupation: c.occupation ?? "",
    passportNumber: c.passportNumber ?? "",
    passportExpiry: c.passportExpiry ?? "",
    category: c.category,
    interestedService: c.interestedService ?? "",
    assignedUserId: c.assignedUserId ? String(c.assignedUserId) : "",
    notes: c.notes ?? "",
    consentMarketing: c.consentMarketing ? "true" : "false",
  };

  return (
    <>
      <PageHeader
        title={c.fullName}
        description={`Customer ${c.code} · ${humanize(c.category)}${c.phone ? ` · ${c.phone}` : ""}`}
        actions={
          <>
            {canSeeVisa && ctx.can("visa", "create") ? (
              <Link href={`/c/${companyId}/visa/applications?addVisa=1&customerId=${customerId}`} className={btnSmall}>
                New visa file
              </Link>
            ) : null}
            {canSeeAccounts && ctx.can("accounting", "create") ? (
              <Link href={`/c/${companyId}/accounting/invoices/new?customerId=${customerId}`} className={btnSmall}>
                New invoice
              </Link>
            ) : null}
            {canSeeAccounts && ctx.can("accounting", "create") ? (
              <Link href={`/c/${companyId}/accounting/receipts/new?customerId=${customerId}`} className={btnSmall}>
                Record payment
              </Link>
            ) : null}
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      {canSeeAccounts ? (
        <div className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          <Stat label="Total billed" value={formatBDT(centsToDb(billedCents))} hint="Invoices, excluding cancelled" />
          <Stat label="Paid to date" value={formatBDT(centsToDb(paidCents - refundedCents))} hint="Payments minus refunds" />
          <Stat label="Still owed" value={formatBDT(centsToDb(outstandingCents))} tone={outstandingCents > 0 ? "red" : "slate"} hint="Unpaid invoice balance" />
          <Stat label="Advance held" value={formatBDT(centsToDb(advance))} hint="Paid but not yet applied" />
          <Stat label="Lifetime value" value={formatBDT(centsToDb(paidCents - refundedCents))} hint="Net money received" />
        </div>
      ) : null}

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <Card title="Profile">
            <DetailList
              items={[
                { label: "Phone", value: c.phone },
                { label: "Alternative phone", value: c.altPhone },
                { label: "Email", value: c.email },
                { label: "Date of birth", value: formatDate(c.dateOfBirth) },
                { label: "Address", value: [c.address, c.city, c.country].filter(Boolean).join(", ") || null },
                { label: "Nationality", value: c.nationality },
                { label: "Occupation", value: c.occupation },
                { label: "Passport number", value: canSeePassport ? c.passportNumber : maskIdentifier(c.passportNumber) },
                { label: "Passport expiry", value: formatDate(c.passportExpiry) },
                { label: "Main interest", value: c.interestedService },
                { label: "Relationship manager", value: customer.assigneeName ?? "Not assigned" },
                { label: "Marketing consent", value: c.consentMarketing ? "Yes" : "No" },
                { label: "Notes", value: c.notes },
              ]}
            />
            {canEdit ? (
              <details className="mt-6 rounded-xl border border-slate-200 p-4">
                <summary className="cursor-pointer select-none text-sm font-semibold text-slate-900">Edit customer details</summary>
                <div className="mt-4">
                  <ActionForm
                    action={updateCustomer}
                    hidden={{ companyId: String(companyId), customerId: String(customerId) }}
                    submitLabel="Save changes"
                    fields={customerFieldDefs({ members: memberOptions, defaults: customerDefaults, includePassport: canSeePassport })}
                  />
                </div>
              </details>
            ) : null}
          </Card>

          <Card title="Timeline" description="Everything that happened with this customer, newest first.">
            {canCreate ? (
              <form action={addActivity} className="mb-6 grid gap-3 rounded-xl bg-slate-50 p-4 md:grid-cols-[10rem_1fr]">
                <input type="hidden" name="companyId" value={companyId} />
                <input type="hidden" name="customerId" value={customerId} />
                <select name="type" defaultValue="call" className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
                  <option value="call">Call</option>
                  <option value="meeting">Meeting</option>
                  <option value="whatsapp">WhatsApp</option>
                  <option value="email">Email</option>
                  <option value="note">Note</option>
                </select>
                <div className="space-y-2">
                  <input name="summary" required placeholder="Summary, e.g. Discussed honeymoon package and payment plan" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                  <textarea name="details" rows={2} placeholder="More detail (optional)" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                  <button type="submit" className="rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800">
                    Add to timeline
                  </button>
                </div>
              </form>
            ) : null}
            {timeline.length === 0 ? (
              <p className="text-sm text-slate-600">No activity yet.</p>
            ) : (
              <ol className="relative space-y-4 border-l border-slate-200 pl-5">
                {timeline.map(({ activity, actorName }) => (
                  <li key={activity.id}>
                    <span className="absolute -left-1.5 mt-1.5 h-3 w-3 rounded-full border-2 border-white bg-teal-600" />
                    <p className="text-sm font-medium text-slate-900">
                      {activity.summary} <Badge>{humanize(activity.type)}</Badge>
                    </p>
                    {activity.details ? <p className="mt-0.5 whitespace-pre-line text-sm text-slate-700">{activity.details}</p> : null}
                    <p className="mt-0.5 text-xs text-slate-500">
                      {formatDateTime(activity.createdAt)} · {actorName ?? "System"}
                    </p>
                  </li>
                ))}
              </ol>
            )}
          </Card>

          {canSeeDocs ? (
            <Card title="Documents" description="Passports, IDs and other files. Files are private and only open for people with permission.">
              {documentRows.length === 0 ? (
                <p className="mb-4 text-sm text-slate-600">No documents uploaded yet.</p>
              ) : (
                <ul className="mb-5 divide-y divide-slate-100">
                  {documentRows.map((doc) => (
                    <li key={doc.id} className="flex items-center justify-between gap-3 py-2.5">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-slate-900">{doc.title}</p>
                        <p className="text-xs text-slate-500">
                          {humanize(doc.category)} · {formatDate(doc.createdAt)} · {Math.round(doc.sizeBytes / 1024)} KB
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <a href={`/api/files/${doc.id}`} target="_blank" rel="noopener" className={btnSmall}>
                          Open
                        </a>
                        <a href={`/api/files/${doc.id}?download=1`} className={btnSmall}>
                          Download
                        </a>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
              {ctx.can("documents", "create") ? (
                <ActionForm
                  action={uploadDocument}
                  columns={2}
                  submitLabel="Upload document"
                  hidden={{ companyId: String(companyId), module: "crm", customerId: String(customerId) }}
                  fields={[
                    { name: "title", label: "Document name", placeholder: "e.g. Passport bio page" },
                    {
                      name: "category",
                      label: "Type",
                      type: "select",
                      options: ["passport", "nid", "photo", "contract", "other"].map((k) => ({ value: k, label: humanize(k) })),
                      defaultValue: "passport",
                    },
                    { name: "file", label: "File (PDF, JPG, PNG or WEBP, max 10 MB)", type: "file", required: true, accept: UPLOAD_ACCEPT, wide: true },
                  ]}
                />
              ) : null}
            </Card>
          ) : null}
        </div>

        <div className="space-y-6">
          {canCreate ? (
            <Card title="Schedule a follow-up">
              <ActionForm
                action={scheduleFollowUp}
                columns={1}
                hidden={{ companyId: String(companyId), customerId: String(customerId) }}
                submitLabel="Schedule follow-up"
                fields={[
                  { name: "title", label: "What to do", required: true },
                  { name: "dueAt", label: "When", type: "datetime-local", required: true },
                  { name: "assignedUserId", label: "Assign to", type: "select", options: [{ value: "", label: "Me" }, ...memberOptions] },
                ]}
              />
            </Card>
          ) : null}

          <Card title="Open follow-ups">
            {customerFollowUps.length === 0 ? (
              <p className="text-sm text-slate-600">Nothing scheduled.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {customerFollowUps.map((item) => (
                  <li key={item.id} className="py-2.5">
                    <p className="text-sm font-medium text-slate-900">{item.title}</p>
                    <p className="text-xs text-slate-500">Due {formatDateTime(item.dueAt)}</p>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          {canSeeVisa ? (
            <Card title="Visa files" actions={ctx.can("visa", "view") ? <Link href={`/c/${companyId}/visa/applications?q=${encodeURIComponent(c.code)}`} className="text-sm font-medium text-teal-800 hover:underline">All</Link> : null}>
              {visaRows.length === 0 ? (
                <p className="text-sm text-slate-600">No visa files for this customer.</p>
              ) : (
                <ul className="divide-y divide-slate-100">
                  {visaRows.map((v) => (
                    <li key={v.id} className="flex items-center justify-between py-2.5">
                      <Link href={`/c/${companyId}/visa/applications/${v.id}`} className="text-sm font-medium text-teal-800 hover:underline">
                        {v.code} · {v.destinationCountry}
                      </Link>
                      <StatusBadge status={v.status} />
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          ) : null}

          {canSeeAccounts ? (
            <Card title="Invoices and receipts">
              {invoiceRows.length === 0 && receiptRows.length === 0 ? (
                <p className="text-sm text-slate-600">No invoices or receipts yet.</p>
              ) : (
                <div className="space-y-4">
                  {invoiceRows.length > 0 ? (
                    <ul className="divide-y divide-slate-100">
                      {invoiceRows.slice(0, 8).map((inv) => (
                        <li key={inv.id} className="flex items-center justify-between gap-2 py-2">
                          <Link href={`/c/${companyId}/accounting/invoices/${inv.id}`} className="text-sm text-teal-800 hover:underline">
                            {inv.number}
                          </Link>
                          <div className="text-right text-xs">
                            <p className="font-medium text-slate-900">{formatBDT(inv.total)}</p>
                            <StatusBadge status={inv.status} />
                          </div>
                        </li>
                      ))}
                    </ul>
                  ) : null}
                  {receiptRows.length > 0 ? (
                    <ul className="divide-y divide-slate-100">
                      {receiptRows.slice(0, 8).map((r) => (
                        <li key={r.id} className="flex items-center justify-between gap-2 py-2">
                          <Link href={`/c/${companyId}/accounting/receipts/${r.id}`} className="text-sm text-teal-800 hover:underline">
                            {r.number}
                          </Link>
                          <div className="text-right text-xs">
                            <p className="font-medium text-slate-900">{formatBDT(r.amount)}</p>
                            <StatusBadge status={r.status} label={r.kind === "refund" ? "Refund" : undefined} />
                          </div>
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </div>
              )}
            </Card>
          ) : null}

          {leadRows.length > 0 ? (
            <Card title="Original leads">
              <ul className="divide-y divide-slate-100">
                {leadRows.map((l) => (
                  <li key={l.id} className="flex items-center justify-between py-2">
                    <Link href={`/c/${companyId}/crm/leads/${l.id}`} className="text-sm text-teal-800 hover:underline">
                      {l.code}
                    </Link>
                    <StatusBadge status={l.status} />
                  </li>
                ))}
              </ul>
            </Card>
          ) : null}
        </div>
      </div>
    </>
  );
}

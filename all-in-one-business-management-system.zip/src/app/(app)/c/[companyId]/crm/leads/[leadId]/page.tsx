import { and, asc, desc, eq } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { addActivity, assignLead, completeFollowUp, convertLead, scheduleFollowUp, setLeadStatus } from "@/app/actions/crm";
import { ActionForm } from "@/components/action-form";
import { Badge, Card, DetailList, Flash, PageHeader, StatusBadge, btnPrimary, btnSmall, toneFor } from "@/components/ui";
import { ConfirmSubmit } from "@/components/confirm-submit";
import { db } from "@/db";
import { activities, campaigns, customers, followUps, leads, users } from "@/db/schema";
import { ACTIVITY_TYPE_KEYS, LEAD_STATUS_KEYS, humanize, optionsOf } from "@/lib/constants";
import { formatDate, formatDateTime, firstParam, parseId } from "@/lib/format";
import { formatBDT } from "@/lib/format";
import { inBranchScope, listCompanyMembers, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function LeadDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string; leadId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const routeParams = await params;
  const companyId = parseId(routeParams.companyId);
  const leadId = parseId(routeParams.leadId);
  if (!companyId || !leadId) notFound();
  const ctx = await requirePage(companyId, "crm", "view");
  const sp = await searchParams;

  const [row] = await db
    .select({
      lead: leads,
      assigneeName: users.fullName,
      campaignName: campaigns.name,
      customerName: customers.fullName,
      customerCode: customers.code,
    })
    .from(leads)
    .leftJoin(users, eq(users.id, leads.assignedUserId))
    .leftJoin(campaigns, eq(campaigns.id, leads.campaignId))
    .leftJoin(customers, eq(customers.id, leads.customerId))
    .where(and(eq(leads.id, leadId), eq(leads.companyId, companyId)))
    .limit(1);
  if (!row || !inBranchScope(ctx, row.lead.branchId)) notFound();

  const [timeline, followUpRows, members] = await Promise.all([
    db
      .select({ activity: activities, actorName: users.fullName })
      .from(activities)
      .leftJoin(users, eq(users.id, activities.createdById))
      .where(and(eq(activities.companyId, companyId), eq(activities.leadId, leadId)))
      .orderBy(desc(activities.createdAt))
      .limit(100),
    db
      .select()
      .from(followUps)
      .where(and(eq(followUps.companyId, companyId), eq(followUps.leadId, leadId)))
      .orderBy(asc(followUps.dueAt)),
    listCompanyMembers(companyId),
  ]);

  const lead = row.lead;
  const converted = lead.status === "converted";
  const canEdit = ctx.can("crm", "edit");
  const canCreate = ctx.can("crm", "create");
  const memberOptions = members.map((m) => ({ value: String(m.id), label: `${m.fullName} (${m.roleName})` }));

  return (
    <>
      <PageHeader
        title={lead.fullName}
        description={`Lead ${lead.code} · ${humanize(lead.leadSource)}${lead.interestedService ? ` · ${lead.interestedService}` : ""}`}
        actions={
          <>
            <StatusBadge status={lead.status} />
            {converted && lead.customerId ? (
              <Link href={`/c/${companyId}/crm/customers/${lead.customerId}`} className={btnPrimary}>
                Open customer {row.customerCode}
              </Link>
            ) : canCreate ? (
              <form action={convertLead}>
                <input type="hidden" name="companyId" value={companyId} />
                <input type="hidden" name="leadId" value={leadId} />
                <ConfirmSubmit
                  label="Convert to customer"
                  message="Convert this lead into a customer? If a customer with the same phone or email exists, this lead will be linked to that customer."
                  className={btnPrimary}
                />
              </form>
            ) : null}
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <Card title="Lead details">
            <DetailList
              items={[
                { label: "Phone", value: lead.phone },
                { label: "Email", value: lead.email },
                { label: "City", value: lead.city },
                { label: "Lead source", value: humanize(lead.leadSource) },
                { label: "Interested in", value: lead.interestedService },
                { label: "Expected value", value: formatBDT(lead.expectedValue) },
                { label: "Assigned to", value: row.assigneeName ?? "Unassigned" },
                { label: "Campaign", value: row.campaignName },
                { label: "Added on", value: formatDate(lead.createdAt) },
                { label: "Lost reason", value: lead.lostReason },
                { label: "Notes", value: lead.notes },
              ]}
            />
          </Card>

          <Card title="Timeline" description="Calls, meetings, notes and status changes. Newest first.">
            {canCreate ? (
              <form action={addActivity} className="mb-6 grid gap-3 rounded-xl bg-slate-50 p-4 md:grid-cols-[10rem_1fr]">
                <input type="hidden" name="companyId" value={companyId} />
                <input type="hidden" name="leadId" value={leadId} />
                <select name="type" defaultValue="call" className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
                  {optionsOf(ACTIVITY_TYPE_KEYS.filter((k) => k !== "status_change" && k !== "system" && k !== "follow_up")).map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
                <div className="space-y-2">
                  <input name="summary" required placeholder="What happened? e.g. Called, interested in Umrah package in November" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                  <textarea name="details" rows={2} placeholder="More detail (optional)" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                  <button type="submit" className={btnPrimary}>
                    Add to timeline
                  </button>
                </div>
              </form>
            ) : null}
            {timeline.length === 0 ? (
              <p className="text-sm text-slate-600">Nothing recorded yet.</p>
            ) : (
              <ol className="relative space-y-4 border-l border-slate-200 pl-5">
                {timeline.map(({ activity, actorName }) => (
                  <li key={activity.id}>
                    <span className="absolute -left-1.5 mt-1.5 h-3 w-3 rounded-full border-2 border-white bg-teal-600" />
                    <p className="text-sm font-medium text-slate-900">
                      {activity.summary} <Badge>{humanize(activity.type)}</Badge>
                    </p>
                    {activity.details ? <p className="mt-0.5 whitespace-pre-line text-sm text-slate-700">{activity.details}</p> : null}
                    <p className="mt-0.5 text-xs text-slate-500">
                      {formatDateTime(activity.createdAt)} · {actorName ?? "System"}
                    </p>
                  </li>
                ))}
              </ol>
            )}
          </Card>
        </div>

        <div className="space-y-6">
          {canEdit && !converted ? (
            <Card title="Change status">
              <form action={setLeadStatus} className="space-y-3">
                <input type="hidden" name="companyId" value={companyId} />
                <input type="hidden" name="leadId" value={leadId} />
                <select name="status" defaultValue={lead.status} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                  {LEAD_STATUS_KEYS.filter((k) => k !== "converted").map((key) => (
                    <option key={key} value={key}>
                      {humanize(key)}
                    </option>
                  ))}
                </select>
                <input name="reason" placeholder="Reason (needed if lost or not interested)" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                <input name="note" placeholder="Short note (optional)" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                <button type="submit" className={btnPrimary}>
                  Update status
                </button>
              </form>
            </Card>
          ) : null}

          {ctx.can("crm", "assign") && !converted ? (
            <Card title="Assign to a team member">
              <form action={assignLead} className="space-y-3">
                <input type="hidden" name="companyId" value={companyId} />
                <input type="hidden" name="leadId" value={leadId} />
                <select name="assignedUserId" defaultValue={lead.assignedUserId ? String(lead.assignedUserId) : ""} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                  <option value="">Unassigned</option>
                  {memberOptions.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
                <button type="submit" className={btnPrimary}>
                  Save assignment
                </button>
              </form>
            </Card>
          ) : null}

          {canCreate && !converted ? (
            <Card title="Schedule a follow-up">
              <ActionForm
                action={scheduleFollowUp}
                columns={1}
                hidden={{ companyId: String(companyId), leadId: String(leadId) }}
                submitLabel="Schedule follow-up"
                fields={[
                  { name: "title", label: "What to do", required: true, placeholder: "e.g. Send visa checklist on WhatsApp" },
                  { name: "dueAt", label: "When", type: "datetime-local", required: true },
                  { name: "assignedUserId", label: "Assign to", type: "select", options: [{ value: "", label: "Me" }, ...memberOptions] },
                  { name: "notes", label: "Notes", type: "textarea" },
                ]}
              />
            </Card>
          ) : null}

          <Card title="Follow-ups">
            {followUpRows.length === 0 ? (
              <p className="text-sm text-slate-600">No follow-ups for this lead.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {followUpRows.map((item) => (
                  <li key={item.id} className="py-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-sm font-medium text-slate-900">{item.title}</p>
                        <p className="text-xs text-slate-500">Due {formatDateTime(item.dueAt)}</p>
                      </div>
                      <Badge tone={toneFor(item.status)}>{humanize(item.status)}</Badge>
                    </div>
                    {item.status === "open" && canEdit ? (
                      <div className="mt-2 flex gap-2">
                        <form action={completeFollowUp}>
                          <input type="hidden" name="companyId" value={companyId} />
                          <input type="hidden" name="followUpId" value={item.id} />
                          <input type="hidden" name="outcome" value="done" />
                          <button type="submit" className={btnSmall}>
                            Mark done
                          </button>
                        </form>
                        <form action={completeFollowUp}>
                          <input type="hidden" name="companyId" value={companyId} />
                          <input type="hidden" name="followUpId" value={item.id} />
                          <input type="hidden" name="outcome" value="cancelled" />
                          <button type="submit" className={btnSmall}>
                            Cancel
                          </button>
                        </form>
                      </div>
                    ) : null}
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
      <p className="mt-6 text-xs text-slate-500">Valid statuses: {LEAD_STATUS_KEYS.map(humanize).join(", ")}.</p>
    </>
  );
}

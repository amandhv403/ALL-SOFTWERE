import { and, count, desc, eq, ilike, isNull, or, type SQL } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { createLead } from "@/app/actions/crm";
import { ActionForm } from "@/components/action-form";
import { Card, Flash, PageHeader, Pagination, StatusBadge, btnPrimary, btnSecondary, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { branches, campaigns, leads, users } from "@/db/schema";
import { leadFieldDefs } from "@/lib/forms/crm-fields";
import { LEAD_SOURCE_KEYS, LEAD_STATUS_KEYS, PAGE_SIZE, humanize, optionsOf, type LeadSource, type LeadStatus } from "@/lib/constants";
import { escapeLike, firstParam, formatDate, parseId, parsePage } from "@/lib/format";
import { branchWhere, listCompanyMembers, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function LeadsPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "crm", "view");
  const sp = await searchParams;

  const q = firstParam(sp.q).trim();
  const status = firstParam(sp.status);
  const source = firstParam(sp.source);
  const owner = firstParam(sp.owner) || "all";
  const page = parsePage(firstParam(sp.page));

  const conditions: (SQL | undefined)[] = [eq(leads.companyId, companyId), branchWhere(ctx, leads.branchId)];
  if (q) {
    const like = `%${escapeLike(q)}%`;
    conditions.push(or(ilike(leads.fullName, like), ilike(leads.phone, like), ilike(leads.email, like), ilike(leads.code, like)));
  }
  if ((LEAD_STATUS_KEYS as readonly string[]).includes(status)) conditions.push(eq(leads.status, status as LeadStatus));
  if ((LEAD_SOURCE_KEYS as readonly string[]).includes(source)) conditions.push(eq(leads.leadSource, source as LeadSource));
  if (owner === "me") conditions.push(eq(leads.assignedUserId, ctx.user.id));
  if (owner === "unassigned") conditions.push(isNull(leads.assignedUserId));
  const where = and(...conditions);

  const [rows, totalRows, members, branchRows, campaignRows] = await Promise.all([
    db
      .select({ lead: leads, assigneeName: users.fullName })
      .from(leads)
      .leftJoin(users, eq(users.id, leads.assignedUserId))
      .where(where)
      .orderBy(desc(leads.createdAt))
      .limit(PAGE_SIZE)
      .offset((page - 1) * PAGE_SIZE),
    db.select({ value: count() }).from(leads).where(where),
    listCompanyMembers(companyId),
    db.select({ id: branches.id, name: branches.name }).from(branches).where(and(eq(branches.companyId, companyId), eq(branches.isActive, true))),
    db.select({ id: campaigns.id, name: campaigns.name }).from(campaigns).where(eq(campaigns.companyId, companyId)),
  ]);
  const total = Number(totalRows[0]?.value ?? 0);
  const canCreate = ctx.can("crm", "create");

  const memberOptions = members.map((m) => ({ value: String(m.id), label: `${m.fullName} (${m.roleName})` }));
  const branchOptions = branchRows.map((b) => ({ value: String(b.id), label: b.name }));
  const campaignOptions = campaignRows.map((c) => ({ value: String(c.id), label: c.name }));

  return (
    <>
      <PageHeader
        title="Leads"
        description="People who have shown interest but are not yet customers. Work each lead, then convert it into a customer when it is ready."
        actions={
          <>
            <Link href={`/c/${companyId}/sales/pipeline`} className={btnSecondary}>
              Pipeline view
            </Link>
            {ctx.can("crm", "export") ? (
              <a href={`/api/export?companyId=${companyId}&type=leads`} className={btnSecondary}>
                Export CSV
              </a>
            ) : null}
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      {canCreate ? (
        <details className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm" open={Boolean(firstParam(sp.addLead))}>
          <summary className="cursor-pointer select-none text-base font-semibold text-slate-900">+ Add a new lead</summary>
          <div className="mt-5">
            <ActionForm
              action={createLead}
              hidden={{ companyId: String(companyId) }}
              submitLabel="Save lead"
              fields={leadFieldDefs({ members: memberOptions, branches: branchOptions, campaigns: campaignOptions })}
            />
          </div>
        </details>
      ) : null}

      <Card>
        <form method="get" className="mb-5 grid gap-3 md:grid-cols-[1fr_repeat(3,minmax(0,12rem))_auto]">
          <input
            name="q"
            defaultValue={q}
            placeholder="Search name, phone, email or code"
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-teal-600 focus:outline-none focus:ring-2 focus:ring-teal-600/20"
          />
          <select name="status" defaultValue={status} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="">All statuses</option>
            {LEAD_STATUS_KEYS.map((key) => (
              <option key={key} value={key}>
                {humanize(key)}
              </option>
            ))}
          </select>
          <select name="source" defaultValue={source} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="">All sources</option>
            {optionsOf(LEAD_SOURCE_KEYS).map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <select name="owner" defaultValue={owner} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="all">Everyone</option>
            <option value="me">Assigned to me</option>
            <option value="unassigned">Unassigned</option>
          </select>
          <button type="submit" className={btnPrimary}>
            Filter
          </button>
        </form>

        <div className="overflow-x-auto">
          <table className={tableClass}>
            <thead>
              <tr>
                <th className={thClass}>Code</th>
                <th className={thClass}>Name and phone</th>
                <th className={thClass}>Source</th>
                <th className={thClass}>Interested in</th>
                <th className={thClass}>Status</th>
                <th className={thClass}>Assigned to</th>
                <th className={thClass}>Added</th>
                <th className={thClass}></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.length === 0 ? (
                <tr>
                  <td className={tdClass} colSpan={8}>
                    No leads match these filters yet.
                  </td>
                </tr>
              ) : null}
              {rows.map(({ lead, assigneeName }) => (
                <tr key={lead.id} className="hover:bg-slate-50">
                  <td className={tdClass}>
                    <Link href={`/c/${companyId}/crm/leads/${lead.id}`} className="font-medium text-teal-800 hover:underline">
                      {lead.code}
                    </Link>
                  </td>
                  <td className={tdClass}>
                    <p className="font-medium text-slate-900">{lead.fullName}</p>
                    <p className="text-xs text-slate-500">{lead.phone ?? lead.email ?? "No contact"}</p>
                  </td>
                  <td className={tdClass}>{humanize(lead.leadSource)}</td>
                  <td className={tdClass}>{lead.interestedService ?? "—"}</td>
                  <td className={tdClass}>
                    <StatusBadge status={lead.status} />
                  </td>
                  <td className={tdClass}>{assigneeName ?? <span className="text-slate-400">Unassigned</span>}</td>
                  <td className={tdClass}>{formatDate(lead.createdAt)}</td>
                  <td className={tdClass}>
                    <Link href={`/c/${companyId}/crm/leads/${lead.id}`} className={btnSmall}>
                      Open
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination
          basePath={`/c/${companyId}/crm/leads`}
          page={page}
          pageSize={PAGE_SIZE}
          total={total}
          query={{ q, status, source, owner }}
        />
      </Card>
    </>
  );
}

import { and, asc, eq } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { completeFollowUp } from "@/app/actions/crm";
import { Badge, Card, EmptyState, Flash, PageHeader, btnSecondary, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { customers, followUps, leads, users } from "@/db/schema";
import { firstParam, formatDateTime, parseId } from "@/lib/format";
import { requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function FollowUpsPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "crm", "view");
  const sp = await searchParams;
  const scope = firstParam(sp.scope) === "all" ? "all" : "mine";
  const now = new Date();

  const conditions = [eq(followUps.companyId, companyId), eq(followUps.status, "open")];
  if (scope === "mine") conditions.push(eq(followUps.assignedUserId, ctx.user.id));

  const rows = await db
    .select({
      item: followUps,
      leadName: leads.fullName,
      leadId: leads.id,
      customerName: customers.fullName,
      customerId: customers.id,
      assigneeName: users.fullName,
    })
    .from(followUps)
    .leftJoin(leads, eq(leads.id, followUps.leadId))
    .leftJoin(customers, eq(customers.id, followUps.customerId))
    .leftJoin(users, eq(users.id, followUps.assignedUserId))
    .where(and(...conditions))
    .orderBy(asc(followUps.dueAt))
    .limit(200);

  const overdue = rows.filter((r) => r.item.dueAt < now);

  return (
    <>
      <PageHeader
        title="Follow-ups"
        description="Things to do next with leads and customers. Overdue items are shown first in red."
        actions={
          <>
            <Link href={`/c/${companyId}/crm/followups?scope=mine`} className={scope === "mine" ? "rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white" : btnSecondary}>
              Mine
            </Link>
            <Link href={`/c/${companyId}/crm/followups?scope=all`} className={scope === "all" ? "rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white" : btnSecondary}>
              Everyone
            </Link>
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <Card>
        {rows.length === 0 ? (
          <EmptyState title="No open follow-ups" text="When you schedule a follow-up from a lead or customer, it appears here." />
        ) : (
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Due</th>
                  <th className={thClass}>What to do</th>
                  <th className={thClass}>Related to</th>
                  <th className={thClass}>Assigned to</th>
                  <th className={thClass}>Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rows.map((r) => {
                  const isOverdue = r.item.dueAt < now;
                  const link = r.leadId ? `/c/${companyId}/crm/leads/${r.leadId}` : `/c/${companyId}/crm/customers/${r.customerId}`;
                  return (
                    <tr key={r.item.id} className={isOverdue ? "bg-red-50/40" : ""}>
                      <td className={tdClass}>
                        <span className={isOverdue ? "font-medium text-red-700" : ""}>{formatDateTime(r.item.dueAt)}</span>
                        {isOverdue ? <Badge tone="red">Overdue</Badge> : null}
                      </td>
                      <td className={tdClass}>
                        <p className="font-medium text-slate-900">{r.item.title}</p>
                        {r.item.notes ? <p className="text-xs text-slate-500">{r.item.notes}</p> : null}
                      </td>
                      <td className={tdClass}>
                        {r.leadId || r.customerId ? (
                          <Link href={link} className="text-teal-800 hover:underline">
                            {r.leadName ?? r.customerName}
                          </Link>
                        ) : (
                          "—"
                        )}
                      </td>
                      <td className={tdClass}>{r.assigneeName ?? "—"}</td>
                      <td className={tdClass}>
                        {ctx.can("crm", "edit") ? (
                          <div className="flex gap-2">
                            <form action={completeFollowUp}>
                              <input type="hidden" name="companyId" value={companyId} />
                              <input type="hidden" name="followUpId" value={r.item.id} />
                              <input type="hidden" name="outcome" value="done" />
                              <button type="submit" className={btnSmall}>
                                Done
                              </button>
                            </form>
                            <form action={completeFollowUp}>
                              <input type="hidden" name="companyId" value={companyId} />
                              <input type="hidden" name="followUpId" value={r.item.id} />
                              <input type="hidden" name="outcome" value="cancelled" />
                              <button type="submit" className={btnSmall}>
                                Cancel
                              </button>
                            </form>
                          </div>
                        ) : null}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        {overdue.length > 0 ? <p className="mt-4 text-sm text-red-700">{overdue.length} overdue follow-up(s) need attention.</p> : null}
      </Card>
    </>
  );
}

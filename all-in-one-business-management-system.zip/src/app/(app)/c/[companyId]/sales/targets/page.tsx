import { and, count, eq, gte, inArray, lte, sql, type SQL } from "drizzle-orm";
import { notFound } from "next/navigation";
import { createTarget, deleteTarget } from "@/app/actions/sales";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Badge, Card, Flash, PageHeader, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { branches, departments, employees, leads, receipts, targets, tasks, userCompanyAccess, users, visaApplications } from "@/db/schema";
import { humanize, TARGET_METRIC_KEYS, TARGET_PERIOD_KEYS, optionsOf, type TargetMetric, type TargetScope } from "@/lib/constants";
import { addDaysISO, daysBetweenISO, endOfDayDhaka, dhakaToDate, firstParam, formatBDT, formatCount, parseId, todayISO } from "@/lib/format";
import { centsToDb, dbToCents } from "@/lib/money";
import { requirePage, listCompanyMembers } from "@/lib/permissions";

export const dynamic = "force-dynamic";

type Target = typeof targets.$inferSelect;

/** Works out the real result for one target in one period, from the database. Money is returned in cents. */
async function achievedFor(companyId: number, t: Target, start: string, end: string): Promise<number> {
  const from = dhakaToDate(start);
  const to = endOfDayDhaka(end);
  let people: number[] | null = null;
  if (t.scopeType === "employee" && t.scopeId) people = [t.scopeId];
  if (t.scopeType === "department" && t.scopeId) {
    const rows = await db
      .select({ userId: userCompanyAccess.userId })
      .from(userCompanyAccess)
      .where(and(eq(userCompanyAccess.companyId, companyId), eq(userCompanyAccess.departmentId, t.scopeId), eq(userCompanyAccess.isActive, true)));
    people = rows.map((r) => r.userId);
  }
  if (people && people.length === 0) return 0;
  const branchId = t.scopeType === "branch" ? t.scopeId : null;

  const metric = t.metric as TargetMetric;
  if (metric === "revenue") {
    const conds: SQL[] = [eq(receipts.companyId, companyId), eq(receipts.kind, "payment"), eq(receipts.status, "active"), gte(receipts.receiptDate, start), lte(receipts.receiptDate, end)];
    if (branchId) conds.push(eq(receipts.branchId, branchId));
    if (people) conds.push(inArray(receipts.createdById, people));
    const [row] = await db.select({ total: sql<string>`coalesce(sum(${receipts.amount}), 0)` }).from(receipts).where(and(...conds));
    return dbToCents(row?.total);
  }

  let value = 0;
  if (metric === "new_leads" || metric === "leads_converted") {
    const conds: SQL[] = [eq(leads.companyId, companyId), gte(leads.createdAt, from), lte(leads.createdAt, to)];
    if (metric === "leads_converted") conds.push(eq(leads.status, "converted"));
    if (branchId) conds.push(eq(leads.branchId, branchId));
    if (people) conds.push(inArray(leads.assignedUserId, people));
    const [row] = await db.select({ value: count() }).from(leads).where(and(...conds));
    value = Number(row?.value ?? 0);
  }
  if (metric === "visa_applications" || metric === "visas_approved") {
    const conds: SQL[] = [eq(visaApplications.companyId, companyId)];
    if (metric === "visa_applications") conds.push(gte(visaApplications.applicationDate, start), lte(visaApplications.applicationDate, end));
    if (metric === "visas_approved") conds.push(eq(visaApplications.status, "approved"), gte(visaApplications.approvalDate, start), lte(visaApplications.approvalDate, end));
    if (branchId) conds.push(eq(visaApplications.branchId, branchId));
    if (people) conds.push(inArray(visaApplications.assignedUserId, people));
    const [row] = await db.select({ value: count() }).from(visaApplications).where(and(...conds));
    value = Number(row?.value ?? 0);
  }
  if (metric === "tasks_completed") {
    const conds: SQL[] = [eq(tasks.companyId, companyId), eq(tasks.status, "done"), gte(tasks.completedAt, from), lte(tasks.completedAt, to)];
    if (people) conds.push(inArray(tasks.assignedUserId, people));
    const [row] = await db.select({ value: count() }).from(tasks).where(and(...conds));
    value = Number(row?.value ?? 0);
  }
  return value;
}

function isMoney(metric: string): boolean {
  return metric === "revenue";
}

function formatValue(metric: string, value: number): string {
  return isMoney(metric) ? formatBDT(centsToDb(value)) : formatCount(value);
}

export default async function TargetsPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "sales", "view");
  const sp = await searchParams;

  const [targetRows, members, branchRows, departmentRows] = await Promise.all([
    db.select().from(targets).where(eq(targets.companyId, companyId)).orderBy(targets.periodStart),
    listCompanyMembers(companyId),
    db.select({ id: branches.id, name: branches.name }).from(branches).where(and(eq(branches.companyId, companyId), eq(branches.isActive, true))),
    db.select({ id: departments.id, name: departments.name }).from(departments).where(and(eq(departments.companyId, companyId), eq(departments.isActive, true))),
  ]);

  const results = await Promise.all(
    targetRows.map(async (t) => {
      const days = daysBetweenISO(t.periodStart, t.periodEnd) + 1;
      const prevEnd = addDaysISO(t.periodStart, -1);
      const prevStart = addDaysISO(prevEnd, -(days - 1));
      const [current, previous] = await Promise.all([achievedFor(companyId, t, t.periodStart, t.periodEnd), achievedFor(companyId, t, prevStart, prevEnd)]);
      return { t, current, previous };
    }),
  );

  const scopeLabel = (t: Target) => {
    if (t.scopeType === "company") return "Whole company";
    if (t.scopeType === "branch") return `Branch: ${branchRows.find((b) => b.id === t.scopeId)?.name ?? "—"}`;
    if (t.scopeType === "department") return `Department: ${departmentRows.find((d) => d.id === t.scopeId)?.name ?? "—"}`;
    return `Person: ${members.find((m) => m.id === t.scopeId)?.fullName ?? "—"}`;
  };

  const scopeOptions = [
    { value: "company", label: "Whole company" },
    ...branchRows.map((b) => ({ value: `branch:${b.id}`, label: `Branch: ${b.name}` })),
    ...departmentRows.map((d) => ({ value: `department:${d.id}`, label: `Department: ${d.name}` })),
    ...members.map((m) => ({ value: `employee:${m.id}`, label: `Person: ${m.fullName}` })),
  ];

  const fields: FieldDef[] = [
    { name: "label", label: "Target name", required: true, placeholder: "e.g. November visa sales" },
    { name: "scopeChoice", label: "Who is this for?", type: "select", options: scopeOptions, defaultValue: "company" },
    { name: "metric", label: "What to measure", type: "select", options: TARGET_METRIC_KEYS.map((k) => ({ value: k, label: humanize(k) })), defaultValue: "revenue" },
    { name: "periodType", label: "Period", type: "select", options: optionsOf(TARGET_PERIOD_KEYS), defaultValue: "monthly" },
    { name: "periodStart", label: "Period starts on", type: "date", required: true, defaultValue: todayISO().slice(0, 8) + "01" },
    { name: "targetValue", label: "Target (৳ for revenue, count for others)", required: true, placeholder: "e.g. 500000 or 25", help: "Revenue is in taka. Other measures are counts." },
  ];

  return (
    <>
      <PageHeader
        title="Targets and KPIs"
        description="Set goals for the company, a branch, a department or a person. Actual results are calculated from your records, so nothing is typed in by hand."
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2" title="Targets" description="Achieved = result so far. Previous = the same length of time just before this period.">
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Target</th>
                  <th className={thClass}>Measure</th>
                  <th className={thClass}>Period</th>
                  <th className={thClass}>Target</th>
                  <th className={thClass}>Achieved</th>
                  <th className={thClass}>Progress</th>
                  <th className={thClass}>Remaining</th>
                  <th className={thClass}>Previous period</th>
                  {ctx.can("sales", "assign") ? <th className={thClass}></th> : null}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {results.length === 0 ? (
                  <tr>
                    <td className={tdClass} colSpan={9}>
                      No targets yet. Create one using the form on the right.
                    </td>
                  </tr>
                ) : null}
                {results.map(({ t, current, previous }) => {
                  const goal = dbToCents(t.targetValue);
                  const money = isMoney(t.metric);
                  const achievedNumber = money ? current : current * 100;
                  const goalNumber = money ? goal : goal;
                  const pct = goalNumber > 0 ? Math.min(999, Math.round((achievedNumber / goalNumber) * 100)) : 0;
                  const remaining = Math.max(goalNumber - achievedNumber, 0);
                  return (
                    <tr key={t.id}>
                      <td className={tdClass}>
                        <p className="font-medium text-slate-900">{t.label}</p>
                        <p className="text-xs text-slate-500">{scopeLabel(t)}</p>
                      </td>
                      <td className={tdClass}>{humanize(t.metric)}</td>
                      <td className={tdClass}>
                        {humanize(t.periodType)}
                        <p className="text-xs text-slate-500">
                          {t.periodStart} → {t.periodEnd}
                        </p>
                      </td>
                      <td className={tdClass}>{formatValue(t.metric, goal)}</td>
                      <td className={tdClass}>{formatValue(t.metric, current)}</td>
                      <td className={tdClass}>
                        <div className="flex items-center gap-2">
                          <div className="h-2 w-24 rounded-full bg-slate-100">
                            <div className={`h-2 rounded-full ${pct >= 100 ? "bg-emerald-600" : "bg-teal-600"}`} style={{ width: `${Math.min(pct, 100)}%` }} />
                          </div>
                          <Badge tone={pct >= 100 ? "green" : pct >= 60 ? "blue" : "amber"}>{pct}%</Badge>
                        </div>
                      </td>
                      <td className={tdClass}>{formatValue(t.metric, money ? remaining : Math.max(goal - current, 0))}</td>
                      <td className={tdClass}>{formatValue(t.metric, previous)}</td>
                      {ctx.can("sales", "assign") ? (
                        <td className={tdClass}>
                          <form action={deleteTarget}>
                            <input type="hidden" name="companyId" value={companyId} />
                            <input type="hidden" name="targetId" value={t.id} />
                            <button type="submit" className={btnSmall}>
                              Remove
                            </button>
                          </form>
                        </td>
                      ) : null}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="mt-4 text-xs text-slate-500">
            Measures: {TARGET_METRIC_KEYS.map((k) => humanize(k)).join(", ")}. Period options: {TARGET_PERIOD_KEYS.map((k) => humanize(k)).join(", ")}.
          </p>
        </Card>

        {ctx.can("sales", "assign") ? (
          <Card title="Set a target">
            <ActionForm action={createTarget} columns={1} hidden={{ companyId: String(companyId) }} submitLabel="Save target" fields={fields} />
          </Card>
        ) : null}
      </div>
    </>
  );
}

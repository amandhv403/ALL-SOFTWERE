import { and, desc, eq, inArray } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Card, Flash, PageHeader, btnSecondary } from "@/components/ui";
import { db } from "@/db";
import { leads } from "@/db/schema";
import { humanize, type LeadStatus } from "@/lib/constants";
import { firstParam, formatBDT, parseId } from "@/lib/format";
import { dbToCents, centsToDb } from "@/lib/money";
import { branchWhere, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

const STAGE_ORDER: LeadStatus[] = ["new", "contacted", "interested", "consultation", "quotation_sent", "follow_up", "converted", "lost", "not_interested"];

export default async function PipelinePage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "sales", "view");
  const sp = await searchParams;

  const rows = await db
    .select({ id: leads.id, code: leads.code, fullName: leads.fullName, status: leads.status, value: leads.expectedValue, interestedService: leads.interestedService })
    .from(leads)
    .where(and(eq(leads.companyId, companyId), branchWhere(ctx, leads.branchId), inArray(leads.status, STAGE_ORDER)))
    .orderBy(desc(leads.updatedAt))
    .limit(600);

  const byStage = new Map<LeadStatus, typeof rows>();
  for (const stage of STAGE_ORDER) byStage.set(stage, []);
  for (const row of rows) byStage.get(row.status)?.push(row);

  const openValue = rows
    .filter((r) => r.status !== "converted" && r.status !== "lost" && r.status !== "not_interested")
    .reduce((sum, r) => sum + dbToCents(r.value), 0);
  const converted = rows.filter((r) => r.status === "converted").length;
  const decided = rows.filter((r) => r.status === "converted" || r.status === "lost" || r.status === "not_interested").length;
  const conversion = decided > 0 ? Math.round((converted / decided) * 100) : 0;

  return (
    <>
      <PageHeader
        title="Sales pipeline"
        description="Every lead moves from left to right. Click a lead to update it."
        actions={
          <Link href={`/c/${companyId}/crm/leads`} className={btnSecondary}>
            List view
          </Link>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <Card>
          <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Open pipeline value</p>
          <p className="mt-2 text-2xl font-semibold text-slate-950">{formatBDT(centsToDb(openValue))}</p>
        </Card>
        <Card>
          <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Conversion rate</p>
          <p className="mt-2 text-2xl font-semibold text-slate-950">{conversion}%</p>
          <p className="text-xs text-slate-500">Converted out of leads that were won or lost</p>
        </Card>
        <Card>
          <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Leads in view</p>
          <p className="mt-2 text-2xl font-semibold text-slate-950">{rows.length}</p>
        </Card>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-4">
        {STAGE_ORDER.map((stage) => {
          const items = byStage.get(stage) ?? [];
          const value = items.reduce((sum, r) => sum + dbToCents(r.value), 0);
          return (
            <div key={stage} className="flex w-64 shrink-0 flex-col rounded-2xl bg-slate-200/50 p-3">
              <div className="mb-3 flex items-center justify-between">
                <p className="text-sm font-semibold text-slate-800">{humanize(stage)}</p>
                <span className="rounded-full bg-white px-2 py-0.5 text-xs font-medium text-slate-700">{items.length}</span>
              </div>
              <p className="mb-3 text-xs text-slate-500">{formatBDT(centsToDb(value))}</p>
              <ul className="space-y-2">
                {items.slice(0, 12).map((item) => (
                  <li key={item.id}>
                    <Link href={`/c/${companyId}/crm/leads/${item.id}`} className="block rounded-xl border border-slate-200 bg-white p-3 shadow-sm hover:border-teal-500">
                      <p className="text-sm font-medium text-slate-900">{item.fullName}</p>
                      <p className="text-xs text-slate-500">
                        {item.code}
                        {item.interestedService ? ` · ${item.interestedService}` : ""}
                      </p>
                    </Link>
                  </li>
                ))}
                {items.length > 12 ? <li className="text-xs text-slate-500">+ {items.length - 12} more in list view</li> : null}
              </ul>
            </div>
          );
        })}
      </div>
    </>
  );
}

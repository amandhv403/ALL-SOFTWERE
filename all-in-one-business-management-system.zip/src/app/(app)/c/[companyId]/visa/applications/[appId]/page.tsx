import { and, asc, desc, eq } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { changeVisaStatus, setChecklistItem, updateVisaDetails } from "@/app/actions/visa";
import { uploadDocument } from "@/app/actions/documents";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { ConfirmSubmit } from "@/components/confirm-submit";
import { Badge, Card, DetailList, Flash, PageHeader, StatusBadge, btnPrimary, btnSmall, toneFor } from "@/components/ui";
import { db } from "@/db";
import { activities, customers, documents, users, visaApplications, visaChecklistItems, visaStatusHistory } from "@/db/schema";
import { VISA_STATUS_KEYS, humanize, optionsOf } from "@/lib/constants";
import { firstParam, formatBDT, formatDate, formatDateTime, parseId, toDhakaInput } from "@/lib/format";
import { inBranchScope, requirePage } from "@/lib/permissions";
import { UPLOAD_ACCEPT } from "@/lib/storage";

export const dynamic = "force-dynamic";

export default async function VisaFilePage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string; appId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const routeParams = await params;
  const companyId = parseId(routeParams.companyId);
  const appId = parseId(routeParams.appId);
  if (!companyId || !appId) notFound();
  const ctx = await requirePage(companyId, "visa", "view");
  const sp = await searchParams;

  const [row] = await db
    .select({ app: visaApplications, customerName: customers.fullName, customerCode: customers.code, assigneeName: users.fullName })
    .from(visaApplications)
    .innerJoin(customers, eq(customers.id, visaApplications.customerId))
    .leftJoin(users, eq(users.id, visaApplications.assignedUserId))
    .where(and(eq(visaApplications.id, appId), eq(visaApplications.companyId, companyId)))
    .limit(1);
  if (!row || !inBranchScope(ctx, row.app.branchId)) notFound();
  const app = row.app;

  const [checklist, history, timeline, docRows, members] = await Promise.all([
    db.select().from(visaChecklistItems).where(eq(visaChecklistItems.visaApplicationId, appId)).orderBy(asc(visaChecklistItems.sortOrder)),
    db
      .select({ h: visaStatusHistory, actorName: users.fullName })
      .from(visaStatusHistory)
      .leftJoin(users, eq(users.id, visaStatusHistory.changedById))
      .where(eq(visaStatusHistory.visaApplicationId, appId))
      .orderBy(desc(visaStatusHistory.createdAt)),
    db
      .select({ a: activities, actorName: users.fullName })
      .from(activities)
      .leftJoin(users, eq(users.id, activities.createdById))
      .where(and(eq(activities.companyId, companyId), eq(activities.visaApplicationId, appId)))
      .orderBy(desc(activities.createdAt))
      .limit(40),
    ctx.can("documents", "view")
      ? db
          .select()
          .from(documents)
          .where(and(eq(documents.companyId, companyId), eq(documents.visaApplicationId, appId)))
          .orderBy(desc(documents.createdAt))
      : Promise.resolve([]),
    db.select({ id: users.id, fullName: users.fullName }).from(users).where(eq(users.isActive, true)).orderBy(asc(users.fullName)),
  ]);

  const canEdit = ctx.can("visa", "edit");
  const canVerify = ctx.can("documents", "verify");
  const receivedCount = checklist.filter((c) => c.status !== "pending").length;

  const statusFields: FieldDef[] = [
    { name: "status", label: "New status", type: "select", options: optionsOf(VISA_STATUS_KEYS), defaultValue: app.status },
    { name: "note", label: "What happened? (kept in the history)", type: "textarea", rows: 2 },
    { name: "submissionDate", label: "Submitted to embassy on", type: "date", defaultValue: app.submissionDate ?? "" },
    { name: "appointmentAt", label: "Appointment (date and time)", type: "datetime-local", defaultValue: toDhakaInput(app.appointmentAt) },
    { name: "approvalDate", label: "Decision date (if approved or refused)", type: "date", defaultValue: app.approvalDate ?? "" },
    { name: "validFrom", label: "Visa valid from", type: "date", defaultValue: app.validFrom ?? "" },
    { name: "validUntil", label: "Visa valid until", type: "date", defaultValue: app.validUntil ?? "" },
    { name: "refusalReason", label: "Refusal reason (required if refused)", type: "textarea", rows: 2, defaultValue: app.refusalReason ?? "" },
  ];

  const detailFields: FieldDef[] = [
    { name: "destinationCountry", label: "Destination", required: true, defaultValue: app.destinationCountry },
    { name: "visaCategory", label: "Visa category", required: true, defaultValue: app.visaCategory },
    { name: "travelPurpose", label: "Purpose of travel", defaultValue: app.travelPurpose ?? "" },
    { name: "embassy", label: "Embassy or visa centre", defaultValue: app.embassy ?? "" },
    { name: "travelDate", label: "Travel date", type: "date", defaultValue: app.travelDate ?? "" },
    { name: "returnDate", label: "Return date", type: "date", defaultValue: app.returnDate ?? "" },
    { name: "appointmentAt", label: "Appointment", type: "datetime-local", defaultValue: toDhakaInput(app.appointmentAt) },
    { name: "serviceFee", label: "Service fee (৳)", type: "number", step: "0.01", min: "0", defaultValue: app.serviceFee },
    {
      name: "assignedUserId",
      label: "Visa officer",
      type: "select",
      options: [{ value: "", label: "Not assigned" }, ...members.map((m) => ({ value: String(m.id), label: m.fullName }))],
      defaultValue: app.assignedUserId ? String(app.assignedUserId) : "",
    },
    { name: "notes", label: "Notes", type: "textarea", wide: true, defaultValue: app.notes ?? "" },
  ];

  return (
    <>
      <PageHeader
        title={`${app.code} · ${app.destinationCountry}`}
        description={`${row.customerName} (${row.customerCode}) · ${app.visaCategory}`}
        actions={
          <>
            <StatusBadge status={app.status} />
            <Link href={`/c/${companyId}/crm/customers/${app.customerId}`} className={btnSmall}>
              Customer profile
            </Link>
            {ctx.can("accounting", "create") ? (
              <Link href={`/c/${companyId}/accounting/invoices/new?customerId=${app.customerId}&visaId=${appId}`} className={btnPrimary}>
                Invoice this file
              </Link>
            ) : null}
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <Card title="File details">
            <DetailList
              items={[
                { label: "Application date", value: formatDate(app.applicationDate) },
                { label: "Submitted to embassy", value: formatDate(app.submissionDate) },
                { label: "Appointment", value: formatDateTime(app.appointmentAt) },
                { label: "Travel dates", value: `${formatDate(app.travelDate)} → ${formatDate(app.returnDate)}` },
                { label: "Embassy", value: app.embassy },
                { label: "Purpose", value: app.travelPurpose },
                { label: "Visa officer", value: row.assigneeName ?? "Not assigned" },
                { label: "Service fee", value: formatBDT(app.serviceFee) },
                { label: "Visa valid", value: `${formatDate(app.validFrom)} → ${formatDate(app.validUntil)}` },
                { label: "Decision date", value: formatDate(app.approvalDate) },
                { label: "Status note", value: app.statusNote },
                { label: "Refusal reason", value: app.refusalReason },
                { label: "Passport handed back", value: formatDateTime(app.passportDeliveredAt) },
                { label: "Notes", value: app.notes },
              ]}
            />
            {canEdit ? (
              <details className="mt-6 rounded-xl border border-slate-200 p-4">
                <summary className="cursor-pointer select-none text-sm font-semibold text-slate-900">Edit file details</summary>
                <div className="mt-4">
                  <ActionForm action={updateVisaDetails} hidden={{ companyId: String(companyId), applicationId: String(appId) }} fields={detailFields} submitLabel="Save file details" />
                </div>
              </details>
            ) : null}
          </Card>

          <Card title="Document checklist" description={`${receivedCount} of ${checklist.length} items received. Items marked verified have been checked by staff.`}>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200 text-sm">
                <tbody className="divide-y divide-slate-100">
                  {checklist.map((item) => (
                    <tr key={item.id}>
                      <td className="px-2 py-2 text-slate-800">{item.label}</td>
                      <td className="px-2 py-2">
                        <Badge tone={toneFor(item.status)}>{humanize(item.status)}</Badge>
                      </td>
                      {canEdit ? (
                        <td className="px-2 py-2">
                          <div className="flex flex-wrap gap-1.5">
                            {item.status !== "received" ? (
                              <form action={setChecklistItem}>
                                <input type="hidden" name="companyId" value={companyId} />
                                <input type="hidden" name="applicationId" value={appId} />
                                <input type="hidden" name="itemId" value={item.id} />
                                <input type="hidden" name="status" value="received" />
                                <button type="submit" className={btnSmall}>
                                  Received
                                </button>
                              </form>
                            ) : null}
                            {item.status !== "verified" && canVerify ? (
                              <form action={setChecklistItem}>
                                <input type="hidden" name="companyId" value={companyId} />
                                <input type="hidden" name="applicationId" value={appId} />
                                <input type="hidden" name="itemId" value={item.id} />
                                <input type="hidden" name="status" value="verified" />
                                <button type="submit" className={btnSmall}>
                                  Verify
                                </button>
                              </form>
                            ) : null}
                            {item.status !== "pending" ? (
                              <form action={setChecklistItem}>
                                <input type="hidden" name="companyId" value={companyId} />
                                <input type="hidden" name="applicationId" value={appId} />
                                <input type="hidden" name="itemId" value={item.id} />
                                <input type="hidden" name="status" value="pending" />
                                <button type="submit" className={btnSmall}>
                                  Reset
                                </button>
                              </form>
                            ) : null}
                          </div>
                        </td>
                      ) : null}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {ctx.can("documents", "view") ? (
            <Card title="Documents for this file" description="Passport copies, supporting letters and embassy receipts. Only people with permission can open them.">
              {docRows.length === 0 ? (
                <p className="mb-4 text-sm text-slate-600">No documents uploaded for this file yet.</p>
              ) : (
                <ul className="mb-5 divide-y divide-slate-100">
                  {docRows.map((doc) => (
                    <li key={doc.id} className="flex items-center justify-between gap-3 py-2.5">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-slate-900">{doc.title}</p>
                        <p className="text-xs text-slate-500">
                          {humanize(doc.category)} · {formatDate(doc.createdAt)}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <a href={`/api/files/${doc.id}`} target="_blank" rel="noopener" className={btnSmall}>
                          Preview
                        </a>
                        <a href={`/api/files/${doc.id}?download=1`} className={btnSmall}>
                          Download
                        </a>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
              {ctx.can("documents", "create") ? (
                <ActionForm
                  action={uploadDocument}
                  columns={2}
                  submitLabel="Upload to this file"
                  hidden={{ companyId: String(companyId), module: "visa", visaApplicationId: String(appId), customerId: String(app.customerId) }}
                  fields={[
                    { name: "title", label: "Document name", placeholder: "e.g. Bank statement (6 months)" },
                    {
                      name: "category",
                      label: "Type",
                      type: "select",
                      options: ["passport", "visa_document", "photo", "nid", "other"].map((k) => ({ value: k, label: humanize(k) })),
                      defaultValue: "visa_document",
                    },
                    { name: "file", label: "File (PDF, JPG, PNG or WEBP, max 10 MB)", type: "file", required: true, accept: UPLOAD_ACCEPT, wide: true },
                  ]}
                />
              ) : null}
            </Card>
          ) : null}

          <Card title="Activity and status history" description="Every status change is kept. Records are never deleted.">
            {history.length === 0 ? (
              <p className="text-sm text-slate-600">No status history yet.</p>
            ) : (
              <ol className="relative mb-6 space-y-4 border-l border-slate-200 pl-5">
                {history.map(({ h, actorName }) => (
                  <li key={h.id}>
                    <span className="absolute -left-1.5 mt-1.5 h-3 w-3 rounded-full border-2 border-white bg-teal-600" />
                    <p className="text-sm font-medium text-slate-900">
                      {h.fromStatus ? `${humanize(h.fromStatus)} → ` : ""}
                      {humanize(h.toStatus)}
                    </p>
                    {h.note ? <p className="text-sm text-slate-700">{h.note}</p> : null}
                    <p className="text-xs text-slate-500">
                      {formatDateTime(h.createdAt)} · {actorName ?? "System"}
                    </p>
                  </li>
                ))}
              </ol>
            )}
            {timeline.length > 0 ? (
              <ul className="divide-y divide-slate-100 text-sm">
                {timeline.map(({ a, actorName }) => (
                  <li key={a.id} className="py-2">
                    {a.summary} <span className="text-xs text-slate-500">· {formatDateTime(a.createdAt)} · {actorName ?? "System"}</span>
                  </li>
                ))}
              </ul>
            ) : null}
          </Card>
        </div>

        <div className="space-y-6">
          {canEdit ? (
            <Card title="Update status" description="Record the latest embassy or internal status. A history entry is saved automatically.">
              <ActionForm
                action={changeVisaStatus}
                columns={1}
                hidden={{ companyId: String(companyId), applicationId: String(appId) }}
                submitLabel="Save status"
                fields={statusFields}
              />
            </Card>
          ) : null}

          <Card title="Quick reference" description="Use the status form to move the file forward. Every change is recorded in the history.">
            <p className="text-sm text-slate-700">Status options: {VISA_STATUS_KEYS.map((k) => humanize(k)).join(", ")}.</p>
          </Card>
        </div>
      </div>
    </>
  );
}

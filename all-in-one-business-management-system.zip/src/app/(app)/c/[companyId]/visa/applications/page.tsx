import { and, asc, count, desc, eq, ilike, or, type SQL } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { createVisaApplication } from "@/app/actions/visa";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Card, Flash, PageHeader, Pagination, StatusBadge, btnPrimary, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { branches, customers, users, visaApplications } from "@/db/schema";
import {
  DESTINATION_SUGGESTIONS,
  PAGE_SIZE,
  VISA_CATEGORY_SUGGESTIONS,
  VISA_STATUS_KEYS,
  humanize,
  optionsOf,
  type VisaStatus,
} from "@/lib/constants";
import { escapeLike, firstParam, formatDate, formatDateTime, parseId, parsePage, todayISO } from "@/lib/format";
import { branchWhere, listCompanyMembers, requirePage } from "@/lib/permissions";
import { UPLOAD_ACCEPT } from "@/lib/storage";

export const dynamic = "force-dynamic";

export default async function VisaListPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "visa", "view");
  const sp = await searchParams;

  const q = firstParam(sp.q).trim();
  const status = firstParam(sp.status);
  const page = parsePage(firstParam(sp.page));

  const conditions: (SQL | undefined)[] = [eq(visaApplications.companyId, companyId), branchWhere(ctx, visaApplications.branchId)];
  if (q) {
    const like = `%${escapeLike(q)}%`;
    conditions.push(or(ilike(visaApplications.code, like), ilike(visaApplications.destinationCountry, like), ilike(customers.fullName, like)));
  }
  if ((VISA_STATUS_KEYS as readonly string[]).includes(status)) conditions.push(eq(visaApplications.status, status as VisaStatus));
  const where = and(...conditions);

  const [rows, totalRows, members, customerRows, branchRows] = await Promise.all([
    db
      .select({ app: visaApplications, customerName: customers.fullName, assigneeName: users.fullName })
      .from(visaApplications)
      .innerJoin(customers, eq(customers.id, visaApplications.customerId))
      .leftJoin(users, eq(users.id, visaApplications.assignedUserId))
      .where(where)
      .orderBy(desc(visaApplications.createdAt))
      .limit(PAGE_SIZE)
      .offset((page - 1) * PAGE_SIZE),
    db
      .select({ value: count() })
      .from(visaApplications)
      .innerJoin(customers, eq(customers.id, visaApplications.customerId))
      .where(where),
    listCompanyMembers(companyId),
    db
      .select({ id: customers.id, code: customers.code, fullName: customers.fullName })
      .from(customers)
      .where(and(eq(customers.companyId, companyId), eq(customers.isArchived, false), branchWhere(ctx, customers.branchId)))
      .orderBy(asc(customers.fullName))
      .limit(800),
    db.select({ id: branches.id, name: branches.name }).from(branches).where(and(eq(branches.companyId, companyId), eq(branches.isActive, true))),
  ]);
  const total = Number(totalRows[0]?.value ?? 0);
  const preselect = firstParam(sp.customerId);

  const fields: FieldDef[] = [
    { name: "h-customer", label: "Customer and destination", type: "heading" },
    {
      name: "customerId",
      label: "Customer (register them first if missing)",
      type: "select",
      required: true,
      options: [{ value: "", label: "Choose a customer…" }, ...customerRows.map((c) => ({ value: String(c.id), label: `${c.fullName} (${c.code})` }))],
      defaultValue: preselect,
    },
    { name: "destinationCountry", label: "Destination country", required: true, suggestions: DESTINATION_SUGGESTIONS },
    { name: "visaCategory", label: "Visa category", required: true, suggestions: VISA_CATEGORY_SUGGESTIONS },
    { name: "travelPurpose", label: "Purpose of travel" },
    { name: "embassy", label: "Embassy or visa centre", placeholder: "e.g. Malaysian High Commission, Dhaka" },
    { name: "h-dates", label: "Dates", type: "heading" },
    { name: "applicationDate", label: "Date of application", type: "date", defaultValue: todayISO() },
    { name: "submissionDate", label: "Date submitted to embassy", type: "date" },
    { name: "travelDate", label: "Planned travel date", type: "date" },
    { name: "returnDate", label: "Planned return date", type: "date" },
    { name: "appointmentAt", label: "Embassy appointment (date and time)", type: "datetime-local" },
    { name: "h-status", label: "Status and money", type: "heading" },
    { name: "status", label: "Current status", type: "select", options: optionsOf(VISA_STATUS_KEYS), defaultValue: "new" },
    { name: "assignedUserId", label: "Visa officer", type: "select", options: [{ value: "", label: "Me (default)" }, ...members.map((m) => ({ value: String(m.id), label: `${m.fullName} (${m.roleName})` }))] },
    { name: "serviceFee", label: "Service fee (৳)", type: "number", step: "0.01", min: "0", defaultValue: "0", help: "Your fee for this file. You can invoice it from the file page." },
    { name: "notes", label: "Notes", type: "textarea", wide: true },
  ];
  if (branchRows.length > 0 && !ctx.branchId) {
    fields.push({ name: "branchId", label: "Branch", type: "select", options: [{ value: "", label: "Not set" }, ...branchRows.map((b) => ({ value: String(b.id), label: b.name }))] });
  }

  return (
    <>
      <PageHeader
        title="Visa applications"
        description="One file per visa application. Track documents, embassy appointments, status changes and decisions from start to passport delivery."
        actions={
          ctx.can("visa", "export") ? (
            <a href={`/api/export?companyId=${companyId}&type=visa`} className={btnSmall}>
              Export CSV
            </a>
          ) : null
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      {ctx.can("visa", "create") ? (
        <details className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm" open={Boolean(preselect)}>
          <summary className="cursor-pointer select-none text-base font-semibold text-slate-900">+ Open a new visa file</summary>
          <div className="mt-5">
            {customerRows.length === 0 ? (
              <p className="text-sm text-slate-600">
                No customers yet. <Link href={`/c/${companyId}/crm/customers`} className="font-medium text-teal-800 underline">Register a customer</Link> first.
              </p>
            ) : (
              <ActionForm action={createVisaApplication} hidden={{ companyId: String(companyId) }} submitLabel="Open visa file" fields={fields} />
            )}
          </div>
        </details>
      ) : null}

      <Card>
        <form method="get" className="mb-5 grid gap-3 md:grid-cols-[1fr_16rem_auto]">
          <input name="q" defaultValue={q} placeholder="Search file number, country or customer name" className="rounded-lg border border-slate-300 px-3 py-2 text-sm shadow-sm" />
          <select name="status" defaultValue={status} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="">All statuses</option>
            {optionsOf(VISA_STATUS_KEYS).map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <button type="submit" className={btnPrimary}>
            Filter
          </button>
        </form>
        <div className="overflow-x-auto">
          <table className={tableClass}>
            <thead>
              <tr>
                <th className={thClass}>File</th>
                <th className={thClass}>Customer</th>
                <th className={thClass}>Destination</th>
                <th className={thClass}>Category</th>
                <th className={thClass}>Status</th>
                <th className={thClass}>Appointment</th>
                <th className={thClass}>Officer</th>
                <th className={thClass}>Applied</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.length === 0 ? (
                <tr>
                  <td className={tdClass} colSpan={8}>
                    No visa files match these filters.
                  </td>
                </tr>
              ) : null}
              {rows.map(({ app, customerName, assigneeName }) => (
                <tr key={app.id} className="hover:bg-slate-50">
                  <td className={tdClass}>
                    <Link href={`/c/${companyId}/visa/applications/${app.id}`} className="font-medium text-teal-800 hover:underline">
                      {app.code}
                    </Link>
                  </td>
                  <td className={tdClass}>{customerName}</td>
                  <td className={tdClass}>{app.destinationCountry}</td>
                  <td className={tdClass}>{app.visaCategory}</td>
                  <td className={tdClass}>
                    <StatusBadge status={app.status} />
                  </td>
                  <td className={tdClass}>{formatDateTime(app.appointmentAt)}</td>
                  <td className={tdClass}>{assigneeName ?? "—"}</td>
                  <td className={tdClass}>{formatDate(app.applicationDate)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination basePath={`/c/${companyId}/visa/applications`} page={page} pageSize={PAGE_SIZE} total={total} query={{ q, status }} />
      </Card>
      <p className="mt-4 text-xs text-slate-500">Accepted document types for file uploads: {UPLOAD_ACCEPT.replace(/\./g, "").toUpperCase().split(",").join(", ")} (max 10 MB).</p>
    </>
  );
}

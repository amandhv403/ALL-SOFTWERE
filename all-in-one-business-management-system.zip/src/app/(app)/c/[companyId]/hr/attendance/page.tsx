import { and, asc, eq, notInArray } from "drizzle-orm";
import { notFound } from "next/navigation";
import { markAttendance } from "@/app/actions/hr";
import { Card, Flash, PageHeader, btnPrimary, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { attendance, branches, employees } from "@/db/schema";
import { ATTENDANCE_STATUS_KEYS, humanize } from "@/lib/constants";
import { firstParam, parseId, todayISO } from "@/lib/format";
import { branchWhere, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

function toTime(value: string | null | undefined): string {
  return value ? value.slice(0, 5) : "";
}

export default async function AttendancePage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "hr", "view");
  const sp = await searchParams;
  const dateParam = firstParam(sp.date);
  const date = /^\d{4}-\d{2}-\d{2}$/.test(dateParam) ? dateParam : todayISO();
  const canRecord = ctx.can("hr", "create");

  const [staff, existing] = await Promise.all([
    db
      .select({ id: employees.id, fullName: employees.fullName, designation: employees.designation, branchName: branches.name })
      .from(employees)
      .leftJoin(branches, eq(branches.id, employees.branchId))
      .where(and(eq(employees.companyId, companyId), notInArray(employees.employmentStatus, ["resigned", "terminated"]), branchWhere(ctx, employees.branchId)))
      .orderBy(asc(employees.fullName)),
    db.select().from(attendance).where(and(eq(attendance.companyId, companyId), eq(attendance.attendanceDate, date))),
  ]);
  const byEmployee = new Map(existing.map((a) => [a.employeeId, a]));

  return (
    <>
      <PageHeader
        title="Attendance"
        description="Record who was in today. Late arrivals and early departures are calculated from the company's working hours and grace period."
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <Card>
        <form method="get" className="mb-5 flex flex-wrap items-end gap-3">
          <label className="text-sm font-medium text-slate-700">
            Date
            <input type="date" name="date" defaultValue={date} className="mt-1 block rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          </label>
          <button type="submit" className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50">
            Show this date
          </button>
        </form>

        {staff.length === 0 ? (
          <p className="text-sm text-slate-600">No active employees yet. Add employees first.</p>
        ) : canRecord ? (
          <form action={markAttendance} className="space-y-4">
            <input type="hidden" name="companyId" value={companyId} />
            <input type="hidden" name="attendanceDate" value={date} />
            <input type="hidden" name="employeeIds" value={staff.map((s) => s.id).join(",")} />
            <div className="overflow-x-auto">
              <table className={tableClass}>
                <thead>
                  <tr>
                    <th className={thClass}>Employee</th>
                    <th className={thClass}>Status</th>
                    <th className={thClass}>Check-in</th>
                    <th className={thClass}>Check-out</th>
                    <th className={thClass}>Note</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {staff.map((s) => {
                    const current = byEmployee.get(s.id);
                    return (
                      <tr key={s.id}>
                        <td className={tdClass}>
                          <p className="font-medium text-slate-900">{s.fullName}</p>
                          <p className="text-xs text-slate-500">{[s.designation, s.branchName].filter(Boolean).join(" · ")}</p>
                        </td>
                        <td className={tdClass}>
                          <select name={`status_${s.id}`} defaultValue={current?.status ?? "present"} className="rounded-lg border border-slate-300 px-2 py-1.5 text-sm">
                            {ATTENDANCE_STATUS_KEYS.map((k) => (
                              <option key={k} value={k}>
                                {humanize(k)}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className={tdClass}>
                          <input name={`in_${s.id}`} defaultValue={toTime(current?.checkIn)} placeholder="09:00" className="w-24 rounded-lg border border-slate-300 px-2 py-1.5 text-sm" />
                        </td>
                        <td className={tdClass}>
                          <input name={`out_${s.id}`} defaultValue={toTime(current?.checkOut)} placeholder="18:00" className="w-24 rounded-lg border border-slate-300 px-2 py-1.5 text-sm" />
                        </td>
                        <td className={tdClass}>
                          <input name={`note_${s.id}`} defaultValue={current?.notes ?? ""} className="w-full min-w-[10rem] rounded-lg border border-slate-300 px-2 py-1.5 text-sm" />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <button type="submit" className={btnPrimary}>
              Save attendance for this day
            </button>
          </form>
        ) : (
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Employee</th>
                  <th className={thClass}>Status</th>
                  <th className={thClass}>In</th>
                  <th className={thClass}>Out</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {staff.map((s) => {
                  const current = byEmployee.get(s.id);
                  return (
                    <tr key={s.id}>
                      <td className={tdClass}>{s.fullName}</td>
                      <td className={tdClass}>{current ? humanize(current.status) : "Not recorded"}</td>
                      <td className={tdClass}>{toTime(current?.checkIn) || "—"}</td>
                      <td className={tdClass}>{toTime(current?.checkOut) || "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}

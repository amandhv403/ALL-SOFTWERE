import { and, asc, desc, eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { decideLeave, requestLeave } from "@/app/actions/hr";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Card, Flash, PageHeader, StatusBadge, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { branches, employees, leaveRequests, users } from "@/db/schema";
import { LEAVE_STATUS_KEYS, LEAVE_TYPE_KEYS, humanize, optionsOf } from "@/lib/constants";
import { firstParam, formatDate, parseId, todayISO } from "@/lib/format";
import { branchWhere, inBranchScope, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function LeavePage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "hr", "view");
  const sp = await searchParams;
  const status = firstParam(sp.status);
  const statusFilter = (LEAVE_STATUS_KEYS as readonly string[]).includes(status) ? eq(leaveRequests.status, status as "pending") : undefined;

  const [rows, staff] = await Promise.all([
    db
      .select({ leave: leaveRequests, employeeName: employees.fullName, employeeBranch: employees.branchId, employeeUserId: employees.userId, requesterName: users.fullName })
      .from(leaveRequests)
      .innerJoin(employees, eq(employees.id, leaveRequests.employeeId))
      .leftJoin(users, eq(users.id, leaveRequests.createdById))
      .where(and(eq(leaveRequests.companyId, companyId), statusFilter))
      .orderBy(desc(leaveRequests.createdAt))
      .limit(200),
    db
      .select({ id: employees.id, fullName: employees.fullName, userId: employees.userId, branchId: employees.branchId })
      .from(employees)
      .where(and(eq(employees.companyId, companyId), branchWhere(ctx, employees.branchId)))
      .orderBy(asc(employees.fullName)),
  ]);

  const canApprove = ctx.can("hr", "approve");
  const canReject = ctx.can("hr", "reject");
  const myEmployee = staff.find((s) => s.userId === ctx.user.id);
  const requestable = staff.filter((s) => inBranchScope(ctx, s.branchId));

  const fields: FieldDef[] = [
    {
      name: "employeeId",
      label: "Employee",
      type: "select",
      required: true,
      options: [{ value: "", label: "Choose…" }, ...requestable.map((s) => ({ value: String(s.id), label: s.fullName }))],
      defaultValue: myEmployee ? String(myEmployee.id) : "",
    },
    { name: "leaveType", label: "Type of leave", type: "select", options: optionsOf(LEAVE_TYPE_KEYS), defaultValue: "annual" },
    { name: "startDate", label: "First day off", type: "date", required: true, defaultValue: todayISO() },
    { name: "endDate", label: "Last day off", type: "date", required: true, defaultValue: todayISO() },
    { name: "reason", label: "Reason", type: "textarea", wide: true },
  ];

  return (
    <>
      <PageHeader title="Leave requests" description="Requests wait for approval. Approved leave is kept in the employee's record." />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2" title="All requests" actions={
          <div className="flex flex-wrap gap-2 text-sm">
            <a href={`/c/${companyId}/hr/leave`} className={btnSmall}>All</a>
            <a href={`/c/${companyId}/hr/leave?status=pending`} className={btnSmall}>Waiting</a>
            <a href={`/c/${companyId}/hr/leave?status=approved`} className={btnSmall}>Approved</a>
          </div>
        }>
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Employee</th>
                  <th className={thClass}>Type</th>
                  <th className={thClass}>Dates</th>
                  <th className={thClass}>Days</th>
                  <th className={thClass}>Status</th>
                  <th className={thClass}>Decision</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rows.length === 0 ? (
                  <tr>
                    <td className={tdClass} colSpan={6}>
                      No leave requests yet.
                    </td>
                  </tr>
                ) : null}
                {rows.map(({ leave, employeeName, employeeBranch }) => {
                  const visible = inBranchScope(ctx, employeeBranch);
                  const pending = leave.status === "pending";
                  return (
                    <tr key={leave.id}>
                      <td className={tdClass}>
                        <p className="font-medium text-slate-900">{visible ? employeeName : "Hidden (other branch)"}</p>
                        <p className="text-xs text-slate-500">{leave.reason ?? ""}</p>
                      </td>
                      <td className={tdClass}>{humanize(leave.leaveType)}</td>
                      <td className={tdClass}>
                        {formatDate(leave.startDate)} → {formatDate(leave.endDate)}
                      </td>
                      <td className={tdClass}>{leave.days}</td>
                      <td className={tdClass}>
                        <StatusBadge status={leave.status} />
                      </td>
                      <td className={tdClass}>
                        {visible && pending && (canApprove || canReject) ? (
                          <div className="flex flex-wrap gap-1.5">
                            {canApprove ? (
                              <form action={decideLeave}>
                                <input type="hidden" name="companyId" value={companyId} />
                                <input type="hidden" name="leaveId" value={leave.id} />
                                <input type="hidden" name="decision" value="approve" />
                                <button type="submit" className={btnSmall}>Approve</button>
                              </form>
                            ) : null}
                            {canReject ? (
                              <form action={decideLeave} className="flex gap-1">
                                <input type="hidden" name="companyId" value={companyId} />
                                <input type="hidden" name="leaveId" value={leave.id} />
                                <input type="hidden" name="decision" value="reject" />
                                <input name="note" placeholder="Reason" className="w-24 rounded-md border border-slate-300 px-1.5 py-1 text-xs" />
                                <button type="submit" className={btnSmall}>Reject</button>
                              </form>
                            ) : null}
                          </div>
                        ) : (
                          <span className="text-xs text-slate-500">{leave.decisionNote ?? "—"}</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>

        {requestable.length > 0 && (ctx.can("hr", "create") || myEmployee) ? (
          <Card title="Request leave">
            <ActionForm action={requestLeave} columns={1} hidden={{ companyId: String(companyId) }} submitLabel="Send request" fields={fields} />
          </Card>
        ) : (
          <Card title="Request leave">
            <p className="text-sm text-slate-600">No employee record is linked to your login yet. Ask HR to link your account on your employee record.</p>
          </Card>
        )}
      </div>
    </>
  );
}

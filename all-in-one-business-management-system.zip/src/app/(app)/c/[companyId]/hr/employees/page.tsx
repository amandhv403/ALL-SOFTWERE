import { and, asc, desc, eq, ilike, notInArray, or, type SQL } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { createEmployee } from "@/app/actions/hr";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Card, Flash, PageHeader, Pagination, StatusBadge, btnPrimary, btnSecondary, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { branches, departments, employees, users } from "@/db/schema";
import { EMPLOYMENT_STATUS_KEYS, PAGE_SIZE, humanize, optionsOf, type EmploymentStatus } from "@/lib/constants";
import { escapeLike, firstParam, formatBDT, formatDate, parseId, parsePage, todayISO } from "@/lib/format";
import { branchWhere, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function EmployeesPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "hr", "view");
  const sp = await searchParams;
  const q = firstParam(sp.q).trim();
  const status = firstParam(sp.status);
  const page = parsePage(firstParam(sp.page));
  const showSalary = ctx.can("hr_salary", "view");

  const conditions: (SQL | undefined)[] = [eq(employees.companyId, companyId), branchWhere(ctx, employees.branchId)];
  if (q) {
    const like = `%${escapeLike(q)}%`;
    conditions.push(or(ilike(employees.fullName, like), ilike(employees.code, like), ilike(employees.designation, like)));
  }
  if ((EMPLOYMENT_STATUS_KEYS as readonly string[]).includes(status)) conditions.push(eq(employees.employmentStatus, status as EmploymentStatus));
  const where = and(...conditions);

  const [rows, totalRows, deptRows, branchRows, userRows, managerRows] = await Promise.all([
    db
      .select({ e: employees, departmentName: departments.name, branchName: branches.name, managerName: employees.reportingManagerId })
      .from(employees)
      .leftJoin(departments, eq(departments.id, employees.departmentId))
      .leftJoin(branches, eq(branches.id, employees.branchId))
      .where(where)
      .orderBy(asc(employees.fullName))
      .limit(PAGE_SIZE)
      .offset((page - 1) * PAGE_SIZE),
    db.select({ id: employees.id }).from(employees).where(where),
    db.select({ id: departments.id, name: departments.name }).from(departments).where(and(eq(departments.companyId, companyId), eq(departments.isActive, true))).orderBy(asc(departments.name)),
    db.select({ id: branches.id, name: branches.name }).from(branches).where(and(eq(branches.companyId, companyId), eq(branches.isActive, true))).orderBy(asc(branches.name)),
    db.select({ id: users.id, fullName: users.fullName, email: users.email }).from(users).where(eq(users.isActive, true)).orderBy(asc(users.fullName)),
    db
      .select({ id: employees.id, fullName: employees.fullName })
      .from(employees)
      .where(and(eq(employees.companyId, companyId), notInArray(employees.employmentStatus, ["resigned", "terminated"])))
      .orderBy(asc(employees.fullName)),
  ]);
  const total = totalRows.length;

  const fields: FieldDef[] = [
    { name: "h-person", label: "Person", type: "heading" },
    { name: "fullName", label: "Full name", required: true },
    { name: "phone", label: "Phone", type: "tel" },
    { name: "email", label: "Email", type: "email" },
    { name: "dateOfBirth", label: "Date of birth", type: "date" },
    { name: "nationalId", label: "National ID (NID) number" },
    { name: "address", label: "Address", type: "textarea", wide: true },
    { name: "h-job", label: "Job", type: "heading" },
    { name: "designation", label: "Job title", required: true, placeholder: "e.g. Visa Officer" },
    { name: "departmentId", label: "Department", type: "select", options: [{ value: "", label: "Not set" }, ...deptRows.map((d) => ({ value: String(d.id), label: d.name }))] },
    ...(branchRows.length > 0 && !ctx.branchId
      ? [{ name: "branchId", label: "Branch", type: "select" as const, options: [{ value: "", label: "Not set" }, ...branchRows.map((b) => ({ value: String(b.id), label: b.name }))] }]
      : []),
    { name: "joinDate", label: "Joining date", type: "date", required: true, defaultValue: todayISO() },
    { name: "employmentStatus", label: "Employment status", type: "select", options: optionsOf(EMPLOYMENT_STATUS_KEYS), defaultValue: "probation" },
    { name: "reportingManagerId", label: "Reports to", type: "select", options: [{ value: "", label: "Nobody" }, ...managerRows.map((m) => ({ value: String(m.id), label: m.fullName }))] },
    { name: "userId", label: "Login account (if this person uses the system)", type: "select", options: [{ value: "", label: "No login" }, ...userRows.map((u) => ({ value: String(u.id), label: `${u.fullName} (${u.email})` }))] },
    ...(ctx.can("hr_salary", "edit")
      ? [{ name: "basicSalary", label: "Basic monthly salary (৳, confidential)", type: "number" as const, step: "0.01", min: "0", defaultValue: "0" }]
      : []),
    { name: "notes", label: "Notes (confidential)", type: "textarea", wide: true },
  ];

  return (
    <>
      <PageHeader
        title="Employees"
        description="The staff directory. Salary details are only shown to people with the confidential salary permission."
        actions={
          <>
            <Link href={`/c/${companyId}/hr/attendance`} className={btnSecondary}>
              Attendance
            </Link>
            <Link href={`/c/${companyId}/hr/leave`} className={btnSecondary}>
              Leave requests
            </Link>
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      {ctx.can("hr", "create") ? (
        <details className="mb-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <summary className="cursor-pointer select-none text-base font-semibold text-slate-900">+ Add an employee</summary>
          <div className="mt-5">
            <ActionForm action={createEmployee} hidden={{ companyId: String(companyId) }} submitLabel="Save employee" fields={fields} />
          </div>
        </details>
      ) : null}

      <Card>
        <form method="get" className="mb-5 grid gap-3 md:grid-cols-[1fr_14rem_auto]">
          <input name="q" defaultValue={q} placeholder="Search name, code or job title" className="rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          <select name="status" defaultValue={status} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="">All statuses</option>
            {optionsOf(EMPLOYMENT_STATUS_KEYS).map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <button type="submit" className={btnPrimary}>
            Filter
          </button>
        </form>
        <div className="overflow-x-auto">
          <table className={tableClass}>
            <thead>
              <tr>
                <th className={thClass}>Code</th>
                <th className={thClass}>Name</th>
                <th className={thClass}>Job title</th>
                <th className={thClass}>Department</th>
                <th className={thClass}>Branch</th>
                <th className={thClass}>Joined</th>
                <th className={thClass}>Status</th>
                {showSalary ? <th className={thClass}>Salary</th> : null}
                <th className={thClass}></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.length === 0 ? (
                <tr>
                  <td className={tdClass} colSpan={9}>
                    No employees yet.
                  </td>
                </tr>
              ) : null}
              {rows.map(({ e, departmentName, branchName }) => (
                <tr key={e.id} className="hover:bg-slate-50">
                  <td className={tdClass}>{e.code}</td>
                  <td className={tdClass}>
                    <Link href={`/c/${companyId}/hr/employees/${e.id}`} className="font-medium text-teal-800 hover:underline">
                      {e.fullName}
                    </Link>
                  </td>
                  <td className={tdClass}>{e.designation}</td>
                  <td className={tdClass}>{departmentName ?? "—"}</td>
                  <td className={tdClass}>{branchName ?? "—"}</td>
                  <td className={tdClass}>{formatDate(e.joinDate)}</td>
                  <td className={tdClass}>
                    <StatusBadge status={e.employmentStatus} />
                  </td>
                  {showSalary ? <td className={tdClass}>{formatBDT(e.basicSalary)}</td> : null}
                  <td className={tdClass}>
                    <Link href={`/c/${companyId}/hr/employees/${e.id}`} className={btnSmall}>
                      Open
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination basePath={`/c/${companyId}/hr/employees`} page={page} pageSize={PAGE_SIZE} total={total} query={{ q, status }} />
      </Card>
    </>
  );
}

import { and, desc, eq, gte, lte } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { updateEmployee } from "@/app/actions/hr";
import { uploadDocument } from "@/app/actions/documents";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Card, DetailList, Flash, PageHeader, StatusBadge, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { attendance, branches, departments, documents, employees, leaveRequests, users } from "@/db/schema";
import { EMPLOYMENT_STATUS_KEYS, humanize, optionsOf } from "@/lib/constants";
import { firstParam, formatBDT, formatDate, parseId, todayISO } from "@/lib/format";
import { inBranchScope, listCompanyMembers, requirePage } from "@/lib/permissions";
import { UPLOAD_ACCEPT } from "@/lib/storage";

export const dynamic = "force-dynamic";

export default async function EmployeeDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string; employeeId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const routeParams = await params;
  const companyId = parseId(routeParams.companyId);
  const employeeId = parseId(routeParams.employeeId);
  if (!companyId || !employeeId) notFound();
  const ctx = await requirePage(companyId, "hr", "view");
  const sp = await searchParams;

  const [row] = await db
    .select({ e: employees, departmentName: departments.name, branchName: branches.name, linkedUser: users.fullName })
    .from(employees)
    .leftJoin(departments, eq(departments.id, employees.departmentId))
    .leftJoin(branches, eq(branches.id, employees.branchId))
    .leftJoin(users, eq(users.id, employees.userId))
    .where(and(eq(employees.id, employeeId), eq(employees.companyId, companyId)))
    .limit(1);
  if (!row || !inBranchScope(ctx, row.e.branchId)) notFound();
  const e = row.e;

  const monthStart = `${todayISO().slice(0, 8)}01`;
  const [attendanceRows, leaveRows, docRows, members, deptRows, branchRows, staffRows, userRows] = await Promise.all([
    db
      .select()
      .from(attendance)
      .where(and(eq(attendance.employeeId, employeeId), gte(attendance.attendanceDate, monthStart)))
      .orderBy(desc(attendance.attendanceDate))
      .limit(31),
    db.select().from(leaveRequests).where(eq(leaveRequests.employeeId, employeeId)).orderBy(desc(leaveRequests.startDate)).limit(20),
    ctx.can("documents", "view")
      ? db.select().from(documents).where(and(eq(documents.companyId, companyId), eq(documents.employeeId, employeeId))).orderBy(desc(documents.createdAt))
      : Promise.resolve([]),
    listCompanyMembers(companyId),
    db.select({ id: departments.id, name: departments.name }).from(departments).where(and(eq(departments.companyId, companyId), eq(departments.isActive, true))),
    db.select({ id: branches.id, name: branches.name }).from(branches).where(and(eq(branches.companyId, companyId), eq(branches.isActive, true))),
    db.select({ id: employees.id, fullName: employees.fullName }).from(employees).where(eq(employees.companyId, companyId)),
    db.select({ id: users.id, fullName: users.fullName, email: users.email }).from(users).where(eq(users.isActive, true)),
  ]);
  const presentDays = attendanceRows.filter((a) => a.status === "present" || a.status === "late" || a.status === "half_day").length;
  const lateMinutes = attendanceRows.reduce((sum, a) => sum + a.lateMinutes, 0);
  const canSeeSalary = ctx.can("hr_salary", "view");
  const canEditSalary = ctx.can("hr_salary", "edit");
  const canEdit = ctx.can("hr", "edit");

  const editFields: FieldDef[] = [
    { name: "fullName", label: "Full name", required: true, defaultValue: e.fullName },
    { name: "phone", label: "Phone", type: "tel", defaultValue: e.phone ?? "" },
    { name: "email", label: "Email", type: "email", defaultValue: e.email ?? "" },
    { name: "dateOfBirth", label: "Date of birth", type: "date", defaultValue: e.dateOfBirth ?? "" },
    { name: "nationalId", label: "National ID (NID) number", defaultValue: e.nationalId ?? "" },
    { name: "address", label: "Address", type: "textarea", wide: true, defaultValue: e.address ?? "" },
    { name: "designation", label: "Job title", required: true, defaultValue: e.designation },
    { name: "departmentId", label: "Department", type: "select", options: [{ value: "", label: "Not set" }, ...deptRows.map((d) => ({ value: String(d.id), label: d.name }))], defaultValue: e.departmentId ? String(e.departmentId) : "" },
    { name: "joinDate", label: "Joining date", type: "date", required: true, defaultValue: e.joinDate },
    { name: "employmentStatus", label: "Employment status", type: "select", options: optionsOf(EMPLOYMENT_STATUS_KEYS), defaultValue: e.employmentStatus },
    { name: "reportingManagerId", label: "Reports to", type: "select", options: [{ value: "", label: "Nobody" }, ...staffRows.filter((s) => s.id !== employeeId).map((s) => ({ value: String(s.id), label: s.fullName }))], defaultValue: e.reportingManagerId ? String(e.reportingManagerId) : "" },
    { name: "notes", label: "Notes (confidential)", type: "textarea", wide: true, defaultValue: e.notes ?? "" },
  ];
  if (canEditSalary) {
    editFields.splice(editFields.length - 1, 0, { name: "basicSalary", label: "Basic monthly salary (৳, confidential)", type: "number", step: "0.01", min: "0", defaultValue: e.basicSalary });
  }

  return (
    <>
      <PageHeader
        title={e.fullName}
        description={`${e.code} · ${e.designation}${row.departmentName ? ` · ${row.departmentName}` : ""}`}
        actions={
          <>
            <StatusBadge status={e.employmentStatus} />
            <Link href={`/c/${companyId}/hr/attendance?date=${todayISO()}`} className={btnSmall}>
              Attendance
            </Link>
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <Card title="Profile">
            <DetailList
              items={[
                { label: "Phone", value: e.phone },
                { label: "Email", value: e.email },
                { label: "Date of birth", value: formatDate(e.dateOfBirth) },
                { label: "National ID", value: e.nationalId },
                { label: "Address", value: e.address },
                { label: "Joined", value: formatDate(e.joinDate) },
                { label: "Department", value: row.departmentName },
                { label: "Branch", value: row.branchName },
                { label: "Login account", value: row.linkedUser ?? "No login" },
                ...(canSeeSalary ? [{ label: "Basic salary (confidential)", value: formatBDT(e.basicSalary) }] : []),
                { label: "Notes", value: e.notes },
              ]}
            />
            {canEdit ? (
              <details className="mt-6 rounded-xl border border-slate-200 p-4">
                <summary className="cursor-pointer select-none text-sm font-semibold text-slate-900">Edit employee record</summary>
                <div className="mt-4">
                  <ActionForm action={updateEmployee} hidden={{ companyId: String(companyId), employeeId: String(employeeId) }} fields={editFields} submitLabel="Save employee" />
                </div>
              </details>
            ) : null}
          </Card>

          <Card title="Attendance this month" description={`${presentDays} day(s) present · ${lateMinutes} minute(s) late`}>
            {attendanceRows.length === 0 ? (
              <p className="text-sm text-slate-600">No attendance recorded this month.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className={tableClass}>
                  <thead>
                    <tr>
                      <th className={thClass}>Date</th>
                      <th className={thClass}>Status</th>
                      <th className={thClass}>In</th>
                      <th className={thClass}>Out</th>
                      <th className={thClass}>Late (min)</th>
                      <th className={thClass}>Left early (min)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {attendanceRows.map((a) => (
                      <tr key={a.id}>
                        <td className={tdClass}>{formatDate(a.attendanceDate)}</td>
                        <td className={tdClass}>
                          <StatusBadge status={a.status} />
                        </td>
                        <td className={tdClass}>{a.checkIn ?? "—"}</td>
                        <td className={tdClass}>{a.checkOut ?? "—"}</td>
                        <td className={tdClass}>{a.lateMinutes}</td>
                        <td className={tdClass}>{a.earlyLeaveMinutes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          {ctx.can("documents", "view") ? (
            <Card title="Employment documents" description="Contracts, certificates and other staff files. Restricted to people with permission.">
              {docRows.length === 0 ? (
                <p className="mb-4 text-sm text-slate-600">No documents uploaded.</p>
              ) : (
                <ul className="mb-5 divide-y divide-slate-100">
                  {docRows.map((d) => (
                    <li key={d.id} className="flex items-center justify-between py-2.5">
                      <span className="text-sm text-slate-900">{d.title}</span>
                      <a href={`/api/files/${d.id}`} target="_blank" rel="noopener" className={btnSmall}>
                        Open
                      </a>
                    </li>
                  ))}
                </ul>
              )}
              {ctx.can("documents", "create") ? (
                <ActionForm
                  action={uploadDocument}
                  columns={2}
                  submitLabel="Upload document"
                  hidden={{ companyId: String(companyId), module: "hr", employeeId: String(employeeId) }}
                  fields={[
                    { name: "title", label: "Document name", placeholder: "e.g. Employment contract" },
                    { name: "category", label: "Type", type: "select", options: ["contract", "nid", "photo", "other"].map((k) => ({ value: k, label: humanize(k) })), defaultValue: "contract" },
                    { name: "file", label: "File (PDF, JPG, PNG or WEBP, max 10 MB)", type: "file", required: true, accept: UPLOAD_ACCEPT, wide: true },
                  ]}
                />
              ) : null}
            </Card>
          ) : null}
        </div>

        <div className="space-y-6">
          <Card title="Leave history">
            {leaveRows.length === 0 ? (
              <p className="text-sm text-slate-600">No leave requests yet.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {leaveRows.map((l) => (
                  <li key={l.id} className="flex items-center justify-between py-2.5 text-sm">
                    <div>
                      <p className="font-medium text-slate-900">
                        {humanize(l.leaveType)} · {l.days} day(s)
                      </p>
                      <p className="text-xs text-slate-500">
                        {formatDate(l.startDate)} → {formatDate(l.endDate)}
                      </p>
                    </div>
                    <StatusBadge status={l.status} />
                  </li>
                ))}
              </ul>
            )}
            <Link href={`/c/${companyId}/hr/leave`} className="mt-4 inline-block text-sm font-medium text-teal-800 hover:underline">
              Go to leave requests
            </Link>
          </Card>
        </div>
      </div>
    </>
  );
}

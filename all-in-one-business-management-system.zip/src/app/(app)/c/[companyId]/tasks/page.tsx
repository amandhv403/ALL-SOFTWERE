import { and, asc, desc, eq, inArray, lt, or, type SQL } from "drizzle-orm";
import { notFound } from "next/navigation";
import { createTask, updateTaskStatus } from "@/app/actions/hr";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Badge, Card, Flash, PageHeader, StatusBadge, btnSecondary, btnSmall, tableClass, tdClass, thClass, btnPrimary } from "@/components/ui";
import { db } from "@/db";
import { tasks, users } from "@/db/schema";
import { TASK_PRIORITY_KEYS, TASK_STATUS_KEYS, humanize, optionsOf } from "@/lib/constants";
import { firstParam, formatDate, parseId, todayISO } from "@/lib/format";
import { listCompanyMembers, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function TasksPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "tasks", "view");
  const sp = await searchParams;
  const scope = firstParam(sp.scope) === "all" ? "all" : "mine";
  const showDone = firstParam(sp.done) === "1";
  const today = todayISO();

  const conditions: (SQL | undefined)[] = [eq(tasks.companyId, companyId)];
  if (scope === "mine") conditions.push(eq(tasks.assignedUserId, ctx.user.id));
  if (!showDone) conditions.push(inArray(tasks.status, ["todo", "in_progress", "waiting"]));

  const [rows, members] = await Promise.all([
    db
      .select({ task: tasks, assigneeName: users.fullName })
      .from(tasks)
      .leftJoin(users, eq(users.id, tasks.assignedUserId))
      .where(and(...conditions))
      .orderBy(asc(tasks.dueDate), desc(tasks.createdAt))
      .limit(300),
    listCompanyMembers(companyId),
  ]);

  const fields: FieldDef[] = [
    { name: "title", label: "What needs doing?", required: true, wide: true, placeholder: "e.g. Collect passport copies for the Malaysia files" },
    { name: "description", label: "Details", type: "textarea", wide: true },
    { name: "priority", label: "Priority", type: "select", options: optionsOf(TASK_PRIORITY_KEYS), defaultValue: "medium" },
    { name: "dueDate", label: "Due date", type: "date" },
    {
      name: "assignedUserId",
      label: "Assign to",
      type: "select",
      options: [{ value: "", label: "Me" }, ...members.map((m) => ({ value: String(m.id), label: m.fullName }))],
    },
  ];

  return (
    <>
      <PageHeader
        title="Office tasks"
        description="Simple task board for the team. Overdue items are shown in red."
        actions={
          <>
            <a href={`/c/${companyId}/tasks?scope=mine${showDone ? "&done=1" : ""}`} className={scope === "mine" ? btnPrimary : btnSecondary}>
              Mine
            </a>
            <a href={`/c/${companyId}/tasks?scope=all${showDone ? "&done=1" : ""}`} className={scope === "all" ? btnPrimary : btnSecondary}>
              Everyone
            </a>
            <a href={`/c/${companyId}/tasks?scope=${scope}${showDone ? "" : "&done=1"}`} className={btnSecondary}>
              {showDone ? "Hide finished" : "Show finished"}
            </a>
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2" title="Tasks">
          {rows.length === 0 ? (
            <p className="text-sm text-slate-600">No tasks here. Add one using the form on the right.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className={tableClass}>
                <thead>
                  <tr>
                    <th className={thClass}>Task</th>
                    <th className={thClass}>Assigned to</th>
                    <th className={thClass}>Due</th>
                    <th className={thClass}>Priority</th>
                    <th className={thClass}>Status</th>
                    <th className={thClass}>Move to</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {rows.map(({ task, assigneeName }) => {
                    const overdue = Boolean(task.dueDate && task.dueDate < today && !["done", "cancelled"].includes(task.status));
                    return (
                      <tr key={task.id} className={overdue ? "bg-red-50/40" : ""}>
                        <td className={tdClass}>
                          <p className="font-medium text-slate-900">{task.title}</p>
                          {task.description ? <p className="text-xs text-slate-500">{task.description}</p> : null}
                        </td>
                        <td className={tdClass}>{assigneeName ?? "—"}</td>
                        <td className={tdClass}>
                          <span className={overdue ? "font-medium text-red-700" : ""}>{formatDate(task.dueDate)}</span>
                          {overdue ? <Badge tone="red">Overdue</Badge> : null}
                        </td>
                        <td className={tdClass}>
                          <StatusBadge status={task.priority} />
                        </td>
                        <td className={tdClass}>
                          <StatusBadge status={task.status} />
                        </td>
                        <td className={tdClass}>
                          <div className="flex flex-wrap gap-1">
                            {TASK_STATUS_KEYS.filter((s) => s !== task.status).slice(0, 3).map((s) => (
                              <form key={s} action={updateTaskStatus}>
                                <input type="hidden" name="companyId" value={companyId} />
                                <input type="hidden" name="taskId" value={task.id} />
                                <input type="hidden" name="status" value={s} />
                                <button type="submit" className={btnSmall}>
                                  {humanize(s)}
                                </button>
                              </form>
                            ))}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Card>
        {ctx.can("tasks", "create") ? (
          <Card title="Add a task">
            <ActionForm action={createTask} columns={1} hidden={{ companyId: String(companyId) }} submitLabel="Add task" fields={fields} />
          </Card>
        ) : null}
      </div>
    </>
  );
}

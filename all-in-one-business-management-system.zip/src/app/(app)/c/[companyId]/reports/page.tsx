import { and, asc, count, desc, eq, gte, lte, sql, type SQL } from "drizzle-orm";

import { notFound } from "next/navigation";
import { Card, Flash, PageHeader, Stat, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { attendance, customers, expenseCategories, expenses, invoices, leads as leadsTable, leaveRequests, receipts, visaApplications } from "@/db/schema";
import { humanize } from "@/lib/constants";
import { accountBalances } from "@/lib/ledger";
import { addDaysISO, daysBetweenISO, dhakaToDate, endOfDayDhaka, firstParam, formatBDT, formatCount, monthStartISO, parseId, todayISO } from "@/lib/format";
import { centsToDb, dbToCents } from "@/lib/money";
import { branchWhere, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

const EXPORTS = [
  { type: "leads", label: "Leads", perm: "crm" as const },
  { type: "customers", label: "Customers", perm: "crm" as const },
  { type: "invoices", label: "Invoices & quotations", perm: "accounting" as const },
  { type: "receipts", label: "Money receipts", perm: "accounting" as const },
  { type: "expenses", label: "Expenses", perm: "accounting" as const },
  { type: "visa", label: "Visa files", perm: "visa" as const },
  { type: "employees", label: "Employees (no salary)", perm: "hr" as const },
  { type: "attendance", label: "Attendance", perm: "hr" as const },
];

function validDate(value: string, fallback: string): string {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : fallback;
}

export default async function ReportsPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "reports", "view");
  const sp = await searchParams;

  const today = todayISO();
  const from = validDate(firstParam(sp.from), monthStartISO(today));
  const to = validDate(firstParam(sp.to), today);
  const fromTs = dhakaToDate(from);
  const toTs = endOfDayDhaka(to);
  const showAcc = ctx.can("accounting", "view");
  const showCrm = ctx.can("crm", "view");
  const showVisa = ctx.can("visa", "view");
  const showHr = ctx.can("hr", "view");
  const none = Promise.resolve([] as never[]);

  const receiptWhere = (extra: SQL[] = []) =>
    and(
      eq(receipts.companyId, companyId),
      eq(receipts.status, "active"),
      eq(receipts.kind, "payment"),
      gte(receipts.receiptDate, from),
      lte(receipts.receiptDate, to),
      branchWhere(ctx, receipts.branchId),
      ...extra,
    );

  const [byMethod, monthly, outstanding, expenseCats, invoicedRow, collectedRow, refundRow, expenseRow, leadSources, visaStatuses, visaSpeed, attendanceStatus, leaveStatus, balances] =
    await Promise.all([
      showAcc
        ? db
            .select({ method: receipts.paymentMethod, total: sql<string>`coalesce(sum(${receipts.amount}), 0)`, n: count() })
            .from(receipts)
            .where(receiptWhere())
            .groupBy(receipts.paymentMethod)
        : none,
      showAcc
        ? db
            .select({ month: sql<string>`to_char(${receipts.receiptDate}, 'YYYY-MM')`, total: sql<string>`coalesce(sum(${receipts.amount}), 0)` })
            .from(receipts)
            .where(and(eq(receipts.companyId, companyId), eq(receipts.status, "active"), eq(receipts.kind, "payment"), branchWhere(ctx, receipts.branchId)))
            .groupBy(sql`to_char(${receipts.receiptDate}, 'YYYY-MM')`)
            .orderBy(sql`1 desc`)
            .limit(12)
        : none,
      showAcc
        ? db
            .select({ number: invoices.number, due: invoices.dueAmount, issueDate: invoices.issueDate, dueDate: invoices.dueDate, customerName: customers.fullName })
            .from(invoices)
            .innerJoin(customers, eq(customers.id, invoices.customerId))
            .where(and(eq(invoices.companyId, companyId), eq(invoices.docType, "invoice"), sql`${invoices.status} in ('issued', 'partially_paid')`, branchWhere(ctx, invoices.branchId)))
            .orderBy(asc(invoices.issueDate))
            .limit(500)
        : none,
      showAcc
        ? db
            .select({ category: expenseCategories.name, total: sql<string>`coalesce(sum(${expenses.amount}), 0)` })
            .from(expenses)
            .innerJoin(expenseCategories, eq(expenseCategories.id, expenses.categoryId))
            .where(and(eq(expenses.companyId, companyId), eq(expenses.status, "approved"), gte(expenses.expenseDate, from), lte(expenses.expenseDate, to), branchWhere(ctx, expenses.branchId)))
            .groupBy(expenseCategories.name)
            .orderBy(desc(sql`sum(${expenses.amount})`))
        : none,
      showAcc
        ? db
            .select({ total: sql<string>`coalesce(sum(${invoices.total}), 0)` })
            .from(invoices)
            .where(and(eq(invoices.companyId, companyId), eq(invoices.docType, "invoice"), sql`${invoices.status} <> 'cancelled'`, gte(invoices.issueDate, from), lte(invoices.issueDate, to), branchWhere(ctx, invoices.branchId)))
        : none,
      showAcc
        ? db.select({ total: sql<string>`coalesce(sum(${receipts.amount}), 0)` }).from(receipts).where(receiptWhere())
        : none,
      showAcc
        ? db
            .select({ total: sql<string>`coalesce(sum(${receipts.amount}), 0)` })
            .from(receipts)
            .where(and(eq(receipts.companyId, companyId), eq(receipts.status, "active"), eq(receipts.kind, "refund"), gte(receipts.receiptDate, from), lte(receipts.receiptDate, to), branchWhere(ctx, receipts.branchId)))
        : none,
      showAcc
        ? db
            .select({ total: sql<string>`coalesce(sum(${expenses.amount}), 0)` })
            .from(expenses)
            .where(and(eq(expenses.companyId, companyId), eq(expenses.status, "approved"), gte(expenses.expenseDate, from), lte(expenses.expenseDate, to), branchWhere(ctx, expenses.branchId)))
        : none,
      showCrm
        ? db
            .select({ source: leadsTable.leadSource, total: count(), converted: sql<number>`count(*) filter (where ${leadsTable.status} = 'converted')` })
            .from(leadsTable)
            .where(and(eq(leadsTable.companyId, companyId), gte(leadsTable.createdAt, fromTs), lte(leadsTable.createdAt, toTs), branchWhere(ctx, leadsTable.branchId)))
            .groupBy(leadsTable.leadSource)
            .orderBy(desc(count()))
        : none,
      showVisa
        ? db
            .select({ status: visaApplications.status, total: count() })
            .from(visaApplications)
            .where(and(eq(visaApplications.companyId, companyId), gte(visaApplications.applicationDate, from), lte(visaApplications.applicationDate, to), branchWhere(ctx, visaApplications.branchId)))
            .groupBy(visaApplications.status)
        : none,
      showVisa
        ? db
            .select({ avgDays: sql<string>`avg(${visaApplications.approvalDate} - ${visaApplications.applicationDate})`, approved: count() })
            .from(visaApplications)
            .where(and(eq(visaApplications.companyId, companyId), eq(visaApplications.status, "approved"), gte(visaApplications.approvalDate, from), lte(visaApplications.approvalDate, to), branchWhere(ctx, visaApplications.branchId)))
        : none,
      showHr
        ? db
            .select({ status: attendance.status, total: count() })
            .from(attendance)
            .where(and(eq(attendance.companyId, companyId), gte(attendance.attendanceDate, from), lte(attendance.attendanceDate, to)))
            .groupBy(attendance.status)
        : none,
      showHr
        ? db
            .select({ status: leaveRequests.status, total: count(), days: sql<string>`coalesce(sum(${leaveRequests.days}), 0)` })
            .from(leaveRequests)
            .where(and(eq(leaveRequests.companyId, companyId), gte(leaveRequests.startDate, from), lte(leaveRequests.startDate, to)))
            .groupBy(leaveRequests.status)
        : none,
      showAcc ? accountBalances(companyId) : Promise.resolve(new Map<number, number>()),
    ]);

  const collected = dbToCents(collectedRow[0]?.total);
  const refunded = dbToCents(refundRow[0]?.total);
  const expensesCents = dbToCents(expenseRow[0]?.total);
  const invoicedCents = dbToCents(invoicedRow[0]?.total);
  const totalBalance = [...balances.values()].reduce((sum, value) => sum + value, 0);

  // Aging of money still owed on invoices, by days past the due date (or issue date when no due date is set).
  const buckets = { current: 0, d30: 0, d60: 0, d90: 0, over90: 0 };
  for (const row of outstanding) {
    const due = dbToCents(row.due);
    const days = daysBetweenISO(row.dueDate ?? row.issueDate, today);
    if (days <= 0) buckets.current += due;
    else if (days <= 30) buckets.d30 += due;
    else if (days <= 60) buckets.d60 += due;
    else if (days <= 90) buckets.d90 += due;
    else buckets.over90 += due;
  }

  const attendanceMap = new Map(attendanceStatus.map((a) => [a.status, Number(a.total)]));
  const visaTotal = visaStatuses.reduce((sum, v) => sum + Number(v.total), 0);

  return (
    <>
      <PageHeader
        title="Reports"
        description="Live reports from your records. Choose a period, then read or export the figures. These are operational reports and not a statutory accounts package."
      />
      <Flash notice={undefined} error={undefined} />

      <Card className="mb-6">
        <form method="get" className="flex flex-wrap items-end gap-3">
          <label className="text-sm font-medium text-slate-700">
            From
            <input type="date" name="from" defaultValue={from} className="mt-1 block rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          </label>
          <label className="text-sm font-medium text-slate-700">
            To
            <input type="date" name="to" defaultValue={to} className="mt-1 block rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          </label>
          <button type="submit" className="rounded-lg bg-teal-700 px-4 py-2 text-sm font-medium text-white hover:bg-teal-800">
            Show report
          </button>
        </form>
      </Card>

      {showAcc ? (
        <>
          <div className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <Stat label="Invoiced in period" value={formatBDT(centsToDb(invoicedCents))} hint="Invoices issued, not cancelled" />
            <Stat label="Collected in period" value={formatBDT(centsToDb(collected))} hint="Active payments" />
            <Stat label="Expenses in period" value={formatBDT(centsToDb(expensesCents))} hint="Approved only" />
            <Stat label="Cash position now" value={formatBDT(centsToDb(totalBalance))} hint="All accounts combined" />
          </div>

          <div className="mb-6 grid gap-6 xl:grid-cols-2">
            <Card title="Income and expense (basic view)" description="Cash basis: money actually received minus refunds and approved expenses. This is not a full balance sheet.">
              <table className={tableClass}>
                <tbody className="divide-y divide-slate-100">
                  <tr><td className={tdClass}>Invoiced (accrual view)</td><td className={`${tdClass} text-right`}>{formatBDT(centsToDb(invoicedCents))}</td></tr>
                  <tr><td className={tdClass}>Money collected</td><td className={`${tdClass} text-right`}>{formatBDT(centsToDb(collected))}</td></tr>
                  <tr><td className={tdClass}>Refunds paid out</td><td className={`${tdClass} text-right`}>- {formatBDT(centsToDb(refunded))}</td></tr>
                  <tr><td className={tdClass}>Approved expenses</td><td className={`${tdClass} text-right`}>- {formatBDT(centsToDb(expensesCents))}</td></tr>
                  <tr className="font-semibold"><td className={tdClass}>Net cash result (collected − refunds − expenses)</td><td className={`${tdClass} text-right`}>{formatBDT(centsToDb(collected - refunded - expensesCents))}</td></tr>
                </tbody>
              </table>
            </Card>

            <Card title="Money still owed (aging)" description="Unpaid invoice balances, grouped by how many days late they are.">
              <table className={tableClass}>
                <tbody className="divide-y divide-slate-100">
                  <tr><td className={tdClass}>Not yet due</td><td className={`${tdClass} text-right`}>{formatBDT(centsToDb(buckets.current))}</td></tr>
                  <tr><td className={tdClass}>1 to 30 days late</td><td className={`${tdClass} text-right`}>{formatBDT(centsToDb(buckets.d30))}</td></tr>
                  <tr><td className={tdClass}>31 to 60 days late</td><td className={`${tdClass} text-right`}>{formatBDT(centsToDb(buckets.d60))}</td></tr>
                  <tr><td className={tdClass}>61 to 90 days late</td><td className={`${tdClass} text-right`}>{formatBDT(centsToDb(buckets.d90))}</td></tr>
                  <tr><td className={tdClass}>Over 90 days late</td><td className={`${tdClass} text-right text-red-700`}>{formatBDT(centsToDb(buckets.over90))}</td></tr>
                </tbody>
              </table>
              <p className="mt-3 text-xs text-slate-500">Showing up to 500 open invoices. Open each invoice to record payments.</p>
            </Card>

            <Card title="Collections by payment method" description="Active payments in the selected period.">
              {byMethod.length === 0 ? (
                <p className="text-sm text-slate-600">No payments in this period.</p>
              ) : (
                <table className={tableClass}>
                  <thead>
                    <tr><th className={thClass}>Method</th><th className={thClass}>Receipts</th><th className={thClass}>Amount</th></tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {byMethod.map((m) => (
                      <tr key={m.method}>
                        <td className={tdClass}>{humanize(m.method)}</td>
                        <td className={tdClass}>{formatCount(Number(m.n))}</td>
                        <td className={tdClass}>{formatBDT(m.total)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </Card>

            <Card title="Monthly collections" description="The last 12 months with payments.">
              {monthly.length === 0 ? (
                <p className="text-sm text-slate-600">No payments recorded yet.</p>
              ) : (
                <table className={tableClass}>
                  <thead><tr><th className={thClass}>Month</th><th className={thClass}>Collected</th></tr></thead>
                  <tbody className="divide-y divide-slate-100">
                    {monthly.map((m) => (
                      <tr key={m.month}><td className={tdClass}>{m.month}</td><td className={tdClass}>{formatBDT(m.total)}</td></tr>
                    ))}
                  </tbody>
                </table>
              )}
            </Card>

            <Card title="Expenses by category" description="Approved expenses in the period.">
              {expenseCats.length === 0 ? (
                <p className="text-sm text-slate-600">No approved expenses in this period.</p>
              ) : (
                <table className={tableClass}>
                  <tbody className="divide-y divide-slate-100">
                    {expenseCats.map((c) => (
                      <tr key={c.category}><td className={tdClass}>{c.category}</td><td className={`${tdClass} text-right`}>{formatBDT(c.total)}</td></tr>
                    ))}
                  </tbody>
                </table>
              )}
            </Card>

            <Card title="Cash and bank balances" description="Current balance of each account.">
              <p className="text-sm text-slate-600">
                See the detail on the <a href="accounting/cash-bank" className="font-medium text-teal-800 underline">Cash and bank</a> page.
              </p>
            </Card>
          </div>
        </>
      ) : null}

      <div className="mb-6 grid gap-6 xl:grid-cols-2">
        {showCrm ? (
          <Card title="Leads by source" description="Where enquiries came from, and how many became customers.">
            {leadSources.length === 0 ? (
              <p className="text-sm text-slate-600">No leads in this period.</p>
            ) : (
              <table className={tableClass}>
                <thead><tr><th className={thClass}>Source</th><th className={thClass}>Leads</th><th className={thClass}>Converted</th><th className={thClass}>Rate</th></tr></thead>
                <tbody className="divide-y divide-slate-100">
                  {leadSources.map((s) => {
                    const converted = Number(s.converted);
                    const total = Number(s.total);
                    return (
                      <tr key={s.source}>
                        <td className={tdClass}>{humanize(s.source)}</td>
                        <td className={tdClass}>{total}</td>
                        <td className={tdClass}>{converted}</td>
                        <td className={tdClass}>{total ? `${Math.round((converted / total) * 100)}%` : "—"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </Card>
        ) : null}

        {showVisa ? (
          <Card title="Visa files" description={`${visaTotal} file(s) opened in this period, by status.`}>
            {visaStatuses.length === 0 ? (
              <p className="text-sm text-slate-600">No visa files in this period.</p>
            ) : (
              <table className={tableClass}>
                <tbody className="divide-y divide-slate-100">
                  {visaStatuses.map((v) => (
                    <tr key={v.status}><td className={tdClass}>{humanize(v.status)}</td><td className={`${tdClass} text-right`}>{Number(v.total)}</td></tr>
                  ))}
                </tbody>
              </table>
            )}
            <p className="mt-4 text-sm text-slate-700">
              Average processing time for approvals in this period:{" "}
              <span className="font-semibold">
                {visaSpeed[0] && Number(visaSpeed[0].approved) > 0 ? `${Math.round(Number(visaSpeed[0].avgDays))} day(s)` : "no approvals yet"}
              </span>
            </p>
          </Card>
        ) : null}

        {showHr ? (
          <Card title="Attendance and leave" description="Daily attendance records and leave requests starting in the period.">
            <table className={tableClass}>
              <tbody className="divide-y divide-slate-100">
                {["present", "late", "absent", "half_day", "leave", "holiday"].map((k) => (
                  <tr key={k}><td className={tdClass}>{humanize(k)}</td><td className={`${tdClass} text-right`}>{attendanceMap.get(k as "present") ?? 0}</td></tr>
                ))}
                {leaveStatus.map((l) => (
                  <tr key={`leave-${l.status}`}><td className={tdClass}>Leave {humanize(l.status).toLowerCase()}</td><td className={`${tdClass} text-right`}>{Number(l.total)} request(s), {Number(l.days)} day(s)</td></tr>
                ))}
              </tbody>
            </table>
          </Card>
        ) : null}
      </div>

      <Card title="Download as spreadsheet (CSV)" description="Each download is recorded in the audit log. Salary data is never included.">
        <div className="flex flex-wrap gap-2">
          {EXPORTS.filter((e) => ctx.can(e.perm, "export")).map((e) => (
            <a key={e.type} href={`/api/export?companyId=${companyId}&type=${e.type}`} className={btnSmall}>
              {e.label}
            </a>
          ))}
        </div>
      </Card>
    </>
  );
}

import { and, asc, count, desc, eq, gte, inArray, isNotNull, lt, lte, notInArray, sql } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Badge, Card, EmptyState, Flash, PageHeader, Stat, StatusBadge, btnPrimary, btnSecondary, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import {
  auditLogs,
  employees,
  expenses,
  followUps,
  invoices,
  leads,
  receipts,
  tasks,
  users,
  visaApplications,
  customers,
} from "@/db/schema";
import { branchWhere, requirePage, type AccessContext } from "@/lib/permissions";
import { LEAD_STATUS_KEYS, OPEN_LEAD_STATUSES, humanize, type ActionKey, type ModuleKey } from "@/lib/constants";
import { dhakaToDate, endOfDayDhaka, firstParam, formatBDT, formatCount, formatDate, formatDateTime, monthStartISO, parseId, todayISO } from "@/lib/format";
import { centsToDb, dbToCents } from "@/lib/money";

export const dynamic = "force-dynamic";

function countOrZero(ctx: AccessContext, module: ModuleKey, action: ActionKey = "view") {
  return ctx.can(module, action);
}

export default async function CompanyDashboardPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "company", "view");
  const sp = await searchParams;

  const today = todayISO();
  const monthStart = monthStartISO(today);
  const monthStartDate = dhakaToDate(monthStart);
  const endToday = endOfDayDhaka(today);
  const weekAhead = new Date(dhakaToDate(today).getTime() + 7 * 86_400_000);
  const zero = [{ value: 0 }];
  const money = [{ value: "0" }];

  const crm = countOrZero(ctx, "crm");
  const acc = countOrZero(ctx, "accounting");
  const visa = countOrZero(ctx, "visa");
  const hr = countOrZero(ctx, "hr");
  const audit = countOrZero(ctx, "audit");

  const [
    newLeads,
    openLeads,
    dueFollowUps,
    collected,
    outstanding,
    pendingExpenses,
    openVisa,
    appointments,
    overdueTasks,
    staff,
    statusRows,
    upcoming,
    latestReceipts,
    activity,
  ] = await Promise.all([
    crm
      ? db.select({ value: count() }).from(leads).where(and(eq(leads.companyId, companyId), gte(leads.createdAt, monthStartDate), branchWhere(ctx, leads.branchId)))
      : Promise.resolve(zero),
    crm
      ? db.select({ value: count() }).from(leads).where(and(eq(leads.companyId, companyId), inArray(leads.status, OPEN_LEAD_STATUSES), branchWhere(ctx, leads.branchId)))
      : Promise.resolve(zero),
    crm
      ? db
          .select({ value: count() })
          .from(followUps)
          .where(
            and(
              eq(followUps.companyId, companyId),
              eq(followUps.status, "open"),
              lte(followUps.dueAt, endToday),
              ctx.branchId ? eq(followUps.assignedUserId, ctx.user.id) : undefined,
            ),
          )
      : Promise.resolve(zero),
    acc
      ? db
          .select({ value: sql<string>`coalesce(sum(${receipts.amount}), 0)` })
          .from(receipts)
          .where(and(eq(receipts.companyId, companyId), eq(receipts.kind, "payment"), eq(receipts.status, "active"), gte(receipts.receiptDate, monthStart), branchWhere(ctx, receipts.branchId)))
      : Promise.resolve(money),
    acc
      ? db
          .select({ value: sql<string>`coalesce(sum(${invoices.dueAmount}), 0)` })
          .from(invoices)
          .where(and(eq(invoices.companyId, companyId), eq(invoices.docType, "invoice"), inArray(invoices.status, ["issued", "partially_paid"]), branchWhere(ctx, invoices.branchId)))
      : Promise.resolve(money),
    acc
      ? db.select({ value: count() }).from(expenses).where(and(eq(expenses.companyId, companyId), eq(expenses.status, "pending"), branchWhere(ctx, expenses.branchId)))
      : Promise.resolve(zero),
    visa
      ? db.select({ value: count() }).from(visaApplications).where(and(eq(visaApplications.companyId, companyId), notInArray(visaApplications.status, ["delivered", "cancelled"]), branchWhere(ctx, visaApplications.branchId)))
      : Promise.resolve(zero),
    visa
      ? db
          .select({ value: count() })
          .from(visaApplications)
          .where(and(eq(visaApplications.companyId, companyId), isNotNull(visaApplications.appointmentAt), gte(visaApplications.appointmentAt, new Date()), lte(visaApplications.appointmentAt, weekAhead), branchWhere(ctx, visaApplications.branchId)))
      : Promise.resolve(zero),
    ctx.can("tasks", "view")
      ? db
          .select({ value: count() })
          .from(tasks)
          .where(and(eq(tasks.companyId, companyId), inArray(tasks.status, ["todo", "in_progress", "waiting"]), lt(tasks.dueDate, today)))
      : Promise.resolve(zero),
    hr
      ? db.select({ value: count() }).from(employees).where(and(eq(employees.companyId, companyId), notInArray(employees.employmentStatus, ["resigned", "terminated"]), branchWhere(ctx, employees.branchId)))
      : Promise.resolve(zero),
    crm
      ? db
          .select({ status: leads.status, value: count() })
          .from(leads)
          .where(and(eq(leads.companyId, companyId), branchWhere(ctx, leads.branchId)))
          .groupBy(leads.status)
      : Promise.resolve([] as { status: string; value: number }[]),
    crm
      ? db
          .select({
            id: followUps.id,
            title: followUps.title,
            dueAt: followUps.dueAt,
            leadId: followUps.leadId,
            customerId: followUps.customerId,
            leadName: leads.fullName,
            customerName: customers.fullName,
          })
          .from(followUps)
          .leftJoin(leads, eq(leads.id, followUps.leadId))
          .leftJoin(customers, eq(customers.id, followUps.customerId))
          .where(and(eq(followUps.companyId, companyId), eq(followUps.status, "open")))
          .orderBy(asc(followUps.dueAt))
          .limit(6)
      : Promise.resolve([]),
    acc
      ? db
          .select({ id: receipts.id, number: receipts.number, amount: receipts.amount, receiptDate: receipts.receiptDate, customerName: customers.fullName, status: receipts.status })
          .from(receipts)
          .innerJoin(customers, eq(customers.id, receipts.customerId))
          .where(and(eq(receipts.companyId, companyId), branchWhere(ctx, receipts.branchId)))
          .orderBy(desc(receipts.createdAt))
          .limit(6)
      : Promise.resolve([]),
    audit
      ? db
          .select({ id: auditLogs.id, summary: auditLogs.summary, createdAt: auditLogs.createdAt, userName: users.fullName })
          .from(auditLogs)
          .leftJoin(users, eq(users.id, auditLogs.userId))
          .where(eq(auditLogs.companyId, companyId))
          .orderBy(desc(auditLogs.createdAt))
          .limit(8)
      : Promise.resolve([]),
  ]);

  const statusCount = new Map(statusRows.map((row) => [row.status, Number(row.value)]));
  const maxStatus = Math.max(1, ...LEAD_STATUS_KEYS.map((key) => statusCount.get(key) ?? 0));
  const company = ctx.company;

  return (
    <>
      <PageHeader
        title={company.name}
        description={`Your workspace overview for ${humanize(company.businessType)}. You are signed in as ${ctx.roleName}.`}
        actions={
          <>
            {crm ? (
              <Link href={`/c/${companyId}/crm/leads`} className={btnSecondary}>
                Leads
              </Link>
            ) : null}
            {acc ? (
              <Link href={`/c/${companyId}/accounting/invoices/new`} className={btnPrimary}>
                New invoice
              </Link>
            ) : null}
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {crm ? <Stat label="New leads this month" value={formatCount(Number(newLeads[0]?.value ?? 0))} href={`/c/${companyId}/crm/leads`} /> : null}
        {crm ? <Stat label="Open leads" value={formatCount(Number(openLeads[0]?.value ?? 0))} hint="Still in the sales pipeline" href={`/c/${companyId}/sales/pipeline`} /> : null}
        {crm ? (
          <Stat
            label="Follow-ups due today"
            value={formatCount(Number(dueFollowUps[0]?.value ?? 0))}
            hint={ctx.branchId ? "Assigned to you" : "Due today or overdue"}
            tone={Number(dueFollowUps[0]?.value ?? 0) > 0 ? "red" : "slate"}
            href={`/c/${companyId}/crm/followups`}
          />
        ) : null}
        {acc ? <Stat label="Collected this month" value={formatBDT(centsToDb(dbToCents(collected[0]?.value)))} hint="Active payments" href={`/c/${companyId}/accounting/receipts`} /> : null}
        {acc ? <Stat label="Outstanding invoices" value={formatBDT(centsToDb(dbToCents(outstanding[0]?.value)))} hint="Money still to collect" tone="red" href={`/c/${companyId}/accounting/invoices`} /> : null}
        {acc ? <Stat label="Expenses to approve" value={formatCount(Number(pendingExpenses[0]?.value ?? 0))} href={`/c/${companyId}/accounting/expenses`} /> : null}
        {visa ? <Stat label="Open visa files" value={formatCount(Number(openVisa[0]?.value ?? 0))} href={`/c/${companyId}/visa/applications`} /> : null}
        {visa ? <Stat label="Visa appointments (7 days)" value={formatCount(Number(appointments[0]?.value ?? 0))} href={`/c/${companyId}/visa/applications`} /> : null}
        {ctx.can("tasks", "view") ? <Stat label="Overdue tasks" value={formatCount(Number(overdueTasks[0]?.value ?? 0))} tone="red" href={`/c/${companyId}/tasks`} /> : null}
        {hr ? <Stat label="Active staff" value={formatCount(Number(staff[0]?.value ?? 0))} href={`/c/${companyId}/hr/employees`} /> : null}
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        {crm ? (
          <Card title="Lead pipeline" description="How many leads are at each stage." className="xl:col-span-1">
            <ul className="space-y-2">
              {LEAD_STATUS_KEYS.map((key) => {
                const value = statusCount.get(key) ?? 0;
                return (
                  <li key={key}>
                    <div className="flex justify-between text-xs text-slate-600">
                      <span>{humanize(key)}</span>
                      <span className="font-medium text-slate-900">{value}</span>
                    </div>
                    <div className="mt-1 h-2 rounded-full bg-slate-100">
                      <div className="h-2 rounded-full bg-teal-600" style={{ width: `${Math.round((value / maxStatus) * 100)}%` }} />
                    </div>
                  </li>
                );
              })}
            </ul>
          </Card>
        ) : null}

        {crm ? (
          <Card title="Next follow-ups" description="The soonest open follow-ups." className="xl:col-span-1" actions={<Link href={`/c/${companyId}/crm/followups`} className="text-sm font-medium text-teal-800 hover:underline">All follow-ups</Link>}>
            {upcoming.length === 0 ? (
              <p className="text-sm text-slate-600">No open follow-ups. Good work.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {upcoming.map((item) => (
                  <li key={item.id} className="py-2.5">
                    <p className="text-sm font-medium text-slate-900">{item.title}</p>
                    <p className="text-xs text-slate-500">
                      {item.leadName ?? item.customerName ?? "—"} · due {formatDateTime(item.dueAt)}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        ) : null}

        {acc ? (
          <Card title="Latest money receipts" className="xl:col-span-1" actions={<Link href={`/c/${companyId}/accounting/receipts`} className="text-sm font-medium text-teal-800 hover:underline">All receipts</Link>}>
            {latestReceipts.length === 0 ? (
              <p className="text-sm text-slate-600">No receipts yet.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {latestReceipts.map((receipt) => (
                  <li key={receipt.id} className="flex items-center justify-between gap-3 py-2.5">
                    <div className="min-w-0">
                      <Link href={`/c/${companyId}/accounting/receipts/${receipt.id}`} className="text-sm font-medium text-teal-800 hover:underline">
                        {receipt.number}
                      </Link>
                      <p className="truncate text-xs text-slate-500">{receipt.customerName} · {formatDate(receipt.receiptDate)}</p>
                    </div>
                    <div className="text-right text-sm">
                      <p className="font-medium text-slate-900">{formatBDT(receipt.amount)}</p>
                      <StatusBadge status={receipt.status} />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        ) : null}
      </div>

      {audit ? (
        <Card className="mt-6" title="Recent activity" description="The latest important actions in this company (from the audit log).">
          {activity.length === 0 ? (
            <EmptyState title="No activity recorded yet" />
          ) : (
            <div className="overflow-x-auto">
              <table className={tableClass}>
                <thead>
                  <tr>
                    <th className={thClass}>When</th>
                    <th className={thClass}>Who</th>
                    <th className={thClass}>What happened</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {activity.map((entry) => (
                    <tr key={entry.id}>
                      <td className={tdClass}>{formatDateTime(entry.createdAt)}</td>
                      <td className={tdClass}>{entry.userName ?? "System"}</td>
                      <td className={tdClass}>{entry.summary}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      ) : null}

      <p className="mt-6 text-xs text-slate-500">
        <Badge tone="teal">Tip</Badge> <span className="ml-2">Use the menu on the left to open each part of this company. Only the options you are allowed to use are shown.</span>
      </p>
    </>
  );
}

import { and, asc, eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { createBranch, createDepartment, toggleBranch, toggleDepartment } from "@/app/actions/admin";
import { ActionForm } from "@/components/action-form";
import { Badge, Card, Flash, PageHeader, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { branches, departments } from "@/db/schema";
import { firstParam, parseId } from "@/lib/format";
import { requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function StructurePage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "company", "view");
  const sp = await searchParams;
  const canEdit = ctx.can("company", "edit");

  const [branchRows, departmentRows] = await Promise.all([
    db.select().from(branches).where(eq(branches.companyId, companyId)).orderBy(asc(branches.name)),
    db.select().from(departments).where(eq(departments.companyId, companyId)).orderBy(asc(departments.name)),
  ]);

  return (
    <>
      <PageHeader
        title="Branches and departments"
        description="Branches are physical offices or locations. Departments are teams such as Visa, Sales or Accounts. Staff can be limited to one branch."
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-2">
        <Card title="Branches" description={`${branchRows.length} branch(es)`}>
          <div className="mb-5 overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Name</th>
                  <th className={thClass}>Address</th>
                  <th className={thClass}>Status</th>
                  {canEdit ? <th className={thClass}>Action</th> : null}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {branchRows.length === 0 ? (
                  <tr>
                    <td className={tdClass} colSpan={4}>
                      No branches yet. Add your first branch below.
                    </td>
                  </tr>
                ) : null}
                {branchRows.map((branch) => (
                  <tr key={branch.id}>
                    <td className={tdClass}>{branch.name}</td>
                    <td className={tdClass}>{branch.address ?? "—"}</td>
                    <td className={tdClass}>
                      <Badge tone={branch.isActive ? "green" : "slate"}>{branch.isActive ? "Open" : "Closed"}</Badge>
                    </td>
                    {canEdit ? (
                      <td className={tdClass}>
                        <form action={toggleBranch}>
                          <input type="hidden" name="companyId" value={companyId} />
                          <input type="hidden" name="branchId" value={branch.id} />
                          <input type="hidden" name="active" value={branch.isActive ? "0" : "1"} />
                          <button type="submit" className={btnSmall}>
                            {branch.isActive ? "Close" : "Re-open"}
                          </button>
                        </form>
                      </td>
                    ) : null}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {canEdit ? (
            <ActionForm
              action={createBranch}
              hidden={{ companyId: String(companyId) }}
              submitLabel="Add branch"
              fields={[
                { name: "name", label: "Branch name", required: true, placeholder: "e.g. Dhaka – Gulshan" },
                { name: "phone", label: "Branch phone", type: "tel" },
                { name: "address", label: "Address", type: "textarea", wide: true },
              ]}
            />
          ) : null}
        </Card>

        <Card title="Departments" description={`${departmentRows.length} department(s)`}>
          <div className="mb-5 overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Name</th>
                  <th className={thClass}>Description</th>
                  <th className={thClass}>Status</th>
                  {canEdit ? <th className={thClass}>Action</th> : null}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {departmentRows.length === 0 ? (
                  <tr>
                    <td className={tdClass} colSpan={4}>
                      No departments yet. Add departments below.
                    </td>
                  </tr>
                ) : null}
                {departmentRows.map((dept) => (
                  <tr key={dept.id}>
                    <td className={tdClass}>{dept.name}</td>
                    <td className={tdClass}>{dept.description ?? "—"}</td>
                    <td className={tdClass}>
                      <Badge tone={dept.isActive ? "green" : "slate"}>{dept.isActive ? "Active" : "Closed"}</Badge>
                    </td>
                    {canEdit ? (
                      <td className={tdClass}>
                        <form action={toggleDepartment}>
                          <input type="hidden" name="companyId" value={companyId} />
                          <input type="hidden" name="departmentId" value={dept.id} />
                          <input type="hidden" name="active" value={dept.isActive ? "0" : "1"} />
                          <button type="submit" className={btnSmall}>
                            {dept.isActive ? "Close" : "Re-open"}
                          </button>
                        </form>
                      </td>
                    ) : null}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {canEdit ? (
            <ActionForm
              action={createDepartment}
              hidden={{ companyId: String(companyId) }}
              submitLabel="Add department"
              fields={[
                { name: "name", label: "Department name", required: true, placeholder: "e.g. Visa processing" },
                { name: "description", label: "Short description", wide: true },
              ]}
            />
          ) : null}
        </Card>
      </div>
    </>
  );
}

import { notFound } from "next/navigation";
import Link from "next/link";
import { updateCompanyModules, updateCompanyProfile } from "@/app/actions/admin";
import { uploadDocument } from "@/app/actions/documents";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Card, DetailList, Flash, PageHeader, btnSecondary } from "@/components/ui";
import { BUSINESS_TYPE_KEYS, BUSINESS_TYPE_LABELS, MODULE_LABELS, TOGGLEABLE_MODULE_KEYS, humanize } from "@/lib/constants";
import { firstParam, parseId } from "@/lib/format";
import { requirePage } from "@/lib/permissions";
import { UPLOAD_ACCEPT } from "@/lib/storage";

export const dynamic = "force-dynamic";

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

export default async function CompanySettingsPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "company", "view");
  const sp = await searchParams;
  const canEdit = ctx.can("company", "edit");
  const c = ctx.company;

  const profileFields: FieldDef[] = [
    { name: "h-identity", label: "Business identity", type: "heading" },
    { name: "name", label: "Company name", required: true, defaultValue: c.name },
    { name: "legalName", label: "Legal name", defaultValue: c.legalName ?? "" },
    {
      name: "businessType",
      label: "Business type",
      type: "select",
      options: BUSINESS_TYPE_KEYS.map((key) => ({ value: key, label: BUSINESS_TYPE_LABELS[key] })),
      defaultValue: c.businessType,
    },
    { name: "registrationNo", label: "Trade licence / registration number", defaultValue: c.registrationNo ?? "" },
    { name: "taxId", label: "Tax ID (TIN / BIN)", defaultValue: c.taxId ?? "" },
    { name: "phone", label: "Phone", type: "tel", defaultValue: c.phone ?? "" },
    { name: "email", label: "Email", type: "email", defaultValue: c.email ?? "" },
    { name: "website", label: "Website", defaultValue: c.website ?? "" },
    { name: "city", label: "City", defaultValue: c.city ?? "" },
    { name: "address", label: "Address (printed on invoices and receipts)", type: "textarea", wide: true, defaultValue: c.address ?? "" },
    { name: "brandColor", label: "Brand colour", defaultValue: c.brandColor, help: "Example: #0f766e" },
    { name: "h-numbering", label: "Numbering and printed notes", type: "heading" },
    { name: "invoicePrefix", label: "Invoice number prefix", defaultValue: c.invoicePrefix, help: "Example DH-INV gives DH-INV-00001" },
    { name: "quotationPrefix", label: "Quotation number prefix", defaultValue: c.quotationPrefix },
    { name: "receiptPrefix", label: "Receipt number prefix", defaultValue: c.receiptPrefix },
    { name: "visaPrefix", label: "Visa file number prefix", defaultValue: c.visaPrefix },
    { name: "invoiceFooter", label: "Invoice footer note", type: "textarea", wide: true, defaultValue: c.invoiceFooter ?? "", help: "For example bank details or payment terms." },
    { name: "receiptFooter", label: "Receipt footer note", type: "textarea", wide: true, defaultValue: c.receiptFooter ?? "" },
    { name: "h-hours", label: "Working hours and financial year", type: "heading" },
    { name: "shiftStart", label: "Shift start time (24-hour)", defaultValue: c.shiftStart, placeholder: "09:00" },
    { name: "shiftEnd", label: "Shift end time (24-hour)", defaultValue: c.shiftEnd, placeholder: "18:00" },
    { name: "graceMinutes", label: "Grace period before counting as late (minutes)", type: "number", min: "0", max: "120", defaultValue: String(c.graceMinutes) },
    {
      name: "financialYearStartMonth",
      label: "Financial year starts in",
      type: "select",
      options: MONTHS.map((month, index) => ({ value: String(index + 1), label: month })),
      defaultValue: String(c.financialYearStartMonth),
    },
  ];

  return (
    <>
      <PageHeader
        title="Company profile and settings"
        description="Details printed on your invoices and receipts, document numbering, working hours and which modules are switched on."
        actions={
          <Link href={`/c/${companyId}/settings/structure`} className={btnSecondary}>
            Branches & departments
          </Link>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <Card title="Company profile" description="Changes apply to new documents. Past invoices and receipts keep the details they were issued with.">
            {canEdit ? (
              <ActionForm action={updateCompanyProfile} hidden={{ companyId: String(companyId) }} fields={profileFields} submitLabel="Save company profile" />
            ) : (
              <DetailList
                items={[
                  { label: "Company", value: c.name },
                  { label: "Business type", value: humanize(c.businessType) },
                  { label: "Phone", value: c.phone },
                  { label: "Email", value: c.email },
                  { label: "Address", value: c.address },
                  { label: "Invoice prefix", value: c.invoicePrefix },
                  { label: "Receipt prefix", value: c.receiptPrefix },
                ]}
              />
            )}
          </Card>

          <Card title="Modules switched on" description="Switch off the modules this company does not use. Their menus disappear, and their data is kept.">
            {canEdit ? (
              <ActionForm
                action={updateCompanyModules}
                hidden={{ companyId: String(companyId) }}
                columns={2}
                submitLabel="Save module settings"
                fields={TOGGLEABLE_MODULE_KEYS.map((key) => ({
                  name: `module_${key}`,
                  label: MODULE_LABELS[key],
                  type: "checkbox" as const,
                  checked: c.enabledModules.includes(key),
                }))}
              />
            ) : (
              <ul className="grid gap-2 sm:grid-cols-2">
                {TOGGLEABLE_MODULE_KEYS.map((key) => (
                  <li key={key} className="text-sm text-slate-800">
                    {c.enabledModules.includes(key) ? "✓" : "–"} {MODULE_LABELS[key]}
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="Company logo" description="Shown at the top of invoices and receipts. PNG, JPG or WEBP, up to 10 MB.">
            {c.logoDocumentId ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={`/api/files/${c.logoDocumentId}`} alt={`${c.name} logo`} className="mb-4 h-20 w-auto rounded-lg border border-slate-200 bg-white object-contain p-2" />
            ) : (
              <p className="mb-4 text-sm text-slate-600">No logo uploaded yet.</p>
            )}
            {canEdit ? (
              <ActionForm
                action={uploadDocument}
                columns={1}
                submitLabel="Upload logo"
                hidden={{ companyId: String(companyId), module: "company", category: "logo" }}
                fields={[{ name: "file", label: "Choose logo image", type: "file", required: true, accept: ".png,.jpg,.jpeg,.webp" }]}
              />
            ) : null}
          </Card>

          <Card title="Your access" description="What your current role lets you do in this company.">
            <DetailList
              items={[
                { label: "Your role", value: ctx.roleName },
                { label: "Branch limit", value: ctx.branchId ? "Limited to one branch" : "All branches" },
                { label: "Can change settings", value: canEdit ? "Yes" : "No" },
                { label: "Business type", value: BUSINESS_TYPE_LABELS[c.businessType as keyof typeof BUSINESS_TYPE_LABELS] ?? "General" },
              ]}
            />
          </Card>
        </div>
      </div>
    </>
  );
}

import { and, asc, desc, eq, sql } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { createExpense, createExpenseCategory, decideExpense } from "@/app/actions/accounting";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Badge, Card, Flash, PageHeader, Stat, StatusBadge, btnPrimary, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { branches, campaigns, cashAccounts, expenseCategories, expenses, users } from "@/db/schema";
import { EXPENSE_STATUS_KEYS, PAYMENT_METHOD_KEYS, humanize, optionsOf } from "@/lib/constants";
import { firstParam, formatBDT, formatDate, parseId, todayISO } from "@/lib/format";
import { centsToDb, dbToCents } from "@/lib/money";
import { branchWhere, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function ExpensesPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "accounting", "view");
  const sp = await searchParams;
  const status = firstParam(sp.status);

  const statusFilter = (EXPENSE_STATUS_KEYS as readonly string[]).includes(status) ? eq(expenses.status, status as "pending") : undefined;
  const where = and(eq(expenses.companyId, companyId), branchWhere(ctx, expenses.branchId), statusFilter);

  const [rows, categories, accounts, campaignRows, branchRows, totals] = await Promise.all([
    db
      .select({ e: expenses, categoryName: expenseCategories.name, accountName: cashAccounts.name, requesterName: users.fullName, campaignName: campaigns.name })
      .from(expenses)
      .innerJoin(expenseCategories, eq(expenseCategories.id, expenses.categoryId))
      .leftJoin(cashAccounts, eq(cashAccounts.id, expenses.accountId))
      .leftJoin(users, eq(users.id, expenses.createdById))
      .leftJoin(campaigns, eq(campaigns.id, expenses.campaignId))
      .where(where)
      .orderBy(desc(expenses.expenseDate), desc(expenses.id))
      .limit(200),
    db.select().from(expenseCategories).where(and(eq(expenseCategories.companyId, companyId), eq(expenseCategories.isActive, true))).orderBy(asc(expenseCategories.name)),
    db.select({ id: cashAccounts.id, name: cashAccounts.name }).from(cashAccounts).where(and(eq(cashAccounts.companyId, companyId), eq(cashAccounts.isActive, true))).orderBy(asc(cashAccounts.name)),
    db.select({ id: campaigns.id, name: campaigns.name }).from(campaigns).where(eq(campaigns.companyId, companyId)).orderBy(asc(campaigns.name)),
    db.select({ id: branches.id, name: branches.name }).from(branches).where(and(eq(branches.companyId, companyId), eq(branches.isActive, true))).orderBy(asc(branches.name)),
    db
      .select({
        approved: sql<string>`coalesce(sum(case when ${expenses.status} = 'approved' then ${expenses.amount} else 0 end), 0)`,
        pending: sql<string>`coalesce(sum(case when ${expenses.status} = 'pending' then ${expenses.amount} else 0 end), 0)`,
      })
      .from(expenses)
      .where(and(eq(expenses.companyId, companyId), branchWhere(ctx, expenses.branchId))),
  ]);

  const canApprove = ctx.can("accounting", "approve");
  const canReject = ctx.can("accounting", "reject");

  const expenseFields: FieldDef[] = [
    { name: "expenseDate", label: "Date spent", type: "date", required: true, defaultValue: todayISO() },
    { name: "categoryId", label: "Category", type: "select", required: true, options: [{ value: "", label: "Choose a category…" }, ...categories.map((c) => ({ value: String(c.id), label: c.name }))] },
    { name: "amount", label: "Amount (৳)", type: "number", step: "0.01", min: "0.01", required: true },
    { name: "payeeName", label: "Paid to (person or company)" },
    { name: "description", label: "What was it for?", required: true, wide: true, placeholder: "e.g. Office electricity bill, October" },
    { name: "paymentMethod", label: "Paid by", type: "select", options: optionsOf(PAYMENT_METHOD_KEYS), defaultValue: "cash" },
    { name: "accountId", label: "From account", type: "select", options: [{ value: "", label: "Not recorded to an account" }, ...accounts.map((a) => ({ value: String(a.id), label: a.name }))] },
    { name: "reference", label: "Bill or receipt number" },
    { name: "campaignId", label: "Marketing campaign (if any)", type: "select", options: [{ value: "", label: "None" }, ...campaignRows.map((c) => ({ value: String(c.id), label: c.name }))] },
    ...(branchRows.length > 0 && !ctx.branchId
      ? [{ name: "branchId", label: "Branch", type: "select" as const, options: [{ value: "", label: "Not set" }, ...branchRows.map((b) => ({ value: String(b.id), label: b.name }))] }]
      : []),
    { name: "receipt", label: "Attach bill or receipt (optional, PDF/JPG/PNG)", type: "file", accept: ".pdf,.jpg,.jpeg,.png,.webp", wide: true },
  ];

  return (
    <>
      <PageHeader
        title="Expenses"
        description="Money the business spends. Expenses above your own approval level wait for an approver. Only approved expenses reduce cash and bank balances."
        actions={
          ctx.can("accounting", "export") ? (
            <a href={`/api/export?companyId=${companyId}&type=expenses`} className={btnSmall}>
              Export CSV
            </a>
          ) : null
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="mb-6 grid gap-4 sm:grid-cols-2">
        <Stat label="Approved spending" value={formatBDT(centsToDb(dbToCents(totals[0]?.approved)))} />
        <Stat label="Waiting for approval" value={formatBDT(centsToDb(dbToCents(totals[0]?.pending)))} tone="red" />
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2" title="Expense list" actions={
          <div className="flex gap-2 text-sm">
            <Link href={`/c/${companyId}/accounting/expenses`} className={btnSmall}>All</Link>
            <Link href={`/c/${companyId}/accounting/expenses?status=pending`} className={btnSmall}>Waiting</Link>
            <Link href={`/c/${companyId}/accounting/expenses?status=approved`} className={btnSmall}>Approved</Link>
          </div>
        }>
          <div className="overflow-x-auto">
            <table className={tableClass}>
              <thead>
                <tr>
                  <th className={thClass}>Date</th>
                  <th className={thClass}>Description</th>
                  <th className={thClass}>Category</th>
                  <th className={thClass}>Amount</th>
                  <th className={thClass}>Requested by</th>
                  <th className={thClass}>Status</th>
                  <th className={thClass}>Decision</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rows.length === 0 ? (
                  <tr>
                    <td className={tdClass} colSpan={7}>
                      No expenses recorded yet.
                    </td>
                  </tr>
                ) : null}
                {rows.map(({ e, categoryName, requesterName, accountName, campaignName }) => {
                  const canDecideThis = e.status === "pending" && e.createdById !== ctx.user.id;
                  return (
                    <tr key={e.id}>
                      <td className={tdClass}>{formatDate(e.expenseDate)}</td>
                      <td className={tdClass}>
                        <p className="font-medium text-slate-900">{e.description}</p>
                        <p className="text-xs text-slate-500">
                          {[e.payeeName, accountName ? `from ${accountName}` : null, campaignName ? `campaign: ${campaignName}` : null].filter(Boolean).join(" · ")}
                        </p>
                      </td>
                      <td className={tdClass}>{categoryName}</td>
                      <td className={tdClass}>{formatBDT(e.amount)}</td>
                      <td className={tdClass}>{requesterName ?? "—"}</td>
                      <td className={tdClass}>
                        <StatusBadge status={e.status} />
                        {e.decisionNote ? <p className="mt-1 text-xs text-slate-500">{e.decisionNote}</p> : null}
                      </td>
                      <td className={tdClass}>
                        {canDecideThis && (canApprove || canReject) ? (
                          <div className="flex flex-col gap-1.5">
                            {canApprove ? (
                              <form action={decideExpense} className="flex gap-1.5">
                                <input type="hidden" name="companyId" value={companyId} />
                                <input type="hidden" name="expenseId" value={e.id} />
                                <input type="hidden" name="decision" value="approve" />
                                <button type="submit" className={btnSmall}>Approve</button>
                              </form>
                            ) : null}
                            {canReject ? (
                              <form action={decideExpense} className="flex flex-col gap-1.5">
                                <input type="hidden" name="companyId" value={companyId} />
                                <input type="hidden" name="expenseId" value={e.id} />
                                <input type="hidden" name="decision" value="reject" />
                                <input name="note" placeholder="Reason (optional)" className="rounded-md border border-slate-300 px-2 py-1 text-xs" />
                                <button type="submit" className={btnSmall}>Reject</button>
                              </form>
                            ) : null}
                          </div>
                        ) : e.createdById === ctx.user.id && e.status === "pending" ? (
                          <Badge tone="amber">Your request</Badge>
                        ) : null}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="space-y-6">
          {ctx.can("accounting", "create") ? (
            <Card title="Record an expense">
              <ActionForm action={createExpense} columns={1} hidden={{ companyId: String(companyId) }} submitLabel="Save expense" fields={expenseFields} />
            </Card>
          ) : null}
          {ctx.can("accounting", "edit") ? (
            <Card title="Add an expense category">
              <form action={createExpenseCategory} className="flex gap-2">
                <input type="hidden" name="companyId" value={companyId} />
                <input name="name" required placeholder="e.g. Staff training" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                <button type="submit" className={btnPrimary}>Add</button>
              </form>
            </Card>
          ) : null}
        </div>
      </div>
    </>
  );
}

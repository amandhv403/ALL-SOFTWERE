import { and, asc, eq, inArray } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { randomUUID } from "node:crypto";
import { recordRefund, recordReceipt } from "@/app/actions/accounting";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Card, PageHeader, btnSecondary } from "@/components/ui";
import { db } from "@/db";
import { cashAccounts, customers, invoices } from "@/db/schema";
import { PAYMENT_METHOD_KEYS, optionsOf } from "@/lib/constants";
import { firstParam, formatBDT, parseId, todayISO } from "@/lib/format";
import { centsToDb, dbToCents } from "@/lib/money";
import { branchWhere, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function NewReceiptPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "accounting", "create");
  const sp = await searchParams;
  const presetCustomer = firstParam(sp.customerId);
  const presetInvoice = firstParam(sp.invoiceId);

  const [customerRows, openInvoices, accountRows] = await Promise.all([
    db
      .select({ id: customers.id, code: customers.code, fullName: customers.fullName })
      .from(customers)
      .where(and(eq(customers.companyId, companyId), eq(customers.isArchived, false), branchWhere(ctx, customers.branchId)))
      .orderBy(asc(customers.fullName))
      .limit(800),
    db
      .select({ id: invoices.id, number: invoices.number, dueAmount: invoices.dueAmount, customerName: customers.fullName })
      .from(invoices)
      .innerJoin(customers, eq(customers.id, invoices.customerId))
      .where(and(eq(invoices.companyId, companyId), eq(invoices.docType, "invoice"), inArray(invoices.status, ["issued", "partially_paid"]), branchWhere(ctx, invoices.branchId)))
      .orderBy(asc(customers.fullName), asc(invoices.issueDate))
      .limit(800),
    db
      .select({ id: cashAccounts.id, name: cashAccounts.name })
      .from(cashAccounts)
      .where(and(eq(cashAccounts.companyId, companyId), eq(cashAccounts.isActive, true)))
      .orderBy(asc(cashAccounts.name)),
  ]);

  const token = randomUUID();
  const accountOptions = [{ value: "", label: "Not recorded to an account" }, ...accountRows.map((a) => ({ value: String(a.id), label: a.name }))];
  const invoiceOptions = [
    { value: "", label: "No invoice (keep as advance)" },
    ...openInvoices.map((i) => ({ value: String(i.id), label: `${i.number} · ${i.customerName} · due ${formatBDT(centsToDb(dbToCents(i.dueAmount)))}` })),
  ];

  const receiptFields: FieldDef[] = [
    { name: "h-customer", label: "Who paid and for what", type: "heading" },
    {
      name: "customerId",
      label: "Customer",
      type: "select",
      required: true,
      options: [{ value: "", label: "Choose a customer…" }, ...customerRows.map((c) => ({ value: String(c.id), label: `${c.fullName} (${c.code})` }))],
      defaultValue: presetCustomer,
    },
    { name: "invoiceId", label: "Invoice to pay", type: "select", options: invoiceOptions, defaultValue: presetInvoice },
    { name: "applyAmount", label: "Amount applied to that invoice (৳, empty = as much as due)", type: "number", step: "0.01", min: "0" },
    { name: "h-money", label: "Money received", type: "heading" },
    { name: "receiptDate", label: "Date received", type: "date", required: true, defaultValue: todayISO() },
    { name: "amount", label: "Amount received (৳)", type: "number", step: "0.01", min: "0.01", required: true },
    { name: "paymentMethod", label: "Payment method", type: "select", options: optionsOf(PAYMENT_METHOD_KEYS), defaultValue: "cash" },
    { name: "transactionRef", label: "Transaction ID (bKash, bank or cheque number)", help: "Each transaction ID can only be recorded once." },
    { name: "accountId", label: "Put the money into", type: "select", options: accountOptions },
    { name: "receivedByName", label: "Received by", defaultValue: ctx.user.fullName },
    { name: "notes", label: "Notes (printed on receipt if needed)", type: "textarea", wide: true, help: "Any amount not applied to an invoice stays with the customer as advance." },
  ];

  const refundFields: FieldDef[] = [
    { name: "customerId", label: "Customer", type: "select", required: true, options: [{ value: "", label: "Choose a customer…" }, ...customerRows.map((c) => ({ value: String(c.id), label: `${c.fullName} (${c.code})` }))] },
    { name: "receiptDate", label: "Date paid back", type: "date", required: true, defaultValue: todayISO() },
    { name: "amount", label: "Refund amount (৳)", type: "number", step: "0.01", min: "0.01", required: true },
    { name: "paymentMethod", label: "Method", type: "select", options: optionsOf(PAYMENT_METHOD_KEYS), defaultValue: "cash" },
    { name: "transactionRef", label: "Transaction ID" },
    { name: "accountId", label: "Paid from", type: "select", options: accountOptions },
    { name: "notes", label: "Reason for refund (required)", type: "textarea", wide: true, required: true },
  ];

  return (
    <>
      <PageHeader
        title="Record a payment"
        description="Enter money received from a customer. If an invoice is chosen, the payment is applied to it straight away. Any leftover stays as the customer's advance."
        actions={
          <Link href={`/c/${companyId}/accounting/receipts`} className={btnSecondary}>
            Back to receipts
          </Link>
        }
      />
      {customerRows.length === 0 ? (
        <Card>
          <p className="text-sm text-slate-600">
            Register a customer first. <Link href={`/c/${companyId}/crm/customers`} className="font-medium text-teal-800 underline">Go to customers</Link>
          </p>
        </Card>
      ) : (
        <div className="grid gap-6 xl:grid-cols-3">
          <Card className="xl:col-span-2" title="Money received">
            <ActionForm
              action={recordReceipt}
              hidden={{ companyId: String(companyId), formToken: token }}
              submitLabel="Save receipt"
              pendingLabel="Saving receipt…"
              fields={receiptFields}
            />
          </Card>
          <Card title="Refund to a customer" description="Refunds come from a customer's advance and need approval.">
            {ctx.can("accounting", "approve") ? (
              <ActionForm
                action={recordRefund}
                columns={1}
                hidden={{ companyId: String(companyId), formToken: randomUUID() }}
                submitLabel="Record refund"
                fields={refundFields}
              />
            ) : (
              <p className="text-sm text-slate-600">Refunds need approval from a senior accountant or manager. Ask them to record it.</p>
            )}
          </Card>
        </div>
      )}
    </>
  );
}

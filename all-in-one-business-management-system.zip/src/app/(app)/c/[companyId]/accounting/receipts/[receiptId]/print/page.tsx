import { and, eq, sql } from "drizzle-orm";
import { notFound } from "next/navigation";
import { PrintButton } from "@/components/print-button";
import { db } from "@/db";
import { cashAccounts, customers, invoices, paymentAllocations, receipts } from "@/db/schema";
import { customerAdvanceCents } from "@/lib/ledger";
import { humanize } from "@/lib/constants";
import { firstParam, formatBDT, formatDate, parseId } from "@/lib/format";
import { dbToCents, centsToDb } from "@/lib/money";
import { requirePage } from "@/lib/permissions";
import { amountInWordsBDT } from "@/lib/words";

export const dynamic = "force-dynamic";

export default async function ReceiptPrintPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string; receiptId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const routeParams = await params;
  const companyId = parseId(routeParams.companyId);
  const receiptId = parseId(routeParams.receiptId);
  if (!companyId || !receiptId) notFound();
  const ctx = await requirePage(companyId, "accounting", "print");
  const company = ctx.company;
  const sp = await searchParams;
  const compact = firstParam(sp.size) === "compact";
  const copy = Math.max(1, Number(firstParam(sp.copy)) || 1);

  const [row] = await db
    .select({ receipt: receipts, customerName: customers.fullName, customerCode: customers.code, customerPhone: customers.phone, accountName: cashAccounts.name })
    .from(receipts)
    .innerJoin(customers, eq(customers.id, receipts.customerId))
    .leftJoin(cashAccounts, eq(cashAccounts.id, receipts.accountId))
    .where(and(eq(receipts.id, receiptId), eq(receipts.companyId, companyId)))
    .limit(1);
  if (!row) notFound();
  const r = row.receipt;

  const applied = await db
    .select({ number: invoices.number, amount: paymentAllocations.amount })
    .from(paymentAllocations)
    .innerJoin(invoices, eq(invoices.id, paymentAllocations.invoiceId))
    .where(eq(paymentAllocations.receiptId, receiptId));
  const appliedCents = applied.reduce((sum, a) => sum + dbToCents(a.amount), 0);

  const [dueRow] = await db
    .select({ due: sql<string>`coalesce(sum(${invoices.dueAmount}), 0)` })
    .from(invoices)
    .where(and(eq(invoices.companyId, companyId), eq(invoices.customerId, r.customerId), eq(invoices.docType, "invoice")));
  const outstandingNow = dbToCents(dueRow?.due);
  const advance = await customerAdvanceCents(companyId, r.customerId);

  const amountCents = dbToCents(r.amount);
  const isRefund = r.kind === "refund";
  const balanceAfter = outstandingNow;
  const balanceBefore = outstandingNow + (isRefund ? 0 : appliedCents);
  const copyLabel = copy <= 1 ? "Original" : `Reprint ${copy - 1}`;
  const width = compact ? "max-w-[80mm] text-[11px]" : "max-w-[210mm] text-[13px]";

  return (
    <div className="min-h-screen bg-slate-200 py-6 print:bg-white print:py-0">
      <div className="mx-auto mb-4 flex max-w-[210mm] flex-wrap items-center justify-between gap-3 px-2 print:hidden">
        <p className="text-sm text-slate-700">
          Layout: <a className="font-medium text-teal-800 underline" href={`?copy=${copy}`}>A4</a> ·{" "}
          <a className="font-medium text-teal-800 underline" href={`?copy=${copy}&size=compact`}>Compact (thermal/small)</a>
        </p>
        <PrintButton />
      </div>
      <article className={`mx-auto w-full bg-white p-8 leading-relaxed text-slate-900 shadow-lg print:shadow-none ${width} print:max-w-none`}>
        <header className="flex items-start justify-between gap-4 border-b-2 pb-4" style={{ borderColor: company.brandColor }}>
          <div className="flex items-center gap-3">
            {company.logoDocumentId ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={`/api/files/${company.logoDocumentId}`} alt="" className="h-14 w-auto object-contain" />
            ) : null}
            <div>
              <h1 className="font-bold" style={{ color: company.brandColor, fontSize: compact ? "13px" : "18px" }}>
                {company.legalName || company.name}
              </h1>
              <p className="text-slate-600">{[company.address, company.city].filter(Boolean).join(", ")}</p>
              <p className="text-slate-600">{[company.phone, company.email].filter(Boolean).join(" · ")}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="font-bold uppercase tracking-wide" style={{ color: company.brandColor, fontSize: compact ? "12px" : "16px" }}>
              {isRefund ? "Refund voucher" : "Money receipt"}
            </p>
            <p className="font-semibold">No. {r.number}</p>
            <p className="text-slate-600">Date: {formatDate(r.receiptDate)}</p>
            <p className="text-slate-600">{copyLabel} copy</p>
          </div>
        </header>

        {r.status === "cancelled" ? (
          <div className="mt-3 rounded border-2 border-red-600 px-2 py-1 text-center font-bold uppercase tracking-widest text-red-700">Cancelled</div>
        ) : null}

        <section className="mt-4 space-y-2">
          <p>
            {isRefund ? "Paid back to" : "Received with thanks from"}: <span className="font-semibold">{row.customerName}</span>{" "}
            <span className="text-slate-600">({row.customerCode}{row.customerPhone ? ` · ${row.customerPhone}` : ""})</span>
          </p>
          <p>
            The sum of: <span className="font-semibold">{amountInWordsBDT(amountCents / 100)}</span>
          </p>
          <p>
            Amount: <span className="text-base font-bold">{formatBDT(r.amount)}</span>
          </p>
          <p>
            Paid by {humanize(r.paymentMethod)}
            {r.transactionRef ? ` · Transaction ID ${r.transactionRef}` : ""}
            {row.accountName ? ` · Into ${row.accountName}` : ""}
          </p>
          {isRefund ? null : (
            <p>
              Against: {applied.length > 0 ? applied.map((a) => a.number).join(", ") : "Customer advance (not yet applied to an invoice)"}
            </p>
          )}
        </section>

        <table className="mt-4 w-full border-collapse border border-slate-300">
          <tbody>
            <tr className="border-b border-slate-300">
              <td className="px-2 py-1 text-slate-600">Balance before this {isRefund ? "refund" : "payment"}</td>
              <td className="px-2 py-1 text-right">{formatBDT(centsToDb(balanceBefore))}</td>
            </tr>
            <tr className="border-b border-slate-300">
              <td className="px-2 py-1 text-slate-600">This {isRefund ? "refund" : "payment"}</td>
              <td className="px-2 py-1 text-right">{formatBDT(r.amount)}</td>
            </tr>
            <tr className="border-b border-slate-300 font-semibold">
              <td className="px-2 py-1">Balance remaining (still owed)</td>
              <td className="px-2 py-1 text-right">{formatBDT(centsToDb(balanceAfter))}</td>
            </tr>
            <tr>
              <td className="px-2 py-1 text-slate-600">Advance held by customer</td>
              <td className="px-2 py-1 text-right">{formatBDT(centsToDb(advance))}</td>
            </tr>
          </tbody>
        </table>

        {r.notes ? <p className="mt-3 text-slate-700">Note: {r.notes}</p> : null}
        {company.receiptFooter ? <p className="mt-4 whitespace-pre-line text-slate-600">{company.receiptFooter}</p> : null}

        <footer className="mt-10 grid grid-cols-2 gap-8 text-slate-700">
          <div className="border-t border-slate-400 pt-1 text-center">Received by{r.receivedByName ? `: ${r.receivedByName}` : ""}</div>
          <div className="border-t border-slate-400 pt-1 text-center">Authorised signature</div>
        </footer>
      </article>
    </div>
  );
}

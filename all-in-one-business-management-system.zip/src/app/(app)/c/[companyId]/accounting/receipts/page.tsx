import { and, count, desc, eq, gte, ilike, lte, or, sql, type SQL } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Card, Flash, PageHeader, Pagination, Stat, StatusBadge, btnPrimary, btnSecondary, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { customers, receipts } from "@/db/schema";
import { PAGE_SIZE, humanize } from "@/lib/constants";
import { escapeLike, firstParam, formatBDT, formatDate, parseId, parsePage } from "@/lib/format";
import { centsToDb, dbToCents } from "@/lib/money";
import { branchWhere, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function ReceiptsPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "accounting", "view");
  const sp = await searchParams;

  const q = firstParam(sp.q).trim();
  const kind = firstParam(sp.kind);
  const status = firstParam(sp.status);
  const from = firstParam(sp.from);
  const to = firstParam(sp.to);
  const page = parsePage(firstParam(sp.page));

  const conditions: (SQL | undefined)[] = [eq(receipts.companyId, companyId), branchWhere(ctx, receipts.branchId)];
  if (q) {
    const like = `%${escapeLike(q)}%`;
    conditions.push(or(ilike(receipts.number, like), ilike(customers.fullName, like), ilike(receipts.transactionRef, like)));
  }
  if (kind === "payment" || kind === "refund") conditions.push(eq(receipts.kind, kind));
  if (status === "active" || status === "cancelled") conditions.push(eq(receipts.status, status));
  if (/^\d{4}-\d{2}-\d{2}$/.test(from)) conditions.push(gte(receipts.receiptDate, from));
  if (/^\d{4}-\d{2}-\d{2}$/.test(to)) conditions.push(lte(receipts.receiptDate, to));
  const where = and(...conditions);

  const [rows, totalRows, totals] = await Promise.all([
    db
      .select({ receipt: receipts, customerName: customers.fullName, customerCode: customers.code })
      .from(receipts)
      .innerJoin(customers, eq(customers.id, receipts.customerId))
      .where(where)
      .orderBy(desc(receipts.receiptDate), desc(receipts.id))
      .limit(PAGE_SIZE)
      .offset((page - 1) * PAGE_SIZE),
    db
      .select({ value: count() })
      .from(receipts)
      .innerJoin(customers, eq(customers.id, receipts.customerId))
      .where(where),
    db
      .select({
        collected: sql<string>`coalesce(sum(case when ${receipts.kind} = 'payment' and ${receipts.status} = 'active' then ${receipts.amount} else 0 end), 0)`,
        refunded: sql<string>`coalesce(sum(case when ${receipts.kind} = 'refund' and ${receipts.status} = 'active' then ${receipts.amount} else 0 end), 0)`,
      })
      .from(receipts)
      .innerJoin(customers, eq(customers.id, receipts.customerId))
      .where(where),
  ]);
  const total = Number(totalRows[0]?.value ?? 0);
  const collected = dbToCents(totals[0]?.collected);
  const refunded = dbToCents(totals[0]?.refunded);

  return (
    <>
      <PageHeader
        title="Money receipts"
        description="Every payment received from customers. Each receipt has a permanent number, and cancelled receipts stay in the list."
        actions={
          <>
            {ctx.can("accounting", "export") ? (
              <a href={`/api/export?companyId=${companyId}&type=receipts`} className={btnSecondary}>
                Export CSV
              </a>
            ) : null}
            {ctx.can("accounting", "create") ? (
              <Link href={`/c/${companyId}/accounting/receipts/new`} className={btnPrimary}>
                Record payment
              </Link>
            ) : null}
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <Stat label="Collected (filtered)" value={formatBDT(centsToDb(collected))} />
        <Stat label="Refunded (filtered)" value={formatBDT(centsToDb(refunded))} />
        <Stat label="Net received (filtered)" value={formatBDT(centsToDb(collected - refunded))} />
      </div>

      <Card>
        <form method="get" className="mb-5 grid gap-3 md:grid-cols-[1fr_9rem_9rem_9rem_9rem_auto]">
          <input name="q" defaultValue={q} placeholder="Search receipt, customer or transaction ID" className="rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          <select name="kind" defaultValue={kind} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="">All types</option>
            <option value="payment">Payments</option>
            <option value="refund">Refunds</option>
          </select>
          <select name="status" defaultValue={status} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="">Any status</option>
            <option value="active">Active</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <input type="date" name="from" defaultValue={from} className="rounded-lg border border-slate-300 px-3 py-2 text-sm" aria-label="From date" />
          <input type="date" name="to" defaultValue={to} className="rounded-lg border border-slate-300 px-3 py-2 text-sm" aria-label="To date" />
          <button type="submit" className={btnPrimary}>
            Filter
          </button>
        </form>
        <div className="overflow-x-auto">
          <table className={tableClass}>
            <thead>
              <tr>
                <th className={thClass}>Receipt</th>
                <th className={thClass}>Date</th>
                <th className={thClass}>Customer</th>
                <th className={thClass}>Type</th>
                <th className={thClass}>Amount</th>
                <th className={thClass}>Method</th>
                <th className={thClass}>Status</th>
                <th className={thClass}>Printed</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.length === 0 ? (
                <tr>
                  <td className={tdClass} colSpan={8}>
                    No receipts match these filters.
                  </td>
                </tr>
              ) : null}
              {rows.map(({ receipt, customerName }) => (
                <tr key={receipt.id} className="hover:bg-slate-50">
                  <td className={tdClass}>
                    <Link href={`/c/${companyId}/accounting/receipts/${receipt.id}`} className="font-medium text-teal-800 hover:underline">
                      {receipt.number}
                    </Link>
                  </td>
                  <td className={tdClass}>{formatDate(receipt.receiptDate)}</td>
                  <td className={tdClass}>{customerName}</td>
                  <td className={tdClass}>{receipt.kind === "refund" ? "Refund" : "Payment"}</td>
                  <td className={tdClass}>{formatBDT(receipt.amount)}</td>
                  <td className={tdClass}>{humanize(receipt.paymentMethod)}</td>
                  <td className={tdClass}>
                    <StatusBadge status={receipt.status} />
                  </td>
                  <td className={tdClass}>{receipt.reprintCount > 0 ? `${receipt.reprintCount}×` : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination
          basePath={`/c/${companyId}/accounting/receipts`}
          page={page}
          pageSize={PAGE_SIZE}
          total={total}
          query={{ q, kind, status, from, to }}
        />
      </Card>
    </>
  );
}

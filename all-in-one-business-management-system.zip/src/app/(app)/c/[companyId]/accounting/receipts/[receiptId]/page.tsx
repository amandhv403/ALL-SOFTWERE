import { and, asc, eq } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { cancelReceipt, printReceipt } from "@/app/actions/accounting";
import { ConfirmSubmit } from "@/components/confirm-submit";
import { Card, DetailList, Flash, PageHeader, StatusBadge, btnPrimary, btnSecondary, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { cashAccounts, customers, invoices, paymentAllocations, receipts, users } from "@/db/schema";
import { humanize } from "@/lib/constants";
import { firstParam, formatBDT, formatDate, formatDateTime, parseId } from "@/lib/format";
import { dbToCents } from "@/lib/money";
import { inBranchScope, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function ReceiptDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string; receiptId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const routeParams = await params;
  const companyId = parseId(routeParams.companyId);
  const receiptId = parseId(routeParams.receiptId);
  if (!companyId || !receiptId) notFound();
  const ctx = await requirePage(companyId, "accounting", "view");
  const sp = await searchParams;

  const [row] = await db
    .select({ receipt: receipts, customerName: customers.fullName, customerCode: customers.code, accountName: cashAccounts.name, creatorName: users.fullName })
    .from(receipts)
    .innerJoin(customers, eq(customers.id, receipts.customerId))
    .leftJoin(cashAccounts, eq(cashAccounts.id, receipts.accountId))
    .leftJoin(users, eq(users.id, receipts.createdById))
    .where(and(eq(receipts.id, receiptId), eq(receipts.companyId, companyId)))
    .limit(1);
  if (!row || !inBranchScope(ctx, row.receipt.branchId)) notFound();
  const r = row.receipt;

  const allocations = await db
    .select({ allocation: paymentAllocations, invoiceNumber: invoices.number, invoiceStatus: invoices.status })
    .from(paymentAllocations)
    .innerJoin(invoices, eq(invoices.id, paymentAllocations.invoiceId))
    .where(eq(paymentAllocations.receiptId, receiptId))
    .orderBy(asc(invoices.number));

  const appliedCents = allocations.reduce((sum, a) => sum + dbToCents(a.allocation.amount), 0);
  const unusedCents = dbToCents(r.amount) - appliedCents;
  const canPrint = ctx.can("accounting", "print");
  const canCancel = ctx.can("accounting", "delete");

  return (
    <>
      <PageHeader
        title={`${r.kind === "refund" ? "Refund" : "Receipt"} ${r.number}`}
        description={`${row.customerName} (${row.customerCode}) · ${formatBDT(r.amount)}`}
        actions={
          <>
            <StatusBadge status={r.status} />
            {canPrint && r.status === "active" ? (
              <form action={printReceipt}>
                <input type="hidden" name="companyId" value={companyId} />
                <input type="hidden" name="receiptId" value={receiptId} />
                <button type="submit" className={btnPrimary}>
                  Print receipt
                </button>
              </form>
            ) : null}
            <Link href={`/c/${companyId}/crm/customers/${r.customerId}`} className={btnSecondary}>
              Customer
            </Link>
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <Card title="Receipt details">
            <DetailList
              items={[
                { label: "Receipt number", value: r.number },
                { label: "Date received", value: formatDate(r.receiptDate) },
                { label: "Amount", value: formatBDT(r.amount) },
                { label: "Type", value: r.kind === "refund" ? "Refund (money paid out)" : "Payment received" },
                { label: "Payment method", value: humanize(r.paymentMethod) },
                { label: "Transaction ID", value: r.transactionRef },
                { label: "Into account", value: row.accountName },
                { label: "Received by", value: r.receivedByName ?? row.creatorName },
                { label: "Recorded by", value: row.creatorName },
                { label: "Recorded at", value: formatDateTime(r.createdAt) },
                { label: "Times printed", value: r.reprintCount },
                { label: "Notes", value: r.notes },
              ]}
            />
          </Card>

          {r.kind === "payment" ? (
            <Card title="Where this money went">
              {allocations.length === 0 ? (
                <p className="text-sm text-slate-600">Not applied to any invoice yet. Unused money is held as the customer&apos;s advance.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className={tableClass}>
                    <thead>
                      <tr>
                        <th className={thClass}>Invoice</th>
                        <th className={thClass}>Invoice status</th>
                        <th className={thClass}>Applied</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {allocations.map((a) => (
                        <tr key={a.allocation.id}>
                          <td className={tdClass}>
                            <Link href={`/c/${companyId}/accounting/invoices/${a.allocation.invoiceId}`} className="text-teal-800 hover:underline">
                              {a.invoiceNumber}
                            </Link>
                          </td>
                          <td className={tdClass}>
                            <StatusBadge status={a.invoiceStatus} />
                          </td>
                          <td className={tdClass}>{formatBDT(a.allocation.amount)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              <p className="mt-4 text-sm text-slate-700">
                Unused (advance): <span className="font-semibold">{formatBDT(unusedCents / 100)}</span>
              </p>
            </Card>
          ) : null}
        </div>

        <div className="space-y-6">
          {canCancel && r.status === "active" ? (
            <Card title="Cancel this receipt" description="The receipt stays in the records with its number. Its money is removed from the invoices it paid.">
              <form action={cancelReceipt} className="space-y-3">
                <input type="hidden" name="companyId" value={companyId} />
                <input type="hidden" name="receiptId" value={receiptId} />
                <textarea name="reason" required minLength={5} rows={2} placeholder="Reason for cancelling (required)" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                <ConfirmSubmit label="Cancel receipt" message="Cancel this receipt? The invoices it paid will show the balance again. The number is not reused." className="rounded-lg bg-red-600 px-3 py-2 text-sm font-medium text-white hover:bg-red-700" />
              </form>
            </Card>
          ) : null}
          {r.status === "cancelled" ? (
            <Card title="Cancellation">
              <DetailList
                items={[
                  { label: "Cancelled on", value: formatDateTime(r.cancelledAt) },
                  { label: "Reason", value: r.cancelReason },
                ]}
              />
            </Card>
          ) : null}
        </div>
      </div>
    </>
  );
}

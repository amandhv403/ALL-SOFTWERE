import { and, asc, eq } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { createCashAccount, transferFunds } from "@/app/actions/accounting";
import { ActionForm } from "@/components/action-form";
import { Card, Flash, PageHeader, StatusBadge, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { accountTransfers, cashAccounts, expenses, receipts } from "@/db/schema";
import { ACCOUNT_TYPE_KEYS, humanize, optionsOf } from "@/lib/constants";
import { firstParam, formatBDT, formatDate, parseId, todayISO } from "@/lib/format";
import { accountBalances } from "@/lib/ledger";
import { centsToDb, dbToCents, type Cents } from "@/lib/money";
import { requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

type LedgerLine = { date: string; order: number; description: string; inCents: Cents; outCents: Cents };

export default async function CashBankPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "accounting", "view");
  const sp = await searchParams;

  const accounts = await db.select().from(cashAccounts).where(eq(cashAccounts.companyId, companyId)).orderBy(asc(cashAccounts.name));
  const balances = await accountBalances(companyId);
  const selectedId = parseId(firstParam(sp.account)) ?? accounts[0]?.id ?? null;
  const selected = accounts.find((a) => a.id === selectedId) ?? null;

  let ledger: LedgerLine[] = [];
  if (selected) {
    const [incoming, outgoing, transfersIn, transfersOut] = await Promise.all([
      db
        .select({ id: receipts.id, number: receipts.number, date: receipts.receiptDate, kind: receipts.kind, amount: receipts.amount, status: receipts.status })
        .from(receipts)
        .where(and(eq(receipts.companyId, companyId), eq(receipts.accountId, selected.id), eq(receipts.status, "active"))),
      db
        .select({ id: expenses.id, date: expenses.expenseDate, description: expenses.description, amount: expenses.amount })
        .from(expenses)
        .where(and(eq(expenses.companyId, companyId), eq(expenses.accountId, selected.id), eq(expenses.status, "approved"))),
      db
        .select({ id: accountTransfers.id, date: accountTransfers.transferDate, amount: accountTransfers.amount, reference: accountTransfers.reference })
        .from(accountTransfers)
        .where(and(eq(accountTransfers.companyId, companyId), eq(accountTransfers.toAccountId, selected.id))),
      db
        .select({ id: accountTransfers.id, date: accountTransfers.transferDate, amount: accountTransfers.amount, reference: accountTransfers.reference })
        .from(accountTransfers)
        .where(and(eq(accountTransfers.companyId, companyId), eq(accountTransfers.fromAccountId, selected.id))),
    ]);
    ledger = [
      ...incoming.map((r) => ({
        date: r.date,
        order: 1,
        description: `${r.kind === "refund" ? "Refund" : "Receipt"} ${r.number}`,
        inCents: r.kind === "refund" ? 0 : dbToCents(r.amount),
        outCents: r.kind === "refund" ? dbToCents(r.amount) : 0,
      })),
      ...outgoing.map((e) => ({ date: e.date, order: 2, description: `Expense: ${e.description}`, inCents: 0, outCents: dbToCents(e.amount) })),
      ...transfersIn.map((t) => ({ date: t.date, order: 3, description: `Transfer in${t.reference ? ` (${t.reference})` : ""}`, inCents: dbToCents(t.amount), outCents: 0 })),
      ...transfersOut.map((t) => ({ date: t.date, order: 3, description: `Transfer out${t.reference ? ` (${t.reference})` : ""}`, inCents: 0, outCents: dbToCents(t.amount) })),
    ].sort((a, b) => (a.date === b.date ? a.order - b.order : a.date < b.date ? -1 : 1));
  }

  // Running balance, shown newest first.
  const withBalance: (LedgerLine & { balance: Cents })[] = [];
  let running = selected ? dbToCents(selected.openingBalance) : 0;
  for (const line of ledger) {
    running += line.inCents - line.outCents;
    withBalance.push({ ...line, balance: running });
  }

  const canEdit = ctx.can("accounting", "edit");
  const canTransfer = ctx.can("accounting", "create");

  return (
    <>
      <PageHeader
        title="Cash and bank"
        description="Every cash box, bank account and mobile wallet (bKash, Nagad, Rocket, Upay). Balances update automatically from receipts, expenses and transfers."
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <Card title="Accounts and balances">
        <div className="overflow-x-auto">
          <table className={tableClass}>
            <thead>
              <tr>
                <th className={thClass}>Account</th>
                <th className={thClass}>Type</th>
                <th className={thClass}>Provider / bank</th>
                <th className={thClass}>Number (masked)</th>
                <th className={thClass}>Opening</th>
                <th className={thClass}>Current balance</th>
                <th className={thClass}>Status</th>
                <th className={thClass}></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {accounts.length === 0 ? (
                <tr>
                  <td className={tdClass} colSpan={8}>
                    No accounts yet. Add your cash box, bank account or mobile wallet below.
                  </td>
                </tr>
              ) : null}
              {accounts.map((a) => (
                <tr key={a.id} className={a.id === selectedId ? "bg-teal-50/50" : ""}>
                  <td className={tdClass}>
                    <p className="font-medium text-slate-900">{a.name}</p>
                  </td>
                  <td className={tdClass}>{humanize(a.accountType)}</td>
                  <td className={tdClass}>{a.providerName ?? "—"}</td>
                  <td className={tdClass}>{a.accountNumberMasked ?? "—"}</td>
                  <td className={tdClass}>{formatBDT(a.openingBalance)}</td>
                  <td className={tdClass}>
                    <span className="font-semibold">{formatBDT(centsToDb(balances.get(a.id) ?? 0))}</span>
                  </td>
                  <td className={tdClass}>
                    <StatusBadge status={a.isActive ? "active" : "cancelled"} label={a.isActive ? "Active" : "Inactive"} />
                  </td>
                  <td className={tdClass}>
                    <Link href={`/c/${companyId}/accounting/cash-bank?account=${a.id}`} className={btnSmall}>
                      View ledger
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2" title={selected ? `Ledger: ${selected.name}` : "Ledger"} description="Money in and out, newest first. Opening balance is at the bottom.">
          {!selected ? (
            <p className="text-sm text-slate-600">Add an account to see its ledger.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className={tableClass}>
                <thead>
                  <tr>
                    <th className={thClass}>Date</th>
                    <th className={thClass}>Description</th>
                    <th className={thClass}>In</th>
                    <th className={thClass}>Out</th>
                    <th className={thClass}>Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {withBalance.length === 0 ? (
                    <tr>
                      <td className={tdClass} colSpan={5}>
                        No movements yet.
                      </td>
                    </tr>
                  ) : null}
                  {[...withBalance].reverse().map((line, index) => (
                    <tr key={`${line.date}-${index}`}>
                      <td className={tdClass}>{formatDate(line.date)}</td>
                      <td className={tdClass}>{line.description}</td>
                      <td className={tdClass}>{line.inCents ? formatBDT(centsToDb(line.inCents)) : "—"}</td>
                      <td className={tdClass}>{line.outCents ? formatBDT(centsToDb(line.outCents)) : "—"}</td>
                      <td className={tdClass}>{formatBDT(centsToDb(line.balance))}</td>
                    </tr>
                  ))}
                  <tr className="bg-slate-50">
                    <td className={tdClass}>Opening</td>
                    <td className={tdClass}>Opening balance</td>
                    <td className={tdClass}>—</td>
                    <td className={tdClass}>—</td>
                    <td className={tdClass}>{formatBDT(selected.openingBalance)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <div className="space-y-6">
          {canEdit ? (
            <Card title="Add an account">
              <ActionForm
                action={createCashAccount}
                columns={1}
                hidden={{ companyId: String(companyId) }}
                submitLabel="Add account"
                fields={[
                  { name: "name", label: "Account name", required: true, placeholder: "e.g. Head office cash" },
                  { name: "accountType", label: "Type", type: "select", options: optionsOf(ACCOUNT_TYPE_KEYS), defaultValue: "cash" },
                  { name: "providerName", label: "Bank or provider", placeholder: "e.g. Dutch-Bangla Bank, bKash" },
                  { name: "accountNumberMasked", label: "Account number (masked, e.g. ****1234)" },
                  { name: "openingBalance", label: "Opening balance (৳)", type: "number", step: "0.01", defaultValue: "0" },
                ]}
              />
            </Card>
          ) : null}
          {canTransfer && accounts.length >= 2 ? (
            <Card title="Move money between accounts" description="For example, from bKash to the bank.">
              <ActionForm
                action={transferFunds}
                columns={1}
                hidden={{ companyId: String(companyId) }}
                submitLabel="Record transfer"
                fields={[
                  { name: "fromAccountId", label: "From", type: "select", required: true, options: accounts.map((a) => ({ value: String(a.id), label: `${a.name} (${formatBDT(centsToDb(balances.get(a.id) ?? 0))})` })) },
                  { name: "toAccountId", label: "To", type: "select", required: true, options: accounts.map((a) => ({ value: String(a.id), label: a.name })) },
                  { name: "amount", label: "Amount (৳)", type: "number", step: "0.01", min: "0.01", required: true },
                  { name: "transferDate", label: "Date", type: "date", defaultValue: todayISO() },
                  { name: "reference", label: "Reference" },
                ]}
              />
            </Card>
          ) : null}
        </div>
      </div>
    </>
  );
}

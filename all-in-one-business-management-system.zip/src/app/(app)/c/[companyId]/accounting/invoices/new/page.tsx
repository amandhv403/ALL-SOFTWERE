import { and, asc, eq } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { createDocument } from "@/app/actions/accounting";
import { ActionForm, type FieldDef } from "@/components/action-form";
import { Card, PageHeader, btnSecondary } from "@/components/ui";
import { db } from "@/db";
import { customers, services, visaApplications } from "@/db/schema";
import { firstParam, formatBDT, parseId, todayISO } from "@/lib/format";
import { centsToDb, dbToCents } from "@/lib/money";
import { branchWhere, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function NewInvoicePage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "accounting", "create");
  const sp = await searchParams;

  const docType = firstParam(sp.type) === "quotation" ? "quotation" : "invoice";
  const presetCustomer = firstParam(sp.customerId);
  const visaId = parseId(firstParam(sp.visaId));

  const [customerRows, serviceRows, visaRows] = await Promise.all([
    db
      .select({ id: customers.id, code: customers.code, fullName: customers.fullName })
      .from(customers)
      .where(and(eq(customers.companyId, companyId), eq(customers.isArchived, false), branchWhere(ctx, customers.branchId)))
      .orderBy(asc(customers.fullName))
      .limit(800),
    db
      .select()
      .from(services)
      .where(and(eq(services.companyId, companyId), eq(services.isActive, true)))
      .orderBy(asc(services.name)),
    db
      .select({ id: visaApplications.id, code: visaApplications.code, customerId: visaApplications.customerId, destinationCountry: visaApplications.destinationCountry, visaCategory: visaApplications.visaCategory, serviceFee: visaApplications.serviceFee })
      .from(visaApplications)
      .where(eq(visaApplications.companyId, companyId))
      .orderBy(asc(visaApplications.code))
      .limit(500),
  ]);

  // When opened from a visa file, the first line is filled with that file's details and fee.
  const visa = visaId ? visaRows.find((v) => v.id === visaId) : undefined;
  const prefill = visa
    ? {
        customerId: String(visa.customerId),
        description: `Visa service: ${visa.destinationCountry} (${visa.visaCategory}) – file ${visa.code}`,
        price: centsToDb(dbToCents(visa.serviceFee)),
        visaApplicationId: String(visa.id),
        serviceReference: visa.code,
      }
    : {
        customerId: presetCustomer,
        description: firstParam(sp.description),
        price: firstParam(sp.amount),
        visaApplicationId: "",
        serviceReference: "",
      };

  const serviceOptions = [{ value: "", label: "Custom item (type below)" }, ...serviceRows.map((s) => ({ value: String(s.id), label: `${s.name} · ${formatBDT(s.unitPrice)}` }))];
  const visaOptions = [{ value: "", label: "Not linked to a visa file" }, ...visaRows.map((v) => ({ value: String(v.id), label: `${v.code} · ${v.destinationCountry}` }))];

  const fields: FieldDef[] = [
    { name: "h-parties", label: "Customer and dates", type: "heading" },
    { name: "docType", label: "Document type", type: "select", options: [{ value: "invoice", label: "Invoice (bill to pay)" }, { value: "quotation", label: "Quotation (price offer)" }], defaultValue: docType },
    {
      name: "customerId",
      label: "Customer",
      type: "select",
      required: true,
      options: [{ value: "", label: "Choose a customer…" }, ...customerRows.map((c) => ({ value: String(c.id), label: `${c.fullName} (${c.code})` }))],
      defaultValue: prefill.customerId,
    },
    { name: "issueDate", label: "Date", type: "date", required: true, defaultValue: todayISO() },
    { name: "dueDate", label: "Payment due date", type: "date" },
    { name: "visaApplicationId", label: "Linked visa file (optional)", type: "select", options: visaOptions, defaultValue: prefill.visaApplicationId },
    { name: "serviceReference", label: "Reference (visa file, booking or order)", defaultValue: prefill.serviceReference },
  ];
  for (let n = 1; n <= 5; n++) {
    fields.push(
      { name: `h-item-${n}`, label: `Item ${n}${n === 1 ? " (required)" : " (optional)"}`, type: "heading" },
      { name: `item${n}_service`, label: "Choose from catalogue", type: "select", options: serviceOptions },
      { name: `item${n}_description`, label: "Description", wide: true, defaultValue: n === 1 ? prefill.description : "" },
      { name: `item${n}_qty`, label: "Quantity", type: "number", step: "0.01", min: "0", defaultValue: "1" },
      { name: `item${n}_price`, label: "Unit price (৳)", type: "number", step: "0.01", min: "0", defaultValue: n === 1 ? prefill.price : "" },
      { name: `item${n}_tax`, label: "Tax / VAT (%)", type: "number", step: "0.01", min: "0", max: "100", defaultValue: "0" },
    );
  }
  fields.push(
    { name: "h-totals", label: "Discount and notes", type: "heading" },
    { name: "discount", label: "Discount on the whole document (৳)", type: "number", step: "0.01", min: "0", defaultValue: "0" },
    { name: "terms", label: "Terms (printed at the bottom)", type: "textarea", defaultValue: "Payment is due on the date shown. Please quote the number on payments." },
    { name: "notes", label: "Internal notes (not printed)", type: "textarea", wide: true },
  );

  return (
    <>
      <PageHeader
        title={docType === "invoice" ? "New invoice" : "New quotation"}
        description="Add up to five items. Prices can be filled in automatically from the service catalogue. Totals, tax and the number are calculated for you."
        actions={
          <Link href={`/c/${companyId}/accounting/invoices?type=${docType}`} className={btnSecondary}>
            Back to list
          </Link>
        }
      />
      <Card>
        {customerRows.length === 0 ? (
          <p className="text-sm text-slate-600">
            Register a customer first. <Link href={`/c/${companyId}/crm/customers`} className="font-medium text-teal-800 underline">Go to customers</Link>
          </p>
        ) : (
          <ActionForm action={createDocument} hidden={{ companyId: String(companyId) }} submitLabel={docType === "invoice" ? "Issue invoice" : "Save quotation"} fields={fields} />
        )}
      </Card>
    </>
  );
}

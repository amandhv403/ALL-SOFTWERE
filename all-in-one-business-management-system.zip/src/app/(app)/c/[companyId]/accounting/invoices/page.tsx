import { and, count, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Card, Flash, PageHeader, Pagination, Stat, StatusBadge, btnPrimary, btnSecondary, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { customers, invoices } from "@/db/schema";
import { INVOICE_STATUS_KEYS, QUOTATION_STATUS_KEYS, PAGE_SIZE, humanize, type DocType, type InvoiceStatus } from "@/lib/constants";
import { escapeLike, firstParam, formatBDT, formatDate, parseId, parsePage } from "@/lib/format";
import { centsToDb, dbToCents } from "@/lib/money";
import { branchWhere, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function InvoicesPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const companyId = parseId((await params).companyId);
  if (!companyId) notFound();
  const ctx = await requirePage(companyId, "accounting", "view");
  const sp = await searchParams;

  const docType: DocType = firstParam(sp.type) === "quotation" ? "quotation" : "invoice";
  const q = firstParam(sp.q).trim();
  const status = firstParam(sp.status);
  const page = parsePage(firstParam(sp.page));
  const allowedStatuses: readonly string[] = docType === "invoice" ? INVOICE_STATUS_KEYS : QUOTATION_STATUS_KEYS;

  const conditions: (SQL | undefined)[] = [eq(invoices.companyId, companyId), eq(invoices.docType, docType), branchWhere(ctx, invoices.branchId)];
  if (q) {
    const like = `%${escapeLike(q)}%`;
    conditions.push(or(ilike(invoices.number, like), ilike(customers.fullName, like), ilike(invoices.serviceReference, like)));
  }
  if (allowedStatuses.includes(status)) conditions.push(eq(invoices.status, status as InvoiceStatus));
  const where = and(...conditions);

  const [rows, totalRows, summaryRows] = await Promise.all([
    db
      .select({ inv: invoices, customerName: customers.fullName, customerCode: customers.code })
      .from(invoices)
      .innerJoin(customers, eq(customers.id, invoices.customerId))
      .where(where)
      .orderBy(desc(invoices.issueDate), desc(invoices.id))
      .limit(PAGE_SIZE)
      .offset((page - 1) * PAGE_SIZE),
    db
      .select({ value: count() })
      .from(invoices)
      .innerJoin(customers, eq(customers.id, invoices.customerId))
      .where(where),
    db
      .select({
        billed: sql<string>`coalesce(sum(case when ${invoices.status} <> 'cancelled' then ${invoices.total} else 0 end), 0)`,
        due: sql<string>`coalesce(sum(${invoices.dueAmount}), 0)`,
      })
      .from(invoices)
      .where(and(eq(invoices.companyId, companyId), eq(invoices.docType, "invoice"), branchWhere(ctx, invoices.branchId))),
  ]);
  const total = Number(totalRows[0]?.value ?? 0);
  const canCreate = ctx.can("accounting", "create");

  return (
    <>
      <PageHeader
        title={docType === "invoice" ? "Invoices" : "Quotations"}
        description={
          docType === "invoice"
            ? "Bills sent to customers. Each invoice gets a permanent number from your company's sequence."
            : "Price offers. Convert an accepted quotation into an invoice with one click."
        }
        actions={
          <>
            <Link href={`/c/${companyId}/accounting/invoices?type=${docType === "invoice" ? "quotation" : "invoice"}`} className={btnSecondary}>
              Show {docType === "invoice" ? "quotations" : "invoices"}
            </Link>
            {canCreate ? (
              <Link href={`/c/${companyId}/accounting/invoices/new?type=${docType}`} className={btnPrimary}>
                New {docType}
              </Link>
            ) : null}
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="mb-6 grid gap-4 sm:grid-cols-2">
        <Stat label="Total invoiced (not cancelled)" value={formatBDT(centsToDb(dbToCents(summaryRows[0]?.billed)))} />
        <Stat label="Still to be collected" value={formatBDT(centsToDb(dbToCents(summaryRows[0]?.due)))} tone="red" />
      </div>

      <Card>
        <form method="get" className="mb-5 grid gap-3 md:grid-cols-[1fr_14rem_auto]">
          <input type="hidden" name="type" value={docType} />
          <input name="q" defaultValue={q} placeholder="Search number, customer or visa reference" className="rounded-lg border border-slate-300 px-3 py-2 text-sm" />
          <select name="status" defaultValue={status} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            <option value="">All statuses</option>
            {(docType === "invoice" ? INVOICE_STATUS_KEYS : QUOTATION_STATUS_KEYS).map((s) => (
              <option key={s} value={s}>
                {humanize(s)}
              </option>
            ))}
          </select>
          <button type="submit" className={btnPrimary}>
            Filter
          </button>
        </form>
        <div className="overflow-x-auto">
          <table className={tableClass}>
            <thead>
              <tr>
                <th className={thClass}>Number</th>
                <th className={thClass}>Date</th>
                <th className={thClass}>Customer</th>
                <th className={thClass}>Total</th>
                {docType === "invoice" ? <th className={thClass}>Paid</th> : null}
                {docType === "invoice" ? <th className={thClass}>Due</th> : null}
                <th className={thClass}>Status</th>
                <th className={thClass}>Reference</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.length === 0 ? (
                <tr>
                  <td className={tdClass} colSpan={8}>
                    No {docType === "invoice" ? "invoices" : "quotations"} yet.
                  </td>
                </tr>
              ) : null}
              {rows.map(({ inv, customerName }) => (
                <tr key={inv.id} className="hover:bg-slate-50">
                  <td className={tdClass}>
                    <Link href={`/c/${companyId}/accounting/invoices/${inv.id}`} className="font-medium text-teal-800 hover:underline">
                      {inv.number}
                    </Link>
                  </td>
                  <td className={tdClass}>{formatDate(inv.issueDate)}</td>
                  <td className={tdClass}>{customerName}</td>
                  <td className={tdClass}>{formatBDT(inv.total)}</td>
                  {docType === "invoice" ? <td className={tdClass}>{formatBDT(inv.paidAmount)}</td> : null}
                  {docType === "invoice" ? <td className={tdClass}>{formatBDT(inv.dueAmount)}</td> : null}
                  <td className={tdClass}>
                    <StatusBadge status={inv.status} />
                  </td>
                  <td className={tdClass}>{inv.serviceReference ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination basePath={`/c/${companyId}/accounting/invoices`} page={page} pageSize={PAGE_SIZE} total={total} query={{ type: docType, q, status }} />
      </Card>
    </>
  );
}

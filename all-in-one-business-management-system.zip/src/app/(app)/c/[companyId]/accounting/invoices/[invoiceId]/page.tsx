import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { applyAdvance, cancelDocument, convertQuotation, setQuotationStatus } from "@/app/actions/accounting";
import { ActionForm } from "@/components/action-form";
import { ConfirmSubmit } from "@/components/confirm-submit";
import { Badge, Card, DetailList, Flash, PageHeader, StatusBadge, btnPrimary, btnSecondary, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { customers, invoiceItems, invoices, paymentAllocations, receipts, visaApplications } from "@/db/schema";
import { humanize } from "@/lib/constants";
import { firstParam, formatBDT, formatDate, formatDateTime, parseId } from "@/lib/format";
import { customerAdvanceCents } from "@/lib/ledger";
import { centsToDb, dbToCents } from "@/lib/money";
import { inBranchScope, requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function InvoiceDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ companyId: string; invoiceId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const routeParams = await params;
  const companyId = parseId(routeParams.companyId);
  const invoiceId = parseId(routeParams.invoiceId);
  if (!companyId || !invoiceId) notFound();
  const ctx = await requirePage(companyId, "accounting", "view");
  const sp = await searchParams;

  const [row] = await db
    .select({ inv: invoices, customerName: customers.fullName, customerCode: customers.code, visaCode: visaApplications.code })
    .from(invoices)
    .innerJoin(customers, eq(customers.id, invoices.customerId))
    .leftJoin(visaApplications, eq(visaApplications.id, invoices.visaApplicationId))
    .where(and(eq(invoices.id, invoiceId), eq(invoices.companyId, companyId)))
    .limit(1);
  if (!row || !inBranchScope(ctx, row.inv.branchId)) notFound();
  const inv = row.inv;
  const isInvoice = inv.docType === "invoice";

  const [items, allocations, openReceipts, advance] = await Promise.all([
    db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, invoiceId)).orderBy(asc(invoiceItems.sortOrder)),
    isInvoice
      ? db
          .select({ allocation: paymentAllocations, receiptNumber: receipts.number, receiptDate: receipts.receiptDate, method: receipts.paymentMethod, status: receipts.status })
          .from(paymentAllocations)
          .innerJoin(receipts, eq(receipts.id, paymentAllocations.receiptId))
          .where(eq(paymentAllocations.invoiceId, invoiceId))
          .orderBy(desc(receipts.receiptDate))
      : Promise.resolve([]),
    isInvoice && (inv.status === "issued" || inv.status === "partially_paid") && ctx.can("accounting", "create")
      ? db
          .select({ id: receipts.id, number: receipts.number, amount: receipts.amount })
          .from(receipts)
          .where(and(eq(receipts.companyId, companyId), eq(receipts.customerId, inv.customerId), eq(receipts.kind, "payment"), eq(receipts.status, "active")))
          .orderBy(desc(receipts.receiptDate))
      : Promise.resolve([]),
    isInvoice ? customerAdvanceCents(companyId, inv.customerId) : Promise.resolve(0),
  ]);

  // Money from each open receipt that has not been applied yet.
  const usedRows =
    openReceipts.length > 0
      ? await db
          .select({ receiptId: paymentAllocations.receiptId, total: sql<string>`coalesce(sum(${paymentAllocations.amount}), 0)` })
          .from(paymentAllocations)
          .where(inArray(paymentAllocations.receiptId, openReceipts.map((r) => r.id)))
          .groupBy(paymentAllocations.receiptId)
      : [];
  const usedMap = new Map(usedRows.map((r) => [r.receiptId, dbToCents(r.total)]));
  const unusedReceipts = openReceipts
    .map((r) => ({ ...r, unused: dbToCents(r.amount) - (usedMap.get(r.id) ?? 0) }))
    .filter((r) => r.unused > 0);

  const canCancel = ctx.can("accounting", "delete");
  const isOpenQuote = !isInvoice && inv.status !== "converted" && inv.status !== "cancelled";

  return (
    <>
      <PageHeader
        title={`${isInvoice ? "Invoice" : "Quotation"} ${inv.number}`}
        description={`${row.customerName} (${row.customerCode})${row.visaCode ? ` · Visa file ${row.visaCode}` : ""}`}
        actions={
          <>
            <StatusBadge status={inv.status} />
            <Link href={`/c/${companyId}/accounting/invoices/${invoiceId}/print`} target="_blank" className={btnSecondary}>
              Print / PDF
            </Link>
            {isInvoice && (inv.status === "issued" || inv.status === "partially_paid") && ctx.can("accounting", "create") ? (
              <Link href={`/c/${companyId}/accounting/receipts/new?customerId=${inv.customerId}&invoiceId=${invoiceId}`} className={btnPrimary}>
                Record payment
              </Link>
            ) : null}
          </>
        }
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <Card title="Items">
            <div className="overflow-x-auto">
              <table className={tableClass}>
                <thead>
                  <tr>
                    <th className={thClass}>Description</th>
                    <th className={thClass}>Qty</th>
                    <th className={thClass}>Unit price</th>
                    <th className={thClass}>Tax</th>
                    <th className={thClass}>Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {items.map((item) => (
                    <tr key={item.id}>
                      <td className={tdClass}>{item.description}</td>
                      <td className={tdClass}>{Number(item.quantity)}</td>
                      <td className={tdClass}>{formatBDT(item.unitPrice)}</td>
                      <td className={tdClass}>{Number(item.taxRate)}%</td>
                      <td className={tdClass}>{formatBDT(item.lineTotal)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <dl className="ml-auto mt-5 w-full max-w-sm space-y-1 text-sm">
              <div className="flex justify-between"><dt className="text-slate-600">Subtotal</dt><dd>{formatBDT(inv.subtotal)}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-600">Tax</dt><dd>{formatBDT(inv.taxAmount)}</dd></div>
              <div className="flex justify-between"><dt className="text-slate-600">Discount</dt><dd>- {formatBDT(inv.discountAmount)}</dd></div>
              <div className="flex justify-between border-t border-slate-200 pt-2 text-base font-semibold"><dt>Total</dt><dd>{formatBDT(inv.total)}</dd></div>
              {isInvoice ? (
                <>
                  <div className="flex justify-between"><dt className="text-slate-600">Paid</dt><dd>{formatBDT(inv.paidAmount)}</dd></div>
                  <div className="flex justify-between font-semibold text-red-700"><dt>Due</dt><dd>{formatBDT(inv.dueAmount)}</dd></div>
                </>
              ) : null}
            </dl>
          </Card>

          {isInvoice ? (
            <Card title="Payments applied" description="Money received against this invoice. Cancelled receipts are not counted.">
              {allocations.length === 0 ? (
                <p className="text-sm text-slate-600">No payments have been applied to this invoice yet.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className={tableClass}>
                    <thead>
                      <tr>
                        <th className={thClass}>Receipt</th>
                        <th className={thClass}>Date</th>
                        <th className={thClass}>Method</th>
                        <th className={thClass}>Applied</th>
                        <th className={thClass}>Receipt status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {allocations.map((a) => (
                        <tr key={a.allocation.id}>
                          <td className={tdClass}>
                            <Link href={`/c/${companyId}/accounting/receipts/${a.allocation.receiptId}`} className="text-teal-800 hover:underline">
                              {a.receiptNumber}
                            </Link>
                          </td>
                          <td className={tdClass}>{formatDate(a.receiptDate)}</td>
                          <td className={tdClass}>{humanize(a.method)}</td>
                          <td className={tdClass}>{formatBDT(a.allocation.amount)}</td>
                          <td className={tdClass}>
                            <StatusBadge status={a.status} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {unusedReceipts.length > 0 && inv.status !== "paid" && ctx.can("accounting", "create") ? (
                <div className="mt-6 rounded-xl bg-amber-50 p-4">
                  <p className="text-sm font-medium text-amber-900">
                    This customer has unused money (advance) on their receipts. Apply it to this invoice:
                  </p>
                  <div className="mt-3">
                    <ActionForm
                      action={applyAdvance}
                      columns={2}
                      hidden={{ companyId: String(companyId), invoiceId: String(invoiceId) }}
                      submitLabel="Apply to this invoice"
                      fields={[
                        {
                          name: "receiptId",
                          label: "Receipt with unused money",
                          type: "select",
                          required: true,
                          options: unusedReceipts.map((r) => ({ value: String(r.id), label: `${r.number} · unused ${formatBDT(centsToDb(r.unused))}` })),
                        },
                        { name: "amount", label: "Amount to apply (৳, empty = as much as possible)", type: "number", step: "0.01", min: "0" },
                      ]}
                    />
                  </div>
                </div>
              ) : null}
              {advance > 0 ? <p className="mt-4 text-xs text-slate-500">This customer currently holds {formatBDT(centsToDb(advance))} in advance across all receipts.</p> : null}
            </Card>
          ) : null}

          {(inv.notes || inv.terms) ? (
            <Card title="Notes">
              {inv.terms ? <p className="text-sm text-slate-700"><span className="font-medium">Printed terms:</span> {inv.terms}</p> : null}
              {inv.notes ? <p className="mt-2 text-sm text-slate-700"><span className="font-medium">Internal note:</span> {inv.notes}</p> : null}
            </Card>
          ) : null}
        </div>

        <div className="space-y-6">
          <Card title="Document details">
            <DetailList
              items={[
                { label: "Issue date", value: formatDate(inv.issueDate) },
                { label: "Due date", value: formatDate(inv.dueDate) },
                { label: "Reference", value: inv.serviceReference },
                { label: "Created", value: formatDateTime(inv.createdAt) },
                { label: "Converted from quotation", value: inv.sourceQuotationId ? <Link className="text-teal-800 hover:underline" href={`/c/${companyId}/accounting/invoices/${inv.sourceQuotationId}`}>Open quotation</Link> : null },
                { label: "Cancelled on", value: inv.cancelledAt ? formatDateTime(inv.cancelledAt) : null },
                { label: "Cancel reason", value: inv.cancelReason },
              ]}
            />
          </Card>

          {isOpenQuote && ctx.can("accounting", "create") ? (
            <Card title="Quotation actions">
              <div className="flex flex-wrap gap-2">
                {(["sent", "accepted", "rejected"] as const).map((s) => (
                  <form key={s} action={setQuotationStatus}>
                    <input type="hidden" name="companyId" value={companyId} />
                    <input type="hidden" name="invoiceId" value={invoiceId} />
                    <input type="hidden" name="status" value={s} />
                    <button type="submit" className={btnSmall}>
                      Mark {humanize(s).toLowerCase()}
                    </button>
                  </form>
                ))}
              </div>
              <form action={convertQuotation} className="mt-4">
                <input type="hidden" name="companyId" value={companyId} />
                <input type="hidden" name="invoiceId" value={invoiceId} />
                <ConfirmSubmit label="Convert into invoice" message="Create a new invoice from this quotation? The quotation will be marked as converted." className={btnPrimary} />
              </form>
            </Card>
          ) : null}

          {canCancel && inv.status !== "cancelled" && inv.status !== "converted" ? (
            <Card title="Cancel this document" description="Cancelling keeps the number and the record. It cannot be undone, so write a clear reason.">
              <form action={cancelDocument} className="space-y-3">
                <input type="hidden" name="companyId" value={companyId} />
                <input type="hidden" name="invoiceId" value={invoiceId} />
                <textarea name="reason" required minLength={5} rows={2} placeholder="Reason for cancelling (required)" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
                <ConfirmSubmit label="Cancel document" message="Cancel this document? Its number will not be reused." className="rounded-lg bg-red-600 px-3 py-2 text-sm font-medium text-white hover:bg-red-700" />
              </form>
            </Card>
          ) : null}

          {inv.status === "cancelled" ? <Badge tone="red">This document is cancelled</Badge> : null}
        </div>
      </div>
    </>
  );
}

import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { PrintButton } from "@/components/print-button";
import { db } from "@/db";
import { customers, invoiceItems, invoices } from "@/db/schema";
import { humanize } from "@/lib/constants";
import { formatBDT, formatDate, parseId } from "@/lib/format";
import { requirePage } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function InvoicePrintPage({ params }: { params: Promise<{ companyId: string; invoiceId: string }> }) {
  const routeParams = await params;
  const companyId = parseId(routeParams.companyId);
  const invoiceId = parseId(routeParams.invoiceId);
  if (!companyId || !invoiceId) notFound();
  const ctx = await requirePage(companyId, "accounting", "print");
  const company = ctx.company;

  const [row] = await db
    .select({ inv: invoices, customerName: customers.fullName, customerPhone: customers.phone, customerAddress: customers.address, customerCity: customers.city })
    .from(invoices)
    .innerJoin(customers, eq(customers.id, invoices.customerId))
    .where(eq(invoices.id, invoiceId))
    .limit(1);
  if (!row || row.inv.companyId !== companyId) notFound();
  const inv = row.inv;
  const items = await db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, invoiceId)).orderBy(invoiceItems.sortOrder);
  const isInvoice = inv.docType === "invoice";
  const isCancelled = inv.status === "cancelled";

  return (
    <div className="min-h-screen bg-slate-200 py-6 print:bg-white print:py-0">
      <div className="mx-auto mb-4 flex max-w-[210mm] justify-end gap-3 print:hidden">
        <PrintButton />
      </div>
      <article className="mx-auto min-h-[297mm] w-full max-w-[210mm] bg-white p-10 text-[13px] leading-relaxed text-slate-900 shadow-lg print:max-w-none print:shadow-none" style={{ ["--brand" as string]: company.brandColor }}>
        <header className="flex items-start justify-between gap-6 border-b-4 pb-5" style={{ borderColor: company.brandColor }}>
          <div className="flex items-center gap-4">
            {company.logoDocumentId ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={`/api/files/${company.logoDocumentId}`} alt="" className="h-16 w-auto object-contain" />
            ) : null}
            <div>
              <h1 className="text-xl font-bold" style={{ color: company.brandColor }}>{company.legalName || company.name}</h1>
              <p className="text-xs text-slate-600">{[company.address, company.city].filter(Boolean).join(", ")}</p>
              <p className="text-xs text-slate-600">{[company.phone, company.email, company.website].filter(Boolean).join(" · ")}</p>
              {company.taxId || company.registrationNo ? (
                <p className="text-xs text-slate-600">{[company.taxId ? `TIN/BIN: ${company.taxId}` : null, company.registrationNo ? `Reg: ${company.registrationNo}` : null].filter(Boolean).join(" · ")}</p>
              ) : null}
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold uppercase tracking-wide" style={{ color: company.brandColor }}>{isInvoice ? "Invoice" : "Quotation"}</p>
            <p className="mt-1 font-semibold">{inv.number}</p>
            <p className="text-xs text-slate-600">Date: {formatDate(inv.issueDate)}</p>
            {inv.dueDate ? <p className="text-xs text-slate-600">Due: {formatDate(inv.dueDate)}</p> : null}
          </div>
        </header>

        <section className="mt-6 grid grid-cols-2 gap-6">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Bill to</p>
            <p className="mt-1 font-semibold">{row.customerName}</p>
            <p className="text-xs text-slate-600">{[row.customerAddress, row.customerCity].filter(Boolean).join(", ")}</p>
            <p className="text-xs text-slate-600">{row.customerPhone ?? ""}</p>
          </div>
          <div className="text-right">
            {inv.serviceReference ? (
              <>
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Reference</p>
                <p className="mt-1">{inv.serviceReference}</p>
              </>
            ) : null}
          </div>
        </section>

        {isCancelled ? (
          <div className="mt-4 rounded border-2 border-red-600 px-3 py-2 text-center font-bold uppercase tracking-widest text-red-700">Cancelled</div>
        ) : null}

        <table className="mt-6 w-full border-collapse text-sm">
          <thead>
            <tr style={{ backgroundColor: company.brandColor, color: "#fff" }}>
              <th className="px-3 py-2 text-left">#</th>
              <th className="px-3 py-2 text-left">Description</th>
              <th className="px-3 py-2 text-right">Qty</th>
              <th className="px-3 py-2 text-right">Unit price</th>
              <th className="px-3 py-2 text-right">Tax</th>
              <th className="px-3 py-2 text-right">Amount</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={item.id} className="border-b border-slate-200">
                <td className="px-3 py-2">{index + 1}</td>
                <td className="px-3 py-2">{item.description}</td>
                <td className="px-3 py-2 text-right">{Number(item.quantity)}</td>
                <td className="px-3 py-2 text-right">{formatBDT(item.unitPrice).replace("৳ ", "")}</td>
                <td className="px-3 py-2 text-right">{Number(item.taxRate)}%</td>
                <td className="px-3 py-2 text-right">{formatBDT(item.lineTotal).replace("৳ ", "")}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="ml-auto mt-5 w-full max-w-xs space-y-1 text-sm">
          <div className="flex justify-between"><span>Subtotal</span><span>{formatBDT(inv.subtotal)}</span></div>
          <div className="flex justify-between"><span>Tax</span><span>{formatBDT(inv.taxAmount)}</span></div>
          <div className="flex justify-between"><span>Discount</span><span>- {formatBDT(inv.discountAmount)}</span></div>
          <div className="flex justify-between border-t-2 border-slate-900 pt-2 text-base font-bold"><span>Total ({inv.currency})</span><span>{formatBDT(inv.total)}</span></div>
          {isInvoice ? (
            <>
              <div className="flex justify-between text-slate-700"><span>Received</span><span>{formatBDT(inv.paidAmount)}</span></div>
              <div className="flex justify-between font-semibold"><span>Balance due</span><span>{formatBDT(inv.dueAmount)}</span></div>
            </>
          ) : null}
          <p className="pt-2 text-xs text-slate-500">Status: {humanize(inv.status)}</p>
        </div>

        {inv.terms ? (
          <section className="mt-10 text-xs text-slate-700">
            <p className="font-semibold text-slate-900">Terms</p>
            <p>{inv.terms}</p>
          </section>
        ) : null}
        {company.invoiceFooter ? <p className="mt-4 whitespace-pre-line text-xs text-slate-600">{company.invoiceFooter}</p> : null}

        <footer className="mt-20 grid grid-cols-2 gap-10 text-xs text-slate-700">
          <div className="border-t border-slate-400 pt-2 text-center">Customer signature</div>
          <div className="border-t border-slate-400 pt-2 text-center">Authorised signature · {company.name}</div>
        </footer>
      </article>
    </div>
  );
}

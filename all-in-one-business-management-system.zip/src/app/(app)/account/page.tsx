import { eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { changeMyPassword, updateMyProfile } from "@/app/actions/auth";
import { ActionForm } from "@/components/action-form";
import { Card, DetailList, Flash, PageHeader } from "@/components/ui";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { GLOBAL_ROLE_LABELS } from "@/lib/constants";
import { firstParam, formatDateTime } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AccountPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sessionUser = await getSessionUser();
  if (!sessionUser) redirect("/login");
  const sp = await searchParams;
  const [user] = await db.select().from(users).where(eq(users.id, sessionUser.id)).limit(1);

  return (
    <>
      <PageHeader
        title="My account"
        description="Keep your details up to date and change your password regularly. Use a password you do not use anywhere else."
      />
      <Flash notice={firstParam(sp.notice) || undefined} error={firstParam(sp.error) || undefined} />

      <div className="grid gap-6 xl:grid-cols-3">
        <Card title="Your details" className="xl:col-span-1">
          <DetailList
            items={[
              { label: "Name", value: user.fullName },
              { label: "Email (sign-in)", value: user.email },
              { label: "Phone", value: user.phone },
              { label: "Top-level role", value: GLOBAL_ROLE_LABELS[user.globalRole] },
              { label: "Last sign-in", value: formatDateTime(user.lastLoginAt) },
            ]}
          />
          <div className="mt-6 border-t border-slate-200 pt-5">
            <ActionForm
              action={updateMyProfile}
              columns={1}
              submitLabel="Save my details"
              fields={[
                { name: "fullName", label: "Full name", required: true, defaultValue: user.fullName },
                { name: "phone", label: "Phone", type: "tel", defaultValue: user.phone ?? "" },
              ]}
            />
          </div>
        </Card>

        <Card title="Change password" description="You will be signed out on other devices after changing it." className="xl:col-span-2">
          <div className="max-w-xl">
            <ActionForm
              action={changeMyPassword}
              columns={1}
              submitLabel="Change password"
              pendingLabel="Changing…"
              fields={[
                { name: "currentPassword", label: "Current password", type: "password", required: true },
                { name: "newPassword", label: "New password", type: "password", required: true, help: "At least 10 characters, with a letter and a number." },
                { name: "confirmPassword", label: "Repeat new password", type: "password", required: true },
              ]}
            />
          </div>
        </Card>
      </div>
    </>
  );
}

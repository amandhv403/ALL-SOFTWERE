import { and, count, eq, gte, inArray, lt, notInArray, sql } from "drizzle-orm";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Flash, PageHeader, Stat, EmptyState, tableClass, thClass, tdClass, cardClass, btnPrimary } from "@/components/ui";
import { db } from "@/db";
import { employees, expenses, invoices, leads, receipts, tasks, visaApplications } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { BUSINESS_TYPE_LABELS, OPEN_LEAD_STATUSES, type BusinessType } from "@/lib/constants";
import { firstParam, formatBDT, formatCount, monthStartISO, todayISO } from "@/lib/format";
import { dbToCents, centsToDb } from "@/lib/money";
import { loadNavCompanies } from "@/lib/permissions";

export const dynamic = "force-dynamic";

type Row = { companyId: number; value: number | string };

function byCompany(rows: Row[]): Map<number, Row> {
  return new Map(rows.map((row) => [row.companyId, row]));
}

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const params = await searchParams;
  const notice = firstParam(params.notice) || undefined;
  const error = firstParam(params.error) || undefined;
  const isAdmin = user.globalRole === "owner" || user.globalRole === "group_admin";

  const companiesList = await loadNavCompanies(user);

  if (companiesList.length === 0) {
    return (
      <>
        <PageHeader title="Owner dashboard" description="A summary of all your companies." />
        <Flash notice={notice} error={error} />
        <EmptyState
          title="No company workspace is set up yet"
          text={
            isAdmin
              ? "Add your business workspaces to get started. You can add all of your current businesses in one click."
              : "Ask the owner to give you access to a company."
          }
        />
        {isAdmin ? (
          <div className="mt-4 text-center">
            <Link href="/companies" className={btnPrimary}>
              Go to companies
            </Link>
          </div>
        ) : null}
      </>
    );
  }

  const ids = companiesList.map((company) => company.id);
  const today = todayISO();
  const monthStart = monthStartISO(today);

  const [openLeadRows, collectionRows, outstandingRows, pendingExpenseRows, openVisaRows, overdueTaskRows, staffRows] =
    await Promise.all([
      db
        .select({ companyId: leads.companyId, value: count() })
        .from(leads)
        .where(and(inArray(leads.companyId, ids), inArray(leads.status, OPEN_LEAD_STATUSES)))
        .groupBy(leads.companyId),
      db
        .select({ companyId: receipts.companyId, value: sql<string>`coalesce(sum(${receipts.amount}), 0)` })
        .from(receipts)
        .where(
          and(
            inArray(receipts.companyId, ids),
            eq(receipts.kind, "payment"),
            eq(receipts.status, "active"),
            gte(receipts.receiptDate, monthStart),
          ),
        )
        .groupBy(receipts.companyId),
      db
        .select({ companyId: invoices.companyId, value: sql<string>`coalesce(sum(${invoices.dueAmount}), 0)` })
        .from(invoices)
        .where(
          and(
            inArray(invoices.companyId, ids),
            eq(invoices.docType, "invoice"),
            inArray(invoices.status, ["issued", "partially_paid"]),
          ),
        )
        .groupBy(invoices.companyId),
      db
        .select({ companyId: expenses.companyId, value: count() })
        .from(expenses)
        .where(and(inArray(expenses.companyId, ids), eq(expenses.status, "pending")))
        .groupBy(expenses.companyId),
      db
        .select({ companyId: visaApplications.companyId, value: count() })
        .from(visaApplications)
        .where(and(inArray(visaApplications.companyId, ids), notInArray(visaApplications.status, ["delivered", "cancelled"])))
        .groupBy(visaApplications.companyId),
      db
        .select({ companyId: tasks.companyId, value: count() })
        .from(tasks)
        .where(
          and(
            inArray(tasks.companyId, ids),
            inArray(tasks.status, ["todo", "in_progress", "waiting"]),
            lt(tasks.dueDate, today),
          ),
        )
        .groupBy(tasks.companyId),
      db
        .select({ companyId: employees.companyId, value: count() })
        .from(employees)
        .where(and(inArray(employees.companyId, ids), notInArray(employees.employmentStatus, ["resigned", "terminated"])))
        .groupBy(employees.companyId),
    ]);

  const openLeadMap = byCompany(openLeadRows);
  const collectionMap = byCompany(collectionRows);
  const outstandingMap = byCompany(outstandingRows);
  const expenseMap = byCompany(pendingExpenseRows);
  const visaMap = byCompany(openVisaRows);
  const taskMap = byCompany(overdueTaskRows);
  const staffMap = byCompany(staffRows);


  const rows = companiesList.map((company) => {
    const collected = dbToCents(collectionMap.get(company.id)?.value);
    const outstanding = dbToCents(outstandingMap.get(company.id)?.value);
    const leadCount = Number(openLeadMap.get(company.id)?.value ?? 0);
    const expenseCount = Number(expenseMap.get(company.id)?.value ?? 0);
    const visaCount = Number(visaMap.get(company.id)?.value ?? 0);
    const taskCount = Number(taskMap.get(company.id)?.value ?? 0);
    const staffCount = Number(staffMap.get(company.id)?.value ?? 0);
    return { company, collected, outstanding, leadCount, expenseCount, visaCount, taskCount, staffCount };
  });

  const totalCollected = rows.reduce((sum, r) => sum + r.collected, 0);
  const totalOutstanding = rows.reduce((sum, r) => sum + r.outstanding, 0);
  const totalLeads = rows.reduce((sum, r) => sum + r.leadCount, 0);
  const totalExpenses = rows.reduce((sum, r) => sum + r.expenseCount, 0);
  const totalVisa = rows.reduce((sum, r) => sum + r.visaCount, 0);
  const totalTasks = rows.reduce((sum, r) => sum + r.taskCount, 0);
  const totalStaff = rows.reduce((sum, r) => sum + r.staffCount, 0);

  return (
    <>
      <PageHeader
        title="Owner dashboard"
        description="A live summary of every company you can access. Numbers update as your team records work."
        actions={
          isAdmin ? (
            <Link href="/companies" className={btnPrimary}>
              Manage companies
            </Link>
          ) : null
        }
      />
      <Flash notice={notice} error={error} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Collected this month" value={formatBDT(centsToDb(totalCollected))} hint="Active payments received" />
        <Stat label="Outstanding invoices" value={formatBDT(centsToDb(totalOutstanding))} hint="Still to be collected" tone="red" />
        <Stat label="Open leads" value={formatCount(totalLeads)} hint="Not yet converted or lost" />
        <Stat label="Expenses awaiting approval" value={formatCount(totalExpenses)} hint="Needs an approver" />
        <Stat label="Open visa files" value={formatCount(totalVisa)} hint="Not yet delivered" />
        <Stat label="Overdue tasks" value={formatCount(totalTasks)} hint="Past their due date" tone="red" />
        <Stat label="Active staff" value={formatCount(totalStaff)} hint="Across all companies" />
      </div>

      <section className={`${cardClass} mt-6 overflow-x-auto`}>
        <div className="border-b border-slate-200 px-5 py-4">
          <h2 className="text-base font-semibold text-slate-900">Company comparison</h2>
          <p className="text-sm text-slate-600">Select a company name to open its workspace.</p>
        </div>
        <table className={tableClass}>
          <thead>
            <tr>
              <th className={thClass}>Company</th>
              <th className={thClass}>Business type</th>
              <th className={thClass}>Collected this month</th>
              <th className={thClass}>Outstanding</th>
              <th className={thClass}>Open leads</th>
              <th className={thClass}>Expenses to approve</th>
              <th className={thClass}>Open visa files</th>
              <th className={thClass}>Overdue tasks</th>
              <th className={thClass}>Active staff</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((row) => (
              <tr key={row.company.id} className="hover:bg-slate-50">
                <td className={tdClass}>
                  <Link href={`/c/${row.company.id}`} className="font-medium text-teal-800 hover:underline">
                    {row.company.name}
                  </Link>
                </td>
                <td className={tdClass}>{BUSINESS_TYPE_LABELS[row.company.businessType as BusinessType] ?? "General business"}</td>
                <td className={tdClass}>{formatBDT(centsToDb(row.collected))}</td>
                <td className={tdClass}>{formatBDT(centsToDb(row.outstanding))}</td>
                <td className={tdClass}>{formatCount(row.leadCount)}</td>
                <td className={tdClass}>{formatCount(row.expenseCount)}</td>
                <td className={tdClass}>{formatCount(row.visaCount)}</td>
                <td className={tdClass}>{formatCount(row.taskCount)}</td>
                <td className={tdClass}>{formatCount(row.staffCount)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
      <p className="mt-3 text-xs text-slate-500">
        Figures only include companies you have access to. Money is shown in Bangladeshi Taka (৳).
      </p>
    </>
  );
}

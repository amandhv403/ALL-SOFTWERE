import { and, count, eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { logoutAction } from "@/app/actions/auth";
import { AppShell } from "@/components/app-shell";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { loadNavCompanies } from "@/lib/permissions";

export const dynamic = "force-dynamic";

// Every page inside this group requires a signed-in user.
export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await getSessionUser();
  if (!user) redirect("/login");

  const [companyList, unread] = await Promise.all([
    loadNavCompanies(user),
    db
      .select({ value: count() })
      .from(notifications)
      .where(and(eq(notifications.userId, user.id), eq(notifications.isRead, false))),
  ]);

  return (
    <AppShell
      user={{ fullName: user.fullName, email: user.email, globalRole: user.globalRole }}
      companies={companyList}
      unreadCount={Number(unread[0]?.value ?? 0)}
      mustChangePassword={user.mustChangePassword}
      logoutAction={logoutAction}
    >
      {children}
    </AppShell>
  );
}

import { asc, eq } from "drizzle-orm";
import Link from "next/link";
import { redirect } from "next/navigation";
import { createCompany, seedPortfolioCompanies, setCompanyActive } from "@/app/actions/admin";
import { ActionForm } from "@/components/action-form";
import { ConfirmSubmit } from "@/components/confirm-submit";
import { Badge, Card, Flash, PageHeader, btnPrimary, btnSecondary, btnSmall, tableClass, tdClass, thClass } from "@/components/ui";
import { db } from "@/db";
import { companies } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { BUSINESS_TYPE_KEYS, BUSINESS_TYPE_LABELS, PORTFOLIO_COMPANIES, optionsOf } from "@/lib/constants";
import { firstParam, formatDate } from "@/lib/format";
import { loadNavCompanies } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export default async function CompaniesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const params = await searchParams;
  const isAdmin = user.globalRole === "owner" || user.globalRole === "group_admin";

  const businessTypeOptions = BUSINESS_TYPE_KEYS.map((key) => ({ value: key, label: BUSINESS_TYPE_LABELS[key] }));

  if (!isAdmin) {
    const mine = await loadNavCompanies(user);
    return (
      <>
        <PageHeader title="Companies" description="The company workspaces you have access to." />
        <Flash notice={firstParam(params.notice) || undefined} error={firstParam(params.error) || undefined} />
        <Card>
          {mine.length === 0 ? (
            <p className="text-sm text-slate-600">You do not have access to any company yet.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {mine.map((company) => (
                <li key={company.id} className="flex items-center justify-between py-3">
                  <div>
                    <p className="font-medium text-slate-900">{company.name}</p>
                    <p className="text-xs text-slate-500">{BUSINESS_TYPE_LABELS[company.businessType as keyof typeof BUSINESS_TYPE_LABELS] ?? "General business"}</p>
                  </div>
                  <Link href={`/c/${company.id}`} className={btnSmall}>
                    Open workspace
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </>
    );
  }

  const rows = await db.select().from(companies).orderBy(asc(companies.name));

  return (
    <>
      <PageHeader
        title="Companies"
        description="Every business workspace. Each company keeps its own customers, invoices, receipts, expenses and staff records separate from the others."
        actions={
          <form action={seedPortfolioCompanies}>
            <button type="submit" className={btnPrimary}>
              Add my {PORTFOLIO_COMPANIES.length} business workspaces
            </button>
          </form>
        }
      />
      <Flash notice={firstParam(params.notice) || undefined} error={firstParam(params.error) || undefined} />

      <Card className="mb-6 overflow-x-auto p-0">
        <table className={tableClass}>
          <thead>
            <tr>
              <th className={thClass}>Company</th>
              <th className={thClass}>Business type</th>
              <th className={thClass}>Modules on</th>
              <th className={thClass}>Created</th>
              <th className={thClass}>Status</th>
              <th className={thClass}>Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.length === 0 ? (
              <tr>
                <td className={tdClass} colSpan={6}>
                  No companies yet. Use the button above to add your business workspaces, or create one below.
                </td>
              </tr>
            ) : null}
            {rows.map((company) => (
              <tr key={company.id}>
                <td className={tdClass}>
                  <p className="font-medium text-slate-900">{company.name}</p>
                  {company.legalName ? <p className="text-xs text-slate-500">{company.legalName}</p> : null}
                </td>
                <td className={tdClass}>{BUSINESS_TYPE_LABELS[company.businessType as keyof typeof BUSINESS_TYPE_LABELS] ?? "General business"}</td>
                <td className={tdClass}>{company.enabledModules.length}</td>
                <td className={tdClass}>{formatDate(company.createdAt)}</td>
                <td className={tdClass}>
                  <Badge tone={company.isActive ? "green" : "red"}>{company.isActive ? "Active" : "Inactive"}</Badge>
                </td>
                <td className={tdClass}>
                  <div className="flex flex-wrap gap-2">
                    <Link href={`/c/${company.id}`} className={btnSmall}>
                      Open
                    </Link>
                    <Link href={`/c/${company.id}/settings`} className={btnSmall}>
                      Settings
                    </Link>
                    <form action={setCompanyActive}>
                      <input type="hidden" name="companyId" value={company.id} />
                      <input type="hidden" name="active" value={company.isActive ? "0" : "1"} />
                      {company.isActive ? (
                        <ConfirmSubmit
                          label="Deactivate"
                          message={`Deactivate ${company.name}? Its data is kept, but staff cannot open it until you reactivate it.`}
                          className={btnSmall}
                        />
                      ) : (
                        <button type="submit" className={btnSmall}>
                          Reactivate
                        </button>
                      )}
                    </form>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Card title="Create a new company" description="Use this for a new business that is not in the list above.">
        <ActionForm
          action={createCompany}
          submitLabel="Create company"
          fields={[
            { name: "name", label: "Company name", required: true, placeholder: "e.g. Dhaka Holiday" },
            { name: "legalName", label: "Legal name (optional)" },
            { name: "businessType", label: "Business type", type: "select", options: businessTypeOptions, defaultValue: "general", required: true },
            { name: "phone", label: "Phone", type: "tel" },
            { name: "email", label: "Email", type: "email" },
            { name: "website", label: "Website" },
            { name: "city", label: "City" },
            { name: "address", label: "Address", type: "textarea", wide: true },
          ]}
        />
      </Card>

      <p className="mt-4 text-xs text-slate-500">
        Business types available: {optionsOf(BUSINESS_TYPE_KEYS).map((o) => o.label).join(", ")}. Options and modules can be
        changed later from each company&apos;s settings.
        {" "}
        <Link href="/dashboard" className={btnSecondary + " !px-2 !py-0.5 !text-xs"}>
          Back to dashboard
        </Link>
      </p>
    </>
  );
}

import { count } from "drizzle-orm";
import { redirect } from "next/navigation";
import { login } from "@/app/actions/auth";
import { ActionForm } from "@/components/action-form";
import { Flash } from "@/components/ui";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { APP_NAME } from "@/lib/constants";
import { firstParam } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const [{ value }] = await db.select({ value: count() }).from(users);
  if (Number(value) === 0) redirect("/setup");
  if (await getSessionUser()) redirect("/dashboard");

  const params = await searchParams;

  return (
    <main className="grid min-h-screen place-items-center bg-gradient-to-br from-teal-50 via-white to-slate-100 px-4 py-12">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-teal-700 text-lg font-bold text-white shadow-lg">
            BM
          </div>
          <h1 className="mt-4 text-2xl font-semibold text-slate-950">{APP_NAME}</h1>
          <p className="mt-1 text-sm text-slate-600">Sign in to manage your companies.</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
          <Flash notice={firstParam(params.notice) || undefined} error={firstParam(params.error) || undefined} />
          <ActionForm
            action={login}
            submitLabel="Sign in"
            pendingLabel="Signing in…"
            columns={1}
            fields={[
              { name: "email", label: "Email address", type: "email", required: true, placeholder: "you@company.com" },
              { name: "password", label: "Password", type: "password", required: true },
            ]}
          />
          <p className="mt-4 text-center text-xs text-slate-500">
            Forgot your password? Ask the owner to reset it from the Users &amp; logins page.
          </p>
        </div>
      </div>
    </main>
  );
}

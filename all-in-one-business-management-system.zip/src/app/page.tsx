import { count } from "drizzle-orm";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [{ value }] = await db.select({ value: count() }).from(users);
  if (Number(value) === 0) redirect("/setup");
  const user = await getSessionUser();
  redirect(user ? "/dashboard" : "/login");
}

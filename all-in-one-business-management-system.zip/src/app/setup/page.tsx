import { count } from "drizzle-orm";
import { redirect } from "next/navigation";
import { createOwnerAccount } from "@/app/actions/auth";
import { ActionForm } from "@/components/action-form";
import { db } from "@/db";
import { users } from "@/db/schema";
import { APP_NAME } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default async function SetupPage() {
  const [{ value }] = await db.select({ value: count() }).from(users);
  if (Number(value) > 0) redirect("/login");

  return (
    <main className="grid min-h-screen place-items-center bg-gradient-to-br from-teal-50 via-white to-slate-100 px-4 py-12">
      <div className="w-full max-w-lg">
        <div className="mb-6 text-center">
          <h1 className="text-2xl font-semibold text-slate-950">Welcome to {APP_NAME}</h1>
          <p className="mt-2 text-sm text-slate-600">
            This is the one-time setup. The account you create now becomes the <strong>Owner (Super Admin)</strong>, with
            full access to all companies. Keep these details safe.
          </p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
          <ActionForm
            action={createOwnerAccount}
            submitLabel="Create owner account"
            pendingLabel="Creating account…"
            columns={1}
            fields={[
              { name: "fullName", label: "Your full name", required: true, placeholder: "e.g. Rahim Uddin" },
              { name: "email", label: "Email address (used to sign in)", type: "email", required: true },
              {
                name: "password",
                label: "Password",
                type: "password",
                required: true,
                help: "At least 10 characters, with at least one letter and one number.",
              },
              { name: "confirmPassword", label: "Repeat password", type: "password", required: true },
            ]}
          />
        </div>
      </div>
    </main>
  );
}

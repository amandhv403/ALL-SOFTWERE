"use server";

// Sign-in, first-time owner setup, sign-out, password and profile changes.
import { and, count, eq, sql } from "drizzle-orm";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/db";
import { notifications, users } from "@/db/schema";
import { logAudit } from "@/lib/audit";
import { AppError, failure, flashUrl, formValues, safeAction, success, zodFieldErrors } from "@/lib/action";
import {
  createSession,
  currentSessionId,
  destroyCurrentSession,
  getSessionUser,
  hashPassword,
  passwordSchema,
  revokeUserSessions,
  verifyPassword,
} from "@/lib/auth";
import type { FormState } from "@/lib/form-state";
import { normalizeEmail } from "@/lib/format";
import { ensureSystemRoles } from "@/lib/permissions";

const MAX_FAILED_ATTEMPTS = 5;
const LOCK_MINUTES = 15;
const GENERIC_LOGIN_ERROR = "The email address or password is not correct.";

export async function login(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const email = normalizeEmail(values.email) ?? "";
  const password = values.password ?? "";

  if (!email || !password) {
    return failure(
      "Please enter your email address and password.",
      { email: values.email ?? "" },
      {
        ...(email ? {} : { email: "Enter your email address." }),
        ...(password ? {} : { password: "Enter your password." }),
      },
    );
  }

  const result = await safeAction(async () => {
    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (!user || !user.isActive) throw new AppError(GENERIC_LOGIN_ERROR);

    if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
      throw new AppError(
        `This account is locked for ${LOCK_MINUTES} minutes after too many failed sign-in attempts. Please try again later.`,
      );
    }

    const valid = await verifyPassword(password, user.passwordHash);
    if (!valid) {
      const failures = user.failedLoginCount + 1;
      const locked = failures >= MAX_FAILED_ATTEMPTS;
      await db
        .update(users)
        .set({
          failedLoginCount: locked ? 0 : failures,
          lockedUntil: locked ? new Date(Date.now() + LOCK_MINUTES * 60_000) : null,
        })
        .where(eq(users.id, user.id));
      throw new AppError(GENERIC_LOGIN_ERROR);
    }

    await db
      .update(users)
      .set({ failedLoginCount: 0, lockedUntil: null, lastLoginAt: new Date() })
      .where(eq(users.id, user.id));
    await createSession(user.id);
    await logAudit({
      userId: user.id,
      action: "auth.sign_in",
      entityType: "user",
      entityId: user.id,
      summary: `${user.fullName} signed in`,
    });
    return user.mustChangePassword;
  });

  if (!result.ok) return failure(result.error, { email });
  redirect(result.data ? "/account" : "/dashboard");
}

export async function logoutAction(): Promise<void> {
  await destroyCurrentSession();
  redirect(flashUrl("/login", "notice", "You have signed out."));
}

const setupSchema = z
  .object({
    fullName: z.string().trim().min(2, "Enter your full name.").max(120, "Name is too long."),
    email: z.email("Enter a valid email address.").max(190, "Email is too long."),
    password: passwordSchema,
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "The passwords do not match.",
    path: ["confirmPassword"],
  });

/** First-time setup. Only works while no user exists yet. The first account becomes the Owner. */
export async function createOwnerAccount(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const parsed = setupSchema.safeParse({
    fullName: values.fullName ?? "",
    email: values.email ?? "",
    password: values.password ?? "",
    confirmPassword: values.confirmPassword ?? "",
  });
  if (!parsed.success) {
    return failure(
      "Please check the highlighted fields.",
      { fullName: values.fullName ?? "", email: values.email ?? "" },
      zodFieldErrors(parsed.error),
    );
  }

  const { fullName, password } = parsed.data;
  const email = parsed.data.email.trim().toLowerCase();

  const result = await safeAction(async () => {
    const passwordHash = await hashPassword(password);
    const userId = await db.transaction(async (tx) => {
      // The advisory lock stops two people from creating the owner account at the same moment.
      await tx.execute(sql`select pg_advisory_xact_lock(90210)`);
      const [{ value }] = await tx.select({ value: count() }).from(users);
      if (Number(value) > 0) throw new AppError("The owner account already exists. Please sign in instead.");
      const [created] = await tx
        .insert(users)
        .values({ fullName, email, passwordHash, globalRole: "owner" })
        .returning({ id: users.id });
      return created.id;
    });
    await ensureSystemRoles();
    await createSession(userId);
    await logAudit({
      userId,
      action: "setup.owner_created",
      entityType: "user",
      entityId: userId,
      summary: `Owner account created for ${email}`,
    });
    return true;
  });

  if (!result.ok) return failure(result.error, { fullName, email });
  redirect("/dashboard");
}

const changePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, "Enter your current password."),
    newPassword: passwordSchema,
    confirmPassword: z.string(),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "The new passwords do not match.",
    path: ["confirmPassword"],
  });

export async function changeMyPassword(_prev: FormState, formData: FormData): Promise<FormState> {
  const user = await getSessionUser();
  if (!user) return failure("Your session has ended. Please sign in again.");

  const values = formValues(formData);
  const parsed = changePasswordSchema.safeParse({
    currentPassword: values.currentPassword ?? "",
    newPassword: values.newPassword ?? "",
    confirmPassword: values.confirmPassword ?? "",
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", {}, zodFieldErrors(parsed.error));

  const result = await safeAction(async () => {
    const [row] = await db.select({ passwordHash: users.passwordHash }).from(users).where(eq(users.id, user.id)).limit(1);
    const valid = row ? await verifyPassword(parsed.data.currentPassword, row.passwordHash) : false;
    if (!valid) {
      throw new AppError("Your current password is not correct.", { currentPassword: "This password is not correct." });
    }
    await db
      .update(users)
      .set({ passwordHash: await hashPassword(parsed.data.newPassword), mustChangePassword: false, updatedAt: new Date() })
      .where(eq(users.id, user.id));
    await revokeUserSessions(user.id, await currentSessionId());
    await logAudit({
      userId: user.id,
      action: "account.password_changed",
      entityType: "user",
      entityId: user.id,
      summary: "Changed own password",
    });
  });

  if (!result.ok) return failure(result.error, {}, result.fieldErrors);
  return success("Your password has been changed. You were signed out on all other devices.");
}

const profileSchema = z.object({
  fullName: z.string().trim().min(2, "Enter your full name.").max(120),
  phone: z.string().trim().max(30).optional(),
});

export async function updateMyProfile(_prev: FormState, formData: FormData): Promise<FormState> {
  const user = await getSessionUser();
  if (!user) return failure("Your session has ended. Please sign in again.");
  const values = formValues(formData);
  const parsed = profileSchema.safeParse({ fullName: values.fullName ?? "", phone: values.phone ?? "" });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));

  const result = await safeAction(async () => {
    await db
      .update(users)
      .set({ fullName: parsed.data.fullName, phone: parsed.data.phone || null, updatedAt: new Date() })
      .where(eq(users.id, user.id));
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  return success("Your profile has been saved.");
}

export async function markAllNotificationsRead(): Promise<void> {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  await db
    .update(notifications)
    .set({ isRead: true })
    .where(and(eq(notifications.userId, user.id), eq(notifications.isRead, false)));
  redirect(flashUrl("/notifications", "notice", "All notifications are marked as read."));
}

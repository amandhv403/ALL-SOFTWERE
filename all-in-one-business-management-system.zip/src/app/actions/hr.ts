"use server";

// Employees, attendance, leave requests and office tasks.
import { and, eq, inArray, lte, gte } from "drizzle-orm";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/db";
import { attendance, companies, employees, leaveRequests, tasks, userCompanyAccess } from "@/db/schema";
import { logAudit, notify, notifyMany } from "@/lib/audit";
import { AppError, failure, flashUrl, formValues, readText, refreshAll, safeAction, success, zodFieldErrors } from "@/lib/action";
import { getSessionUser } from "@/lib/auth";
import {
  ATTENDANCE_STATUS_KEYS,
  EMPLOYMENT_STATUS_KEYS,
  LEAVE_TYPE_KEYS,
  TASK_PRIORITY_KEYS,
  TASK_STATUS_KEYS,
  type AttendanceStatus,
  type EmploymentStatus,
  type LeaveType,
  type TaskPriority,
  type TaskStatus,
} from "@/lib/constants";
import type { FormState } from "@/lib/form-state";
import { daysBetweenISO, parseId } from "@/lib/format";
import { formatDocNumber, nextSequence } from "@/lib/numbering";
import { parseToCents, centsToDb } from "@/lib/money";
import { inBranchScope, requireAccess, usersWithPermission } from "@/lib/permissions";

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const TIME_PATTERN = /^([01]\d|2[0-3]):[0-5]\d$/;
const oneOf = (keys: readonly string[], message: string) => z.string().refine((value) => keys.includes(value), { message });

function minutesOf(time: string): number {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
}

// ---------- Employees ----------
const employeeSchema = z.object({
  fullName: z.string().trim().min(2, "Enter the employee's full name.").max(120),
  phone: z.string().trim().max(40),
  email: z.string().trim().max(190),
  address: z.string().trim().max(400),
  nationalId: z.string().trim().max(40),
  designation: z.string().trim().min(2, "Enter the job title.").max(120),
  employmentStatus: oneOf(EMPLOYMENT_STATUS_KEYS, "Choose an employment status."),
  notes: z.string().trim().max(2000),
});

function parseEmployee(values: Record<string, string>) {
  const parsed = employeeSchema.safeParse({
    fullName: readText(values, "fullName"),
    phone: readText(values, "phone"),
    email: readText(values, "email"),
    address: readText(values, "address"),
    nationalId: readText(values, "nationalId"),
    designation: readText(values, "designation"),
    employmentStatus: readText(values, "employmentStatus") || "active",
    notes: readText(values, "notes"),
  });
  if (!parsed.success) throw new AppError("Please check the highlighted fields.", zodFieldErrors(parsed.error));
  const errors: Record<string, string> = {};
  const joinDate = readText(values, "joinDate");
  if (!DATE_PATTERN.test(joinDate)) errors.joinDate = "Choose the joining date.";
  const dob = readText(values, "dateOfBirth");
  if (dob && !DATE_PATTERN.test(dob)) errors.dateOfBirth = "Use a valid date.";
  const email = parsed.data.email.toLowerCase();
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.email = "Enter a valid email address.";
  if (Object.keys(errors).length > 0) throw new AppError("Please check the highlighted fields.", errors);
  return { ...parsed.data, email: email || null, joinDate, dateOfBirth: dob || null };
}

export async function createEmployee(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "hr", "create");
    const d = parseEmployee(values);
    const salaryAllowed = ctx.can("hr_salary", "edit");
    const salary = salaryAllowed ? parseToCents(readText(values, "basicSalary") || "0") : 0;
    if (salary === null || salary < 0) throw new AppError("Enter the salary as a number.", { basicSalary: "Enter a valid amount." });
    const linkUser = parseId(readText(values, "userId"));
    const departmentId = parseId(readText(values, "departmentId"));
    const branchId = ctx.branchId ?? parseId(readText(values, "branchId"));
    const manager = parseId(readText(values, "reportingManagerId"));

    const employeeId = await db.transaction(async (tx) => {
      const sequence = await nextSequence(tx, companyId, "employee");
      const [created] = await tx
        .insert(employees)
        .values({
          companyId,
          code: formatDocNumber("EMP", sequence, 4),
          userId: linkUser,
          fullName: d.fullName,
          phone: d.phone || null,
          email: d.email,
          address: d.address || null,
          nationalId: d.nationalId || null,
          dateOfBirth: d.dateOfBirth,
          branchId: branchId ?? null,
          departmentId,
          designation: d.designation,
          joinDate: d.joinDate,
          employmentStatus: d.employmentStatus as EmploymentStatus,
          reportingManagerId: manager,
          basicSalary: centsToDb(salary ?? 0),
          notes: d.notes || null,
          createdById: ctx.user.id,
        })
        .returning({ id: employees.id });
      return created.id;
    });
    await logAudit({ companyId, userId: ctx.user.id, action: "employee.created", entityType: "employee", entityId: employeeId, summary: `Employee record created: ${d.fullName}` });
    return employeeId;
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  redirect(`/c/${companyId}/hr/employees/${result.data}`);
}

export async function updateEmployee(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  const employeeId = parseId(values.employeeId);
  if (!companyId || !employeeId) return failure("Employee not found. Please reload the page.");
  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "hr", "edit");
    const [existing] = await db
      .select()
      .from(employees)
      .where(and(eq(employees.id, employeeId), eq(employees.companyId, companyId)))
      .limit(1);
    if (!existing || !inBranchScope(ctx, existing.branchId)) throw new AppError("Employee not found.");
    const d = parseEmployee(values);
    const updates: Partial<typeof employees.$inferInsert> = {
      fullName: d.fullName,
      phone: d.phone || null,
      email: d.email,
      address: d.address || null,
      nationalId: d.nationalId || null,
      dateOfBirth: d.dateOfBirth,
      departmentId: parseId(readText(values, "departmentId")),
      designation: d.designation,
      joinDate: d.joinDate,
      employmentStatus: d.employmentStatus as EmploymentStatus,
      reportingManagerId: parseId(readText(values, "reportingManagerId")),
      notes: d.notes || null,
      updatedAt: new Date(),
    };
    if (ctx.can("hr_salary", "edit")) {
      const salary = parseToCents(readText(values, "basicSalary") || "0");
      if (salary === null || salary < 0) throw new AppError("Enter the salary as a number.", { basicSalary: "Enter a valid amount." });
      updates.basicSalary = centsToDb(salary);
    }
    await db.update(employees).set(updates).where(eq(employees.id, employeeId));
    await logAudit({ companyId, userId: ctx.user.id, action: "employee.updated", entityType: "employee", entityId: employeeId, summary: `Employee record updated: ${d.fullName}` });
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Employee record saved.");
}

// ---------- Attendance ----------
export async function markAttendance(formData: FormData): Promise<void> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) redirect(flashUrl("/dashboard", "error", "Company not found."));
  const date = readText(values, "attendanceDate");
  if (!DATE_PATTERN.test(date)) redirect(flashUrl(`/c/${companyId}/hr/attendance`, "error", "Choose a valid date."));

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "hr", "create");
    const [company] = await db.select().from(companies).where(eq(companies.id, companyId)).limit(1);
    const shiftStart = minutesOf(company?.shiftStart ?? "09:00");
    const shiftEnd = minutesOf(company?.shiftEnd ?? "18:00");
    const grace = company?.graceMinutes ?? 10;

    const ids = readText(values, "employeeIds")
      .split(",")
      .map((item) => parseId(item))
      .filter((item): item is number => item !== null);
    if (ids.length === 0) throw new AppError("There are no active employees to record.");

    const staff = await db
      .select({ id: employees.id, branchId: employees.branchId })
      .from(employees)
      .where(and(eq(employees.companyId, companyId), inArray(employees.id, ids)));

    let saved = 0;
    for (const person of staff) {
      if (!inBranchScope(ctx, person.branchId)) continue;
      const status = readText(values, `status_${person.id}`) || "present";
      if (!(ATTENDANCE_STATUS_KEYS as readonly string[]).includes(status)) continue;
      const checkIn = readText(values, `in_${person.id}`);
      const checkOut = readText(values, `out_${person.id}`);
      if ((checkIn && !TIME_PATTERN.test(checkIn)) || (checkOut && !TIME_PATTERN.test(checkOut))) {
        throw new AppError("Check-in and check-out times must look like 09:05 or 17:30.");
      }
      const late = checkIn && (status === "present" || status === "late" || status === "half_day") ? Math.max(0, minutesOf(checkIn) - (shiftStart + grace)) : 0;
      const early = checkOut ? Math.max(0, shiftEnd - minutesOf(checkOut)) : 0;
      const finalStatus = late > 0 && status === "present" ? "late" : status;
      await db
        .insert(attendance)
        .values({
          companyId,
          employeeId: person.id,
          attendanceDate: date,
          status: finalStatus as AttendanceStatus,
          checkIn: checkIn || null,
          checkOut: checkOut || null,
          lateMinutes: late,
          earlyLeaveMinutes: early,
          notes: readText(values, `note_${person.id}`) || null,
          recordedById: ctx.user.id,
        })
        .onConflictDoUpdate({
          target: [attendance.employeeId, attendance.attendanceDate],
          set: {
            status: finalStatus as AttendanceStatus,
            checkIn: checkIn || null,
            checkOut: checkOut || null,
            lateMinutes: late,
            earlyLeaveMinutes: early,
            notes: readText(values, `note_${person.id}`) || null,
            recordedById: ctx.user.id,
            updatedAt: new Date(),
          },
        });
      saved += 1;
    }
    await logAudit({ companyId, userId: ctx.user.id, action: "attendance.recorded", entityType: "attendance", summary: `Attendance recorded for ${date} (${saved} people)` });
    return saved;
  });
  refreshAll();
  redirect(
    flashUrl(
      `/c/${companyId}/hr/attendance?date=${date}`,
      result.ok ? "notice" : "error",
      result.ok ? `Attendance saved for ${result.data} employee(s) on ${date}.` : result.error,
    ),
  );
}

// ---------- Leave ----------
export async function requestLeave(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const leaveType = readText(values, "leaveType") || "annual";
  const startDate = readText(values, "startDate");
  const endDate = readText(values, "endDate");
  const reason = readText(values, "reason");
  const errors: Record<string, string> = {};
  if (!(LEAVE_TYPE_KEYS as readonly string[]).includes(leaveType)) errors.leaveType = "Choose a leave type.";
  if (!DATE_PATTERN.test(startDate)) errors.startDate = "Choose a start date.";
  if (!DATE_PATTERN.test(endDate)) errors.endDate = "Choose an end date.";
  if (Object.keys(errors).length > 0) return failure("Please check the highlighted fields.", values, errors);
  if (endDate < startDate) return failure("The end date cannot be before the start date.", values, { endDate: "Must be on or after the start date." });

  const result = await safeAction(async () => {
    const user = await getSessionUser();
    if (!user) throw new AppError("Your session has ended. Please sign in again.");
    const employeeId = parseId(readText(values, "employeeId"));
    if (!employeeId) throw new AppError("Choose the employee.", { employeeId: "Choose an employee." });
    const [employee] = await db
      .select({ id: employees.id, userId: employees.userId, fullName: employees.fullName, branchId: employees.branchId })
      .from(employees)
      .where(and(eq(employees.id, employeeId), eq(employees.companyId, companyId)))
      .limit(1);
    if (!employee) throw new AppError("Employee not found.", { employeeId: "Employee not found." });
    const isSelf = employee.userId === user.id;
    const ctx = await requireAccess(companyId, "hr", isSelf ? "view" : "create");
    if (!inBranchScope(ctx, employee.branchId)) throw new AppError("This employee belongs to another branch.");

    const overlapping = await db
      .select({ id: leaveRequests.id })
      .from(leaveRequests)
      .where(
        and(
          eq(leaveRequests.employeeId, employeeId),
          inArray(leaveRequests.status, ["pending", "approved"]),
          lte(leaveRequests.startDate, endDate),
          gte(leaveRequests.endDate, startDate),
        ),
      )
      .limit(1);
    if (overlapping.length > 0) throw new AppError("This person already has leave that overlaps these dates.", { startDate: "Overlaps existing leave." });

    const days = daysBetweenISO(startDate, endDate) + 1;
    const [created] = await db
      .insert(leaveRequests)
      .values({
        companyId,
        employeeId,
        leaveType: leaveType as LeaveType,
        startDate,
        endDate,
        days,
        reason: reason || null,
        status: "pending",
        createdById: user.id,
      })
      .returning({ id: leaveRequests.id });

    const approvers = await usersWithPermission(companyId, "hr", "approve");
    await notifyMany(approvers, {
      companyId,
      title: "Leave request waiting for approval",
      body: `${employee.fullName}: ${days} day(s) from ${startDate}`,
      link: `/c/${companyId}/hr/leave`,
    }, user.id);
    await logAudit({ companyId, userId: user.id, action: "leave.requested", entityType: "leave_request", entityId: created.id, summary: `${employee.fullName} requested ${days} day(s) leave` });
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Leave request sent for approval.");
}

export async function decideLeave(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const leaveId = parseId(String(formData.get("leaveId") ?? ""));
  const decision = String(formData.get("decision") ?? "");
  const note = String(formData.get("note") ?? "").trim().slice(0, 300);
  const result = await safeAction(async () => {
    if (!companyId || !leaveId) throw new AppError("Leave request not found.");
    if (decision !== "approve" && decision !== "reject") throw new AppError("Choose approve or reject.");
    const ctx = await requireAccess(companyId, "hr", decision === "approve" ? "approve" : "reject");
    const [row] = await db
      .select({ leave: leaveRequests, employeeName: employees.fullName, employeeUserId: employees.userId, branchId: employees.branchId })
      .from(leaveRequests)
      .innerJoin(employees, eq(employees.id, leaveRequests.employeeId))
      .where(and(eq(leaveRequests.id, leaveId), eq(leaveRequests.companyId, companyId)))
      .limit(1);
    if (!row) throw new AppError("Leave request not found.");
    if (!inBranchScope(ctx, row.branchId)) throw new AppError("This request belongs to another branch.");
    if (row.leave.status !== "pending") throw new AppError("This request has already been decided.");
    const status = decision === "approve" ? "approved" : "rejected";
    await db
      .update(leaveRequests)
      .set({ status, decidedById: ctx.user.id, decidedAt: new Date(), decisionNote: note || null, updatedAt: new Date() })
      .where(eq(leaveRequests.id, leaveId));
    if (row.employeeUserId) {
      await notify(row.employeeUserId, {
        companyId,
        title: `Leave request ${status}`,
        body: `${row.leave.days} day(s) from ${row.leave.startDate}`,
        link: `/c/${companyId}/hr/leave`,
      });
    }
    await logAudit({ companyId, userId: ctx.user.id, action: `leave.${status}`, entityType: "leave_request", entityId: leaveId, summary: `${row.employeeName}: leave ${status}` });
  });
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/hr/leave`, result.ok ? "notice" : "error", result.ok ? "Decision saved." : result.error));
}

// ---------- Tasks ----------
const taskSchema = z.object({
  title: z.string().trim().min(3, "Describe the task (at least 3 letters).").max(200),
  description: z.string().trim().max(3000),
  priority: oneOf(TASK_PRIORITY_KEYS, "Choose a priority."),
});

export async function createTask(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const parsed = taskSchema.safeParse({
    title: readText(values, "title"),
    description: readText(values, "description"),
    priority: readText(values, "priority") || "medium",
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const dueDate = readText(values, "dueDate");
  if (dueDate && !DATE_PATTERN.test(dueDate)) return failure("Use a valid due date.", values, { dueDate: "Use a valid date." });

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "tasks", "create");
    const requested = parseId(readText(values, "assignedUserId"));
    const assignee = requested && requested !== ctx.user.id ? requested : ctx.user.id;
    if (assignee !== ctx.user.id) {
      if (!ctx.can("tasks", "assign")) throw new AppError("You need permission to assign tasks to other people.", { assignedUserId: "You cannot assign to others." });
      const [member] = await db
        .select({ id: userCompanyAccess.userId })
        .from(userCompanyAccess)
        .where(and(eq(userCompanyAccess.companyId, companyId), eq(userCompanyAccess.userId, assignee), eq(userCompanyAccess.isActive, true)))
        .limit(1);
      if (!member) throw new AppError("That person does not work in this company.", { assignedUserId: "Choose a team member." });
    }
    await db.insert(tasks).values({
      companyId,
      title: parsed.data.title,
      description: parsed.data.description || null,
      priority: parsed.data.priority as TaskPriority,
      status: "todo",
      assignedUserId: assignee,
      dueDate: dueDate || null,
      createdById: ctx.user.id,
    });
    if (assignee !== ctx.user.id) {
      await notify(assignee, { companyId, title: "New task assigned to you", body: parsed.data.title, link: `/c/${companyId}/tasks` });
    }
    await logAudit({ companyId, userId: ctx.user.id, action: "task.created", entityType: "task", summary: `Task created: ${parsed.data.title}` });
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Task added.");
}

export async function updateTaskStatus(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const taskId = parseId(String(formData.get("taskId") ?? ""));
  const status = String(formData.get("status") ?? "");
  const result = await safeAction(async () => {
    if (!companyId || !taskId) throw new AppError("Task not found.");
    if (!(TASK_STATUS_KEYS as readonly string[]).includes(status)) throw new AppError("Choose a valid status.");
    const user = await getSessionUser();
    if (!user) throw new AppError("Your session has ended. Please sign in again.");
    const [task] = await db
      .select()
      .from(tasks)
      .where(and(eq(tasks.id, taskId), eq(tasks.companyId, companyId)))
      .limit(1);
    if (!task) throw new AppError("Task not found.");
    const isMine = task.assignedUserId === user.id;
    const ctx = await requireAccess(companyId, "tasks", isMine ? "view" : "edit");
    await db
      .update(tasks)
      .set({
        status: status as TaskStatus,
        completedAt: status === "done" ? new Date() : null,
        updatedAt: new Date(),
      })
      .where(eq(tasks.id, taskId));
    await logAudit({ companyId, userId: ctx.user.id, action: "task.status", entityType: "task", entityId: taskId, summary: `Task "${task.title}" set to ${status}` });
  });
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/tasks`, result.ok ? "notice" : "error", result.ok ? "Task updated." : result.error));
}


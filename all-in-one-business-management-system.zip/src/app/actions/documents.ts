"use server";

// Secure document upload. Checks the user's permission and that every linked record belongs to the same company.
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { companies, customers, documents, employees, expenses, visaApplications } from "@/db/schema";
import { logAudit } from "@/lib/audit";
import { AppError, failure, formValues, readText, refreshAll, safeAction, success } from "@/lib/action";
import { getSessionUser } from "@/lib/auth";
import {
  DOCUMENT_CATEGORY_KEYS,
  DOCUMENT_MODULE_KEYS,
  type DocumentCategory,
  type DocumentModule,
  type ModuleKey,
} from "@/lib/constants";
import type { FormState } from "@/lib/form-state";
import { parseId } from "@/lib/format";
import { requireAccess } from "@/lib/permissions";
import { saveUpload } from "@/lib/storage";

async function assertLinkedRecords(companyId: number, values: Record<string, string>) {
  const customerId = parseId(values.customerId);
  const visaApplicationId = parseId(values.visaApplicationId);
  const employeeId = parseId(values.employeeId);
  const expenseId = parseId(values.expenseId);

  if (customerId) {
    const [row] = await db
      .select({ id: customers.id })
      .from(customers)
      .where(and(eq(customers.id, customerId), eq(customers.companyId, companyId)))
      .limit(1);
    if (!row) throw new AppError("The linked customer was not found in this company.");
  }
  if (visaApplicationId) {
    const [row] = await db
      .select({ id: visaApplications.id })
      .from(visaApplications)
      .where(and(eq(visaApplications.id, visaApplicationId), eq(visaApplications.companyId, companyId)))
      .limit(1);
    if (!row) throw new AppError("The linked visa file was not found in this company.");
  }
  if (employeeId) {
    const [row] = await db
      .select({ id: employees.id })
      .from(employees)
      .where(and(eq(employees.id, employeeId), eq(employees.companyId, companyId)))
      .limit(1);
    if (!row) throw new AppError("The linked employee was not found in this company.");
  }
  if (expenseId) {
    const [row] = await db
      .select({ id: expenses.id })
      .from(expenses)
      .where(and(eq(expenses.id, expenseId), eq(expenses.companyId, companyId)))
      .limit(1);
    if (!row) throw new AppError("The linked expense was not found in this company.");
  }
  return {
    customerId: customerId ?? null,
    visaApplicationId: visaApplicationId ?? null,
    employeeId: employeeId ?? null,
    expenseId: expenseId ?? null,
  };
}

export async function uploadDocument(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");

  const docModule = values.module as DocumentModule;
  const category = values.category as DocumentCategory;
  if (!(DOCUMENT_MODULE_KEYS as readonly string[]).includes(docModule)) return failure("Choose where this document belongs.", values);
  if (!(DOCUMENT_CATEGORY_KEYS as readonly string[]).includes(category)) return failure("Choose a document type.", values, { category: "Choose a type." });

  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) {
    return failure("Please choose a file to upload.", values, { file: "Choose a PDF, JPG, PNG or WEBP file." });
  }

  const result = await safeAction(async () => {
    const user = await getSessionUser();
    if (!user) throw new AppError("Your session has ended. Please sign in again.");
    const ctx = await requireAccess(companyId, "documents", "create");
    const moduleKey: ModuleKey = docModule === "general" ? "documents" : docModule;
    if (!ctx.can(moduleKey, "view")) {
      throw new AppError("You do not have permission to upload documents to this area.");
    }
    if (category === "logo") {
      requireAccessFlag(ctx.can("company", "edit"));
    }
    const links = await assertLinkedRecords(companyId, values);
    const saved = await saveUpload(file);
    const title = readText(values, "title").slice(0, 150) || saved.fileName;

    const [doc] = await db
      .insert(documents)
      .values({
        companyId,
        module: docModule,
        category,
        title,
        fileName: saved.fileName,
        mimeType: saved.mimeType,
        sizeBytes: saved.sizeBytes,
        storageKey: saved.storageKey,
        isSensitive: category === "passport" || category === "nid",
        uploadedById: user.id,
        ...links,
      })
      .returning({ id: documents.id });

    if (category === "logo") {
      await db.update(companies).set({ logoDocumentId: doc.id, updatedAt: new Date() }).where(eq(companies.id, companyId));
    }
    await logAudit({
      companyId,
      userId: user.id,
      action: "document.uploaded",
      entityType: "document",
      entityId: doc.id,
      summary: `${category} uploaded: ${title}`,
    });
    return doc.id;
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("File uploaded securely. Only people with permission can open it.");
}

function requireAccessFlag(allowed: boolean): void {
  if (!allowed) throw new AppError("You need company settings permission to change the logo.");
}

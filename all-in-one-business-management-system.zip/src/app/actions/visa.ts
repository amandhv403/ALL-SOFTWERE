"use server";

// Visa files: creating applications, status changes with history, checklist verification and document links.
import { and, eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/db";
import { activities, customers, visaApplications, visaChecklistItems, visaStatusHistory } from "@/db/schema";
import { logAudit, notify } from "@/lib/audit";
import { AppError, failure, flashUrl, formValues, readText, refreshAll, safeAction, success, zodFieldErrors } from "@/lib/action";
import { DEFAULT_VISA_CHECKLIST, VISA_STATUS_KEYS, humanize, type VisaStatus } from "@/lib/constants";
import type { FormState } from "@/lib/form-state";
import { parseId } from "@/lib/format";
import { formatDocNumber, nextSequence } from "@/lib/numbering";
import { inBranchScope, requireAccess } from "@/lib/permissions";
import { parseToCents, centsToDb } from "@/lib/money";

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const DATETIME_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/;

function dateField(value: string, key: string, errors: Record<string, string>): string | null {
  if (!value) return null;
  if (!DATE_PATTERN.test(value)) {
    errors[key] = "Use a valid date.";
    return null;
  }
  return value;
}

function dateTimeField(value: string, key: string, errors: Record<string, string>): Date | null {
  if (!value) return null;
  if (!DATETIME_PATTERN.test(value)) {
    errors[key] = "Use a valid date and time.";
    return null;
  }
  return new Date(`${value}:00+06:00`);
}

const visaSchema = z.object({
  customerId: z.string().min(1, "Choose the customer."),
  destinationCountry: z.string().trim().min(2, "Enter the destination country.").max(100),
  visaCategory: z.string().trim().min(2, "Choose or enter the visa category.").max(100),
  travelPurpose: z.string().trim().max(200),
  embassy: z.string().trim().max(150),
  notes: z.string().trim().max(3000),
  serviceFee: z.string().trim(),
});

export async function createVisaApplication(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const parsed = visaSchema.safeParse({
    customerId: readText(values, "customerId"),
    destinationCountry: readText(values, "destinationCountry"),
    visaCategory: readText(values, "visaCategory"),
    travelPurpose: readText(values, "travelPurpose"),
    embassy: readText(values, "embassy"),
    notes: readText(values, "notes"),
    serviceFee: readText(values, "serviceFee") || "0",
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const d = parsed.data;

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "visa", "create");
    const customerId = parseId(d.customerId);
    if (!customerId) throw new AppError("Choose the customer.", { customerId: "Choose the customer." });
    const [customer] = await db
      .select({ id: customers.id, fullName: customers.fullName, branchId: customers.branchId, isArchived: customers.isArchived })
      .from(customers)
      .where(and(eq(customers.id, customerId), eq(customers.companyId, companyId)))
      .limit(1);
    if (!customer || customer.isArchived || !inBranchScope(ctx, customer.branchId)) {
      throw new AppError("This customer was not found. Please register the customer first.", { customerId: "Customer not found." });
    }

    const errors: Record<string, string> = {};
    const travelDate = dateField(readText(values, "travelDate"), "travelDate", errors);
    const returnDate = dateField(readText(values, "returnDate"), "returnDate", errors);
    const applicationDate = dateField(readText(values, "applicationDate"), "applicationDate", errors) ?? new Date().toISOString().slice(0, 10);
    const submissionDate = dateField(readText(values, "submissionDate"), "submissionDate", errors);
    const appointmentAt = dateTimeField(readText(values, "appointmentAt"), "appointmentAt", errors);
    const fee = parseToCents(d.serviceFee);
    if (fee === null || fee < 0) errors.serviceFee = "Enter an amount such as 5000.";
    const status = (readText(values, "status") || "new") as VisaStatus;
    if (!(VISA_STATUS_KEYS as readonly string[]).includes(status)) errors.status = "Choose a valid status.";
    if (Object.keys(errors).length > 0) throw new AppError("Please check the highlighted fields.", errors);

    const assignee = parseId(readText(values, "assignedUserId")) ?? ctx.user.id;
    const branchId = ctx.branchId ?? customer.branchId;

    const applicationId = await db.transaction(async (tx) => {
      const sequence = await nextSequence(tx, companyId, "visa");
      const code = formatDocNumber(ctx.company.visaPrefix, sequence);
      const [created] = await tx
        .insert(visaApplications)
        .values({
          companyId,
          branchId,
          customerId,
          code,
          destinationCountry: d.destinationCountry,
          visaCategory: d.visaCategory,
          travelPurpose: d.travelPurpose || null,
          travelDate,
          returnDate,
          embassy: d.embassy || null,
          applicationDate,
          submissionDate,
          appointmentAt,
          status,
          assignedUserId: assignee,
          serviceFee: centsToDb(fee ?? 0),
          notes: d.notes || null,
          createdById: ctx.user.id,
          updatedById: ctx.user.id,
        })
        .returning({ id: visaApplications.id });
      await tx.insert(visaChecklistItems).values(
        DEFAULT_VISA_CHECKLIST.map((label, index) => ({ visaApplicationId: created.id, label, sortOrder: index })),
      );
      await tx.insert(visaStatusHistory).values({ visaApplicationId: created.id, fromStatus: null, toStatus: status, note: "File opened", changedById: ctx.user.id });
      await tx.insert(activities).values({
        companyId,
        customerId,
        visaApplicationId: created.id,
        type: "system",
        summary: `Visa file ${code} opened for ${d.destinationCountry} (${d.visaCategory})`,
        createdById: ctx.user.id,
      });
      return created.id;
    });

    if (assignee !== ctx.user.id) {
      await notify(assignee, {
        companyId,
        title: "New visa file assigned to you",
        body: `${customer.fullName} · ${d.destinationCountry}`,
        link: `/c/${companyId}/visa/applications/${applicationId}`,
      });
    }
    await logAudit({ companyId, userId: ctx.user.id, action: "visa.created", entityType: "visa_application", entityId: applicationId, summary: `Visa file opened for ${customer.fullName}` });
    return applicationId;
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  redirect(`/c/${companyId}/visa/applications/${result.data}`);
}

const statusSchema = z.object({
  status: z.string().refine((value) => (VISA_STATUS_KEYS as readonly string[]).includes(value), { message: "Choose a valid status." }),
  note: z.string().trim().max(1000),
});

export async function changeVisaStatus(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  const applicationId = parseId(values.applicationId);
  if (!companyId || !applicationId) return failure("Visa file not found. Please reload the page.");
  const parsed = statusSchema.safeParse({ status: readText(values, "status"), note: readText(values, "note") });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "visa", "edit");
    const [app] = await db
      .select()
      .from(visaApplications)
      .where(and(eq(visaApplications.id, applicationId), eq(visaApplications.companyId, companyId)))
      .limit(1);
    if (!app || !inBranchScope(ctx, app.branchId)) throw new AppError("Visa file not found.");

    const errors: Record<string, string> = {};
    const newStatus = parsed.data.status as VisaStatus;
    const refusalReason = readText(values, "refusalReason");
    if (newStatus === "refused" && !refusalReason) errors.refusalReason = "Write the reason given by the embassy.";
    const approvalDate = dateField(readText(values, "approvalDate"), "approvalDate", errors);
    const validFrom = dateField(readText(values, "validFrom"), "validFrom", errors);
    const validUntil = dateField(readText(values, "validUntil"), "validUntil", errors);
    const submissionDate = dateField(readText(values, "submissionDate"), "submissionDate", errors);
    const appointmentAt = dateTimeField(readText(values, "appointmentAt"), "appointmentAt", errors);
    if (Object.keys(errors).length > 0) throw new AppError("Please check the highlighted fields.", errors);

    const changed = newStatus !== app.status;
    await db
      .update(visaApplications)
      .set({
        status: newStatus,
        statusNote: parsed.data.note || null,
        refusalReason: newStatus === "refused" ? refusalReason : app.refusalReason,
        approvalDate: approvalDate ?? app.approvalDate,
        validFrom: validFrom ?? app.validFrom,
        validUntil: validUntil ?? app.validUntil,
        submissionDate: submissionDate ?? app.submissionDate,
        appointmentAt: appointmentAt ?? app.appointmentAt,
        passportDeliveredAt: newStatus === "delivered" ? new Date() : app.passportDeliveredAt,
        updatedById: ctx.user.id,
        updatedAt: new Date(),
      })
      .where(eq(visaApplications.id, applicationId));

    if (changed) {
      await db.insert(visaStatusHistory).values({
        visaApplicationId: applicationId,
        fromStatus: app.status,
        toStatus: newStatus,
        note: parsed.data.note || null,
        changedById: ctx.user.id,
      });
      await db.insert(activities).values({
        companyId,
        customerId: app.customerId,
        visaApplicationId: applicationId,
        type: "status_change",
        summary: `${app.code}: ${humanize(app.status)} → ${humanize(newStatus)}`,
        details: parsed.data.note || null,
        createdById: ctx.user.id,
      });
      if (app.assignedUserId && app.assignedUserId !== ctx.user.id) {
        await notify(app.assignedUserId, {
          companyId,
          title: `Visa status changed: ${humanize(newStatus)}`,
          body: `${app.code} · ${app.destinationCountry}`,
          link: `/c/${companyId}/visa/applications/${applicationId}`,
        });
      }
    }
    await logAudit({ companyId, userId: ctx.user.id, action: "visa.status_changed", entityType: "visa_application", entityId: applicationId, summary: `${app.code} status set to ${humanize(newStatus)}` });
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Visa status updated and recorded in the history.");
}

export async function updateVisaDetails(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  const applicationId = parseId(values.applicationId);
  if (!companyId || !applicationId) return failure("Visa file not found. Please reload the page.");
  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "visa", "edit");
    const [app] = await db
      .select()
      .from(visaApplications)
      .where(and(eq(visaApplications.id, applicationId), eq(visaApplications.companyId, companyId)))
      .limit(1);
    if (!app || !inBranchScope(ctx, app.branchId)) throw new AppError("Visa file not found.");
    const errors: Record<string, string> = {};
    const destination = readText(values, "destinationCountry");
    const category = readText(values, "visaCategory");
    if (destination.length < 2) errors.destinationCountry = "Enter the destination country.";
    if (category.length < 2) errors.visaCategory = "Enter the visa category.";
    const travelDate = dateField(readText(values, "travelDate"), "travelDate", errors);
    const returnDate = dateField(readText(values, "returnDate"), "returnDate", errors);
    const appointmentAt = dateTimeField(readText(values, "appointmentAt"), "appointmentAt", errors);
    const fee = parseToCents(readText(values, "serviceFee") || "0");
    if (fee === null || fee < 0) errors.serviceFee = "Enter an amount such as 5000.";
    if (Object.keys(errors).length > 0) throw new AppError("Please check the highlighted fields.", errors);
    const assignee = parseId(readText(values, "assignedUserId"));
    await db
      .update(visaApplications)
      .set({
        destinationCountry: destination,
        visaCategory: category,
        travelPurpose: readText(values, "travelPurpose") || null,
        travelDate,
        returnDate,
        embassy: readText(values, "embassy") || null,
        appointmentAt,
        serviceFee: centsToDb(fee ?? 0),
        assignedUserId: assignee,
        notes: readText(values, "notes") || null,
        updatedById: ctx.user.id,
        updatedAt: new Date(),
      })
      .where(eq(visaApplications.id, applicationId));
    await logAudit({ companyId, userId: ctx.user.id, action: "visa.updated", entityType: "visa_application", entityId: applicationId, summary: `${app.code} details updated` });
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Visa file details saved.");
}

export async function setChecklistItem(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const applicationId = parseId(String(formData.get("applicationId") ?? ""));
  const itemId = parseId(String(formData.get("itemId") ?? ""));
  const next = String(formData.get("status") ?? "pending");
  const back = `/c/${companyId}/visa/applications/${applicationId}`;
  const result = await safeAction(async () => {
    if (!companyId || !applicationId || !itemId) throw new AppError("Checklist item not found.");
    if (next !== "pending" && next !== "received" && next !== "verified") throw new AppError("Choose a valid checklist status.");
    const ctx = await requireAccess(companyId, "visa", "edit");
    if (next === "verified") requireVerifyRight(ctx.can("documents", "verify"));
    const [item] = await db
      .select({ id: visaChecklistItems.id, appId: visaChecklistItems.visaApplicationId, label: visaChecklistItems.label, branchId: visaApplications.branchId })
      .from(visaChecklistItems)
      .innerJoin(visaApplications, eq(visaApplications.id, visaChecklistItems.visaApplicationId))
      .where(and(eq(visaChecklistItems.id, itemId), eq(visaApplications.companyId, companyId), eq(visaApplications.id, applicationId)))
      .limit(1);
    if (!item || !inBranchScope(ctx, item.branchId)) throw new AppError("Checklist item not found.");
    await db
      .update(visaChecklistItems)
      .set({
        status: next,
        verifiedById: next === "verified" ? ctx.user.id : null,
        verifiedAt: next === "verified" ? new Date() : null,
      })
      .where(eq(visaChecklistItems.id, itemId));
    await logAudit({ companyId, userId: ctx.user.id, action: "visa.checklist", entityType: "visa_checklist_item", entityId: itemId, summary: `"${item.label}" marked ${next}` });
  });
  refreshAll();
  redirect(flashUrl(back, result.ok ? "notice" : "error", result.ok ? "Checklist updated." : result.error));
}

function requireVerifyRight(allowed: boolean): void {
  if (!allowed) throw new AppError("Only a person allowed to verify documents can mark an item as verified.");
}


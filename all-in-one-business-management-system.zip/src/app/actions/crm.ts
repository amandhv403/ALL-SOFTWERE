"use server";

// Leads, customers, follow-ups, notes and lead conversion. Every action checks permissions and company ownership.
import { and, eq, inArray, or, type SQL } from "drizzle-orm";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/db";
import { activities, branches, campaigns, customers, followUps, leads, userCompanyAccess, users } from "@/db/schema";
import { logAudit, notify } from "@/lib/audit";
import {
  AppError,
  failure,
  flashUrl,
  formValues,
  readFlag,
  readText,
  refreshAll,
  safeAction,
  success,
  zodFieldErrors,
} from "@/lib/action";
import { getSessionUser } from "@/lib/auth";
import {
  ACTIVITY_TYPE_KEYS,
  CUSTOMER_CATEGORY_KEYS,
  LEAD_SOURCE_KEYS,
  LEAD_STATUS_KEYS,
  humanize,
  type ActivityType,
  type LeadStatus,
} from "@/lib/constants";
import type { FormState } from "@/lib/form-state";
import { normalizeEmail, parseId } from "@/lib/format";
import { formatDocNumber, nextSequence } from "@/lib/numbering";
import { inBranchScope, requireAccess, type AccessContext } from "@/lib/permissions";
import { parseToCents, centsToDb } from "@/lib/money";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

const oneOf = (keys: readonly string[], message: string) => z.string().refine((value) => keys.includes(value), { message });

/** Bangladeshi numbers are stored in one standard form (01XXXXXXXXX) so duplicates are found reliably. */
function canonicalPhone(value: string): string | null {
  const digits = value.replace(/\D/g, "");
  if (digits.length < 6) return null;
  if (digits.startsWith("880")) return `0${digits.slice(3)}`;
  return digits;
}

function optionalDate(value: string, key: string, errors: Record<string, string>): string | null {
  if (!value) return null;
  if (!DATE_PATTERN.test(value)) {
    errors[key] = "Use a valid date.";
    return null;
  }
  return value;
}

async function validAssignee(companyId: number, raw: string): Promise<number | null> {
  const id = parseId(raw);
  if (!id) return null;
  const [member] = await db
    .select({ id: userCompanyAccess.userId })
    .from(userCompanyAccess)
    .where(
      and(
        eq(userCompanyAccess.companyId, companyId),
        eq(userCompanyAccess.userId, id),
        eq(userCompanyAccess.isActive, true),
      ),
    )
    .limit(1);
  if (member) return id;
  const [admin] = await db
    .select({ id: users.id })
    .from(users)
    .where(and(eq(users.id, id), inArray(users.globalRole, ["owner", "group_admin"])))
    .limit(1);
  if (admin) return id;
  throw new AppError("The selected person does not work in this company.", {
    assignedUserId: "Choose someone who works in this company.",
  });
}

async function validBranch(companyId: number, ctx: AccessContext, raw: string): Promise<number | null> {
  if (ctx.branchId) return ctx.branchId;
  const id = parseId(raw);
  if (!id) return null;
  const [row] = await db
    .select({ id: branches.id })
    .from(branches)
    .where(and(eq(branches.id, id), eq(branches.companyId, companyId)))
    .limit(1);
  if (!row) throw new AppError("The branch does not belong to this company.", { branchId: "Choose a branch of this company." });
  return row.id;
}

async function validCampaign(companyId: number, raw: string): Promise<number | null> {
  const id = parseId(raw);
  if (!id) return null;
  const [row] = await db
    .select({ id: campaigns.id })
    .from(campaigns)
    .where(and(eq(campaigns.id, id), eq(campaigns.companyId, companyId)))
    .limit(1);
  if (!row) throw new AppError("The campaign does not belong to this company.", { campaignId: "Choose a campaign from this company." });
  return row.id;
}

async function findDuplicates(companyId: number, phone: string | null, email: string | null): Promise<string[]> {
  const found: string[] = [];
  if (!phone && !email) return found;
  const customerConditions = [phone ? eq(customers.phone, phone) : undefined, email ? eq(customers.email, email) : undefined].filter(
    (c): c is SQL => c !== undefined,
  );
  const leadConditions = [phone ? eq(leads.phone, phone) : undefined, email ? eq(leads.email, email) : undefined].filter(
    (c): c is SQL => c !== undefined,
  );
  const matchedCustomers = await db
    .select({ code: customers.code, fullName: customers.fullName })
    .from(customers)
    .where(and(eq(customers.companyId, companyId), or(...customerConditions)))
    .limit(3);
  for (const row of matchedCustomers) found.push(`customer ${row.code} (${row.fullName})`);
  const matchedLeads = await db
    .select({ code: leads.code, fullName: leads.fullName })
    .from(leads)
    .where(and(eq(leads.companyId, companyId), or(...leadConditions)))
    .limit(3);
  for (const row of matchedLeads) found.push(`lead ${row.code} (${row.fullName})`);
  return found;
}

// ---------- Leads ----------
const leadSchema = z.object({
  fullName: z.string().trim().min(2, "Enter the person's name.").max(150, "Name is too long."),
  phone: z.string().trim().max(30),
  email: z.string().trim().max(190),
  city: z.string().trim().max(100),
  leadSource: oneOf(LEAD_SOURCE_KEYS, "Choose where the lead came from."),
  interestedService: z.string().trim().max(150),
  notes: z.string().trim().max(2000),
  expectedValue: z.string().trim(),
});

export async function createLead(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");

  const parsed = leadSchema.safeParse({
    fullName: readText(values, "fullName"),
    phone: readText(values, "phone"),
    email: readText(values, "email"),
    city: readText(values, "city"),
    leadSource: readText(values, "leadSource") || "other",
    interestedService: readText(values, "interestedService"),
    notes: readText(values, "notes"),
    expectedValue: readText(values, "expectedValue") || "0",
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const d = parsed.data;

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "crm", "create");
    const phone = d.phone ? canonicalPhone(d.phone) : null;
    const email = normalizeEmail(d.email);
    const fieldErrors: Record<string, string> = {};
    if (d.phone && !phone) fieldErrors.phone = "Enter a valid phone number.";
    if (email && !EMAIL_PATTERN.test(email)) fieldErrors.email = "Enter a valid email address.";
    const expected = parseToCents(d.expectedValue);
    if (expected === null || expected < 0) fieldErrors.expectedValue = "Enter an amount such as 5000 or 5000.50.";
    if (Object.keys(fieldErrors).length > 0) throw new AppError("Please check the highlighted fields.", fieldErrors);

    const duplicates = await findDuplicates(companyId, phone, email);
    if (duplicates.length > 0 && !readFlag(values, "allowDuplicate")) {
      throw new AppError(
        `A similar record already exists: ${duplicates.join("; ")}. Open that record, or tick "Save even if a similar record already exists".`,
        { phone: "Possible duplicate." },
      );
    }

    const assigneeId = values.assignedUserId ? await validAssignee(companyId, values.assignedUserId) : null;
    const branchId = await validBranch(companyId, ctx, values.branchId ?? "");
    const campaignId = await validCampaign(companyId, values.campaignId ?? "");
    const assignedTo = assigneeId ?? ctx.user.id;

    const leadId = await db.transaction(async (tx) => {
      const sequence = await nextSequence(tx, companyId, "lead");
      const [created] = await tx
        .insert(leads)
        .values({
          companyId,
          code: formatDocNumber("LD", sequence),
          fullName: d.fullName,
          phone,
          email,
          city: d.city || null,
          leadSource: d.leadSource as (typeof LEAD_SOURCE_KEYS)[number],
          interestedService: d.interestedService || null,
          campaignId,
          status: "new",
          expectedValue: centsToDb(expected ?? 0),
          branchId,
          assignedUserId: assignedTo,
          notes: d.notes || null,
          createdById: ctx.user.id,
          updatedById: ctx.user.id,
        })
        .returning({ id: leads.id, code: leads.code });
      await tx.insert(activities).values({
        companyId,
        leadId: created.id,
        type: "system",
        summary: `Lead ${created.code} created from ${humanize(d.leadSource)}`,
        createdById: ctx.user.id,
      });
      return created.id;
    });

    await notify(assignedTo, {
      companyId,
      title: "New lead assigned to you",
      body: `${d.fullName}${d.interestedService ? ` · ${d.interestedService}` : ""}`,
      link: `/c/${companyId}/crm/leads/${leadId}`,
    });
    await logAudit({ companyId, userId: ctx.user.id, action: "lead.created", entityType: "lead", entityId: leadId, summary: `Lead created: ${d.fullName}` });
    return leadId;
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  redirect(`/c/${companyId}/crm/leads/${result.data}`);
}

export async function setLeadStatus(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const leadId = parseId(String(formData.get("leadId") ?? ""));
  const status = String(formData.get("status") ?? "");
  const reason = String(formData.get("reason") ?? "").trim().slice(0, 300);
  const note = String(formData.get("note") ?? "").trim().slice(0, 1000);
  const result = await safeAction(async () => {
    if (!companyId || !leadId) throw new AppError("Lead not found.");
    const ctx = await requireAccess(companyId, "crm", "edit");
    if (!(LEAD_STATUS_KEYS as readonly string[]).includes(status)) throw new AppError("Choose a valid status.");
    if (status === "converted") throw new AppError("Use the Convert to customer button to convert a lead.");
    const [lead] = await db.select().from(leads).where(and(eq(leads.id, leadId), eq(leads.companyId, companyId))).limit(1);
    if (!lead) throw new AppError("Lead not found.");
    if (!inBranchScope(ctx, lead.branchId)) throw new AppError("This lead belongs to another branch.");
    if (lead.status === "converted") throw new AppError("A converted lead cannot change status here.");
    if ((status === "lost" || status === "not_interested") && !reason) {
      throw new AppError("Please write a short reason, so the team can learn from this lead.");
    }
    await db
      .update(leads)
      .set({
        status: status as LeadStatus,
        lostReason: status === "lost" || status === "not_interested" ? reason : null,
        updatedById: ctx.user.id,
        updatedAt: new Date(),
      })
      .where(eq(leads.id, leadId));
    await db.insert(activities).values({
      companyId,
      leadId,
      type: "status_change",
      summary: `Status changed to ${humanize(status)}${reason ? `: ${reason}` : ""}`,
      details: note || null,
      createdById: ctx.user.id,
    });
  });
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/crm/leads/${leadId}`, result.ok ? "notice" : "error", result.ok ? "Status updated." : result.error));
}

export async function assignLead(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const leadId = parseId(String(formData.get("leadId") ?? ""));
  const assigneeRaw = String(formData.get("assignedUserId") ?? "");
  const result = await safeAction(async () => {
    if (!companyId || !leadId) throw new AppError("Lead not found.");
    const ctx = await requireAccess(companyId, "crm", "assign");
    const assigneeId = assigneeRaw ? await validAssignee(companyId, assigneeRaw) : null;
    if (assigneeRaw && !assigneeId) throw new AppError("Choose a valid person.");
    const [lead] = await db.select().from(leads).where(and(eq(leads.id, leadId), eq(leads.companyId, companyId))).limit(1);
    if (!lead) throw new AppError("Lead not found.");
    if (!inBranchScope(ctx, lead.branchId)) throw new AppError("This lead belongs to another branch.");
    await db.update(leads).set({ assignedUserId: assigneeId, updatedAt: new Date(), updatedById: ctx.user.id }).where(eq(leads.id, leadId));
    if (assigneeId && assigneeId !== ctx.user.id) {
      await notify(assigneeId, {
        companyId,
        title: "A lead was assigned to you",
        body: lead.fullName,
        link: `/c/${companyId}/crm/leads/${leadId}`,
      });
    }
    await db.insert(activities).values({
      companyId,
      leadId,
      type: "system",
      summary: assigneeId ? "Lead assigned to a team member" : "Lead assignment removed",
      createdById: ctx.user.id,
    });
  });
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/crm/leads/${leadId}`, result.ok ? "notice" : "error", result.ok ? "Lead assigned." : result.error));
}

export async function convertLead(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const leadId = parseId(String(formData.get("leadId") ?? ""));
  if (!companyId || !leadId) redirect(flashUrl("/dashboard", "error", "Lead not found."));

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "crm", "create");
    const [lead] = await db.select().from(leads).where(and(eq(leads.id, leadId), eq(leads.companyId, companyId))).limit(1);
    if (!lead) throw new AppError("Lead not found.");
    if (!inBranchScope(ctx, lead.branchId)) throw new AppError("This lead belongs to another branch.");
    if (lead.status === "converted" && lead.customerId) throw new AppError("This lead has already been converted.");

    const phone = lead.phone ? canonicalPhone(lead.phone) : null;
    const email = normalizeEmail(lead.email);
    const existingConditions = [phone ? eq(customers.phone, phone) : undefined, email ? eq(customers.email, email) : undefined].filter(
      (c): c is SQL => c !== undefined,
    );
    const [existing] =
      existingConditions.length > 0
        ? await db
            .select({ id: customers.id })
            .from(customers)
            .where(and(eq(customers.companyId, companyId), or(...existingConditions)))
            .limit(1)
        : [];

    const customerId = await db.transaction(async (tx) => {
      if (existing) return existing.id;
      const sequence = await nextSequence(tx, companyId, "customer");
      const [created] = await tx
        .insert(customers)
        .values({
          companyId,
          code: formatDocNumber("CUS", sequence),
          fullName: lead.fullName,
          phone,
          email,
          city: lead.city,
          leadSource: lead.leadSource,
          interestedService: lead.interestedService,
          branchId: lead.branchId,
          assignedUserId: lead.assignedUserId,
          notes: lead.notes,
          category: "individual",
          createdById: ctx.user.id,
          updatedById: ctx.user.id,
        })
        .returning({ id: customers.id });
      return created.id;
    });

    const now = new Date();
    await db
      .update(leads)
      .set({ status: "converted", customerId, convertedAt: now, updatedAt: now, updatedById: ctx.user.id })
      .where(eq(leads.id, leadId));
    await db.insert(activities).values([
      {
        companyId,
        leadId,
        customerId,
        type: "status_change",
        summary: existing ? "Lead linked to an existing customer" : "Lead converted into a customer",
        createdById: ctx.user.id,
      },
      {
        companyId,
        customerId,
        type: "system",
        summary: existing ? "Existing record matched by phone or email" : "Customer created from a converted lead",
        createdById: ctx.user.id,
      },
    ]);
    await logAudit({ companyId, userId: ctx.user.id, action: "lead.converted", entityType: "lead", entityId: leadId, summary: `Lead converted to customer ${customerId}` });
    return customerId;
  });

  refreshAll();
  if (!result.ok) redirect(flashUrl(`/c/${companyId}/crm/leads/${leadId}`, "error", result.error));
  redirect(flashUrl(`/c/${companyId}/crm/customers/${result.data}`, "notice", "Lead converted. The customer record is ready."));
}

// ---------- Customers ----------
const customerSchema = z.object({
  fullName: z.string().trim().min(2, "Enter the customer's full name.").max(150),
  phone: z.string().trim().max(30),
  altPhone: z.string().trim().max(30),
  email: z.string().trim().max(190),
  address: z.string().trim().max(400),
  city: z.string().trim().max(100),
  country: z.string().trim().max(100),
  nationality: z.string().trim().max(100),
  occupation: z.string().trim().max(120),
  category: oneOf(CUSTOMER_CATEGORY_KEYS, "Choose a category."),
  interestedService: z.string().trim().max(150),
  passportNumber: z.string().trim().max(30),
  notes: z.string().trim().max(3000),
});

function parseCustomer(values: Record<string, string>) {
  const base = customerSchema.safeParse({
    fullName: readText(values, "fullName"),
    phone: readText(values, "phone"),
    altPhone: readText(values, "altPhone"),
    email: readText(values, "email"),
    address: readText(values, "address"),
    city: readText(values, "city"),
    country: readText(values, "country"),
    nationality: readText(values, "nationality"),
    occupation: readText(values, "occupation"),
    category: readText(values, "category") || "individual",
    interestedService: readText(values, "interestedService"),
    passportNumber: readText(values, "passportNumber").toUpperCase(),
    notes: readText(values, "notes"),
  });
  if (!base.success) throw new AppError("Please check the highlighted fields.", zodFieldErrors(base.error));
  const errors: Record<string, string> = {};
  const phone = base.data.phone ? canonicalPhone(base.data.phone) : null;
  const altPhone = base.data.altPhone ? canonicalPhone(base.data.altPhone) : null;
  const email = normalizeEmail(base.data.email);
  if (base.data.phone && !phone) errors.phone = "Enter a valid phone number.";
  if (base.data.altPhone && !altPhone) errors.altPhone = "Enter a valid phone number.";
  if (email && !EMAIL_PATTERN.test(email)) errors.email = "Enter a valid email address.";
  const dateOfBirth = optionalDate(readText(values, "dateOfBirth"), "dateOfBirth", errors);
  const passportExpiry = optionalDate(readText(values, "passportExpiry"), "passportExpiry", errors);
  if (Object.keys(errors).length > 0) throw new AppError("Please check the highlighted fields.", errors);
  return {
    ...base.data,
    phone,
    altPhone,
    email,
    dateOfBirth,
    passportExpiry,
    category: base.data.category as (typeof CUSTOMER_CATEGORY_KEYS)[number],
    consentMarketing: readFlag(values, "consentMarketing"),
  };
}

export async function createCustomer(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "crm", "create");
    const d = parseCustomer(values);
    const duplicates = await findDuplicates(companyId, d.phone, d.email);
    if (duplicates.length > 0 && !readFlag(values, "allowDuplicate")) {
      throw new AppError(
        `A similar record already exists: ${duplicates.join("; ")}. Open that record, or tick "Save even if a similar record already exists".`,
        { phone: "Possible duplicate." },
      );
    }
    const assigneeId = values.assignedUserId ? await validAssignee(companyId, values.assignedUserId) : null;
    const branchId = await validBranch(companyId, ctx, values.branchId ?? "");

    const customerId = await db.transaction(async (tx) => {
      const sequence = await nextSequence(tx, companyId, "customer");
      const [created] = await tx
        .insert(customers)
        .values({
          companyId,
          code: formatDocNumber("CUS", sequence),
          fullName: d.fullName,
          phone: d.phone,
          altPhone: d.altPhone,
          email: d.email,
          address: d.address || null,
          city: d.city || null,
          country: d.country || null,
          nationality: d.nationality || null,
          dateOfBirth: d.dateOfBirth,
          occupation: d.occupation || null,
          category: d.category,
          interestedService: d.interestedService || null,
          passportNumber: d.passportNumber || null,
          passportExpiry: d.passportExpiry,
          branchId,
          assignedUserId: assigneeId ?? ctx.user.id,
          consentMarketing: d.consentMarketing,
          notes: d.notes || null,
          createdById: ctx.user.id,
          updatedById: ctx.user.id,
        })
        .returning({ id: customers.id, code: customers.code });
      await tx.insert(activities).values({
        companyId,
        customerId: created.id,
        type: "system",
        summary: `Customer ${created.code} registered`,
        createdById: ctx.user.id,
      });
      return created.id;
    });
    await logAudit({ companyId, userId: ctx.user.id, action: "customer.created", entityType: "customer", entityId: customerId, summary: `Customer created: ${d.fullName}` });
    return customerId;
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  redirect(`/c/${companyId}/crm/customers/${result.data}`);
}

export async function updateCustomer(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  const customerId = parseId(values.customerId);
  if (!companyId || !customerId) return failure("Customer not found. Please reload the page.");

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "crm", "edit");
    const [existing] = await db
      .select()
      .from(customers)
      .where(and(eq(customers.id, customerId), eq(customers.companyId, companyId)))
      .limit(1);
    if (!existing) throw new AppError("Customer not found.");
    if (!inBranchScope(ctx, existing.branchId)) throw new AppError("This customer belongs to another branch.");
    const d = parseCustomer(values);
    const assigneeId = values.assignedUserId ? await validAssignee(companyId, values.assignedUserId) : null;
    await db
      .update(customers)
      .set({
        fullName: d.fullName,
        phone: d.phone,
        altPhone: d.altPhone,
        email: d.email,
        address: d.address || null,
        city: d.city || null,
        country: d.country || null,
        nationality: d.nationality || null,
        dateOfBirth: d.dateOfBirth,
        occupation: d.occupation || null,
        category: d.category,
        interestedService: d.interestedService || null,
        passportNumber: Object.hasOwn(values, "passportNumber") ? d.passportNumber || null : existing.passportNumber,
        passportExpiry: Object.hasOwn(values, "passportExpiry") ? d.passportExpiry : existing.passportExpiry,
        assignedUserId: assigneeId,
        consentMarketing: d.consentMarketing,
        notes: d.notes || null,
        updatedById: ctx.user.id,
        updatedAt: new Date(),
      })
      .where(eq(customers.id, customerId));
    await logAudit({ companyId, userId: ctx.user.id, action: "customer.updated", entityType: "customer", entityId: customerId, summary: `Customer details updated: ${d.fullName}` });
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Customer details saved.");
}

// ---------- Notes, calls and follow-ups ----------
const noteSchema = z.object({
  summary: z.string().trim().min(2, "Write a short summary.").max(300),
  details: z.string().trim().max(3000),
});

export async function addActivity(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const leadId = parseId(String(formData.get("leadId") ?? ""));
  const customerId = parseId(String(formData.get("customerId") ?? ""));
  const type = String(formData.get("type") ?? "note");
  const back = leadId ? `/c/${companyId}/crm/leads/${leadId}` : `/c/${companyId}/crm/customers/${customerId}`;
  const parsed = noteSchema.safeParse({
    summary: String(formData.get("summary") ?? ""),
    details: String(formData.get("details") ?? ""),
  });
  const result = await safeAction(async () => {
    if (!companyId || (!leadId && !customerId)) throw new AppError("Record not found.");
    if (!parsed.success) throw new AppError(parsed.error.issues[0]?.message ?? "Check the note.");
    if (!(ACTIVITY_TYPE_KEYS as readonly string[]).includes(type)) throw new AppError("Choose a valid activity type.");
    const ctx = await requireAccess(companyId, "crm", "create");
    if (leadId) {
      const [lead] = await db.select({ id: leads.id, branchId: leads.branchId }).from(leads).where(and(eq(leads.id, leadId), eq(leads.companyId, companyId))).limit(1);
      if (!lead || !inBranchScope(ctx, lead.branchId)) throw new AppError("Lead not found.");
    }
    if (customerId) {
      const [customer] = await db.select({ id: customers.id, branchId: customers.branchId }).from(customers).where(and(eq(customers.id, customerId), eq(customers.companyId, companyId))).limit(1);
      if (!customer || !inBranchScope(ctx, customer.branchId)) throw new AppError("Customer not found.");
    }
    await db.insert(activities).values({
      companyId,
      leadId: leadId ?? null,
      customerId: customerId ?? null,
      type: type as ActivityType,
      summary: parsed.data.summary,
      details: parsed.data.details || null,
      createdById: ctx.user.id,
    });
  });
  refreshAll();
  redirect(flashUrl(back, result.ok ? "notice" : "error", result.ok ? "Note saved to the timeline." : result.error));
}

const followUpSchema = z.object({
  title: z.string().trim().min(3, "Describe the follow-up (at least 3 letters).").max(200),
  notes: z.string().trim().max(2000),
  dueAt: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/, "Choose a date and time."),
});

export async function scheduleFollowUp(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  const leadId = parseId(values.leadId);
  const customerId = parseId(values.customerId);
  if (!companyId || (!leadId && !customerId)) return failure("Record not found. Please reload the page.");
  const parsed = followUpSchema.safeParse({
    title: readText(values, "title"),
    notes: readText(values, "notes"),
    dueAt: readText(values, "dueAt"),
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "crm", "create");
    const dueAt = new Date(`${parsed.data.dueAt}:00+06:00`);
    if (Number.isNaN(dueAt.getTime())) throw new AppError("Choose a valid date and time.", { dueAt: "Choose a valid date and time." });
    const assigneeId = values.assignedUserId ? await validAssignee(companyId, values.assignedUserId) : null;
    const assignedTo = assigneeId ?? ctx.user.id;
    await db.insert(followUps).values({
      companyId,
      leadId: leadId ?? null,
      customerId: customerId ?? null,
      assignedUserId: assignedTo,
      title: parsed.data.title,
      notes: parsed.data.notes || null,
      dueAt,
      createdById: ctx.user.id,
    });
    if (assignedTo !== ctx.user.id) {
      await notify(assignedTo, {
        companyId,
        title: "New follow-up assigned to you",
        body: parsed.data.title,
        link: `/c/${companyId}/crm/followups`,
      });
    }
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Follow-up scheduled.");
}

export async function completeFollowUp(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const followUpId = parseId(String(formData.get("followUpId") ?? ""));
  const outcome = String(formData.get("outcome") ?? "done") === "cancelled" ? "cancelled" : "done";
  const back = `/c/${companyId}/crm/followups`;
  const result = await safeAction(async () => {
    if (!companyId || !followUpId) throw new AppError("Follow-up not found.");
    const ctx = await requireAccess(companyId, "crm", "edit");
    const [row] = await db
      .select()
      .from(followUps)
      .where(and(eq(followUps.id, followUpId), eq(followUps.companyId, companyId)))
      .limit(1);
    if (!row) throw new AppError("Follow-up not found.");
    await db
      .update(followUps)
      .set({ status: outcome, completedAt: new Date() })
      .where(eq(followUps.id, followUpId));
    if (outcome === "done" && row.leadId) {
      await db.insert(activities).values({
        companyId,
        leadId: row.leadId,
        type: "follow_up",
        summary: `Follow-up completed: ${row.title}`,
        createdById: ctx.user.id,
      });
    }
  });
  refreshAll();
  redirect(flashUrl(back, result.ok ? "notice" : "error", result.ok ? "Follow-up updated." : result.error));
}


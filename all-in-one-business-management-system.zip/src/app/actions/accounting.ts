"use server";

// Accounting: quotations, invoices, money receipts, refunds, advances, expenses, cash/bank accounts and transfers.
// Rules: confirmed records are never deleted. They are cancelled with a reason. Numbers are never reused.
import { and, asc, eq, sql } from "drizzle-orm";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/db";
import {
  accountTransfers,
  activities,
  branches,
  campaigns,
  cashAccounts,
  customers,
  documents,
  expenseCategories,
  expenses,
  invoiceItems,
  invoices,
  paymentAllocations,
  receipts,
  services,
  visaApplications,
} from "@/db/schema";
import { logAudit, notifyMany } from "@/lib/audit";
import { AppError, failure, flashUrl, formValues, readText, refreshAll, safeAction, success, zodFieldErrors } from "@/lib/action";
import {
  ACCOUNT_TYPE_KEYS,
  DOC_TYPE_KEYS,
  PAYMENT_METHOD_KEYS,
  humanize,
  type AccountType,
  type DocType,
  type InvoiceStatus,
  type PaymentMethod,
} from "@/lib/constants";
import type { FormState } from "@/lib/form-state";
import { parseId, todayISO } from "@/lib/format";
import { accountBalances, customerAdvanceCents, lockInvoiceTx, recomputeInvoiceTx } from "@/lib/ledger";
import { formatDocNumber, nextSequence, type Tx } from "@/lib/numbering";
import { centsToDb, dbToCents, lineTotals, parseToCents, sumCents, type Cents } from "@/lib/money";
import { inBranchScope, requireAccess, usersWithPermission, type AccessContext } from "@/lib/permissions";
import { saveUpload } from "@/lib/storage";

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const ITEM_COUNT = 5;
const oneOf = (keys: readonly string[], message: string) => z.string().refine((value) => keys.includes(value), { message });

// ---------- Shared checks ----------
async function assertCustomer(ctx: AccessContext, companyId: number, customerId: number) {
  const [customer] = await db
    .select()
    .from(customers)
    .where(and(eq(customers.id, customerId), eq(customers.companyId, companyId)))
    .limit(1);
  if (!customer || customer.isArchived) throw new AppError("This customer was not found.", { customerId: "Choose a customer." });
  if (!inBranchScope(ctx, customer.branchId)) throw new AppError("This customer belongs to another branch.");
  return customer;
}

async function assertAccount(companyId: number, accountId: number | null) {
  if (!accountId) return null;
  const [account] = await db
    .select()
    .from(cashAccounts)
    .where(and(eq(cashAccounts.id, accountId), eq(cashAccounts.companyId, companyId), eq(cashAccounts.isActive, true)))
    .limit(1);
  if (!account) throw new AppError("The selected cash or bank account was not found.", { accountId: "Choose an active account." });
  return account;
}

async function assertBranch(companyId: number, branchId: number | null) {
  if (!branchId) return null;
  const [branch] = await db
    .select({ id: branches.id })
    .from(branches)
    .where(and(eq(branches.id, branchId), eq(branches.companyId, companyId)))
    .limit(1);
  if (!branch) throw new AppError("The branch does not belong to this company.");
  return branch.id;
}

async function getInvoice(companyId: number, invoiceId: number) {
  const [invoice] = await db
    .select()
    .from(invoices)
    .where(and(eq(invoices.id, invoiceId), eq(invoices.companyId, companyId)))
    .limit(1);
  if (!invoice) throw new AppError("This document was not found.");
  return invoice;
}

async function getReceipt(companyId: number, receiptId: number) {
  const [receipt] = await db
    .select()
    .from(receipts)
    .where(and(eq(receipts.id, receiptId), eq(receipts.companyId, companyId)))
    .limit(1);
  if (!receipt) throw new AppError("This receipt was not found.");
  return receipt;
}

async function findReceiptByToken(tx: Tx, companyId: number, token: string) {
  const [row] = await tx
    .select({ id: receipts.id, number: receipts.number })
    .from(receipts)
    .where(and(eq(receipts.companyId, companyId), eq(receipts.formToken, token)))
    .limit(1);
  return row ?? null;
}

async function ensureTransactionRefFree(tx: Tx, companyId: number, ref: string) {
  if (!ref) return;
  const [row] = await tx
    .select({ number: receipts.number })
    .from(receipts)
    .where(and(eq(receipts.companyId, companyId), eq(receipts.transactionRef, ref), eq(receipts.status, "active")))
    .limit(1);
  if (row) {
    throw new AppError(`Transaction reference "${ref}" was already recorded on receipt ${row.number}. Check before recording it again.`, {
      transactionRef: "Already used.",
    });
  }
}

// ---------- Quotations and invoices ----------
type ItemInput = { serviceId: number | null; description: string; quantityH: number; unitCents: Cents; taxH: number };

async function readItems(companyId: number, values: Record<string, string>): Promise<ItemInput[]> {
  const items: ItemInput[] = [];
  for (let n = 1; n <= ITEM_COUNT; n++) {
    const serviceId = parseId(readText(values, `item${n}_service`));
    let service: typeof services.$inferSelect | null = null;
    if (serviceId) {
      const [row] = await db
        .select()
        .from(services)
        .where(and(eq(services.id, serviceId), eq(services.companyId, companyId)))
        .limit(1);
      service = row ?? null;
    }
    const description = (readText(values, `item${n}_description`) || service?.name || "").slice(0, 300);
    const priceText = readText(values, `item${n}_price`) || (service ? centsToDb(dbToCents(service.unitPrice)) : "");
    if (!description && !priceText) continue;
    if (!description) throw new AppError(`Item ${n}: describe the service or product.`, { [`item${n}_description`]: "Describe this item." });
    const quantityH = parseToCents(readText(values, `item${n}_qty`) || "1");
    if (quantityH === null || quantityH <= 0) throw new AppError(`Item ${n}: enter a quantity greater than zero.`, { [`item${n}_qty`]: "Enter a quantity above 0." });
    const unitCents = parseToCents(priceText);
    if (unitCents === null || unitCents < 0) throw new AppError(`Item ${n}: enter the unit price.`, { [`item${n}_price`]: "Enter a valid price." });
    const taxText = readText(values, `item${n}_tax`) || (service ? centsToDb(dbToCents(service.taxRate)) : "0");
    const taxH = parseToCents(taxText);
    if (taxH === null || taxH < 0 || taxH > 10000) throw new AppError(`Item ${n}: tax must be between 0 and 100 percent.`, { [`item${n}_tax`]: "0 to 100." });
    items.push({ serviceId: service?.id ?? null, description, quantityH, unitCents, taxH });
  }
  if (items.length === 0) throw new AppError("Add at least one item with a description and price.", { item1_description: "Add at least one item." });
  return items;
}

function computeTotals(items: ItemInput[], discountCents: number) {
  const lines = items.map((item, index) => {
    const amounts = lineTotals(item.quantityH, item.unitCents, item.taxH);
    return { ...item, gross: amounts.gross, tax: amounts.tax, lineTotal: amounts.total, sortOrder: index };
  });
  const subtotal = sumCents(lines.map((l) => l.gross));
  const tax = sumCents(lines.map((l) => l.tax));
  if (discountCents < 0 || discountCents > subtotal + tax) {
    throw new AppError("The discount cannot be more than the total amount.", { discount: "Discount is too large." });
  }
  return { lines, subtotal, tax, discount: discountCents, total: subtotal + tax - discountCents };
}

export async function createDocument(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const docType = readText(values, "docType") || "invoice";
  if (!(DOC_TYPE_KEYS as readonly string[]).includes(docType)) return failure("Choose invoice or quotation.", values);
  const issueDate = readText(values, "issueDate") || todayISO();
  const dueDate = readText(values, "dueDate");
  if (!DATE_PATTERN.test(issueDate) || (dueDate && !DATE_PATTERN.test(dueDate))) {
    return failure("Please check the dates.", values, { issueDate: "Use a valid date." });
  }

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "accounting", "create");
    const customerId = parseId(readText(values, "customerId"));
    if (!customerId) throw new AppError("Choose the customer.", { customerId: "Choose the customer." });
    const customer = await assertCustomer(ctx, companyId, customerId);

    const visaApplicationId = parseId(readText(values, "visaApplicationId"));
    if (visaApplicationId) {
      const [visa] = await db
        .select({ id: visaApplications.id })
        .from(visaApplications)
        .where(and(eq(visaApplications.id, visaApplicationId), eq(visaApplications.companyId, companyId), eq(visaApplications.customerId, customerId)))
        .limit(1);
      if (!visa) throw new AppError("The visa file does not belong to this customer.");
    }

    const items = await readItems(companyId, values);
    const discount = parseToCents(readText(values, "discount") || "0");
    if (discount === null || discount < 0) throw new AppError("Enter the discount as a number.", { discount: "Enter a valid amount." });
    const totals = computeTotals(items, discount);
    const company = ctx.company;

    const invoiceId = await db.transaction(async (tx) => {
      const sequence = await nextSequence(tx, companyId, docType);
      const number = formatDocNumber(docType === "invoice" ? company.invoicePrefix : company.quotationPrefix, sequence);
      const isInvoice = docType === "invoice";
      const [created] = await tx
        .insert(invoices)
        .values({
          companyId,
          branchId: ctx.branchId ?? customer.branchId,
          customerId,
          visaApplicationId,
          docType: docType as DocType,
          number,
          status: (isInvoice ? "issued" : "draft") as InvoiceStatus,
          issueDate,
          dueDate: dueDate || null,
          serviceReference: readText(values, "serviceReference") || null,
          subtotal: centsToDb(totals.subtotal),
          discountAmount: centsToDb(totals.discount),
          taxAmount: centsToDb(totals.tax),
          total: centsToDb(totals.total),
          paidAmount: "0",
          dueAmount: isInvoice ? centsToDb(totals.total) : "0",
          notes: readText(values, "notes") || null,
          terms: readText(values, "terms") || null,
          createdById: ctx.user.id,
          updatedById: ctx.user.id,
        })
        .returning({ id: invoices.id, number: invoices.number });
      await tx.insert(invoiceItems).values(
        totals.lines.map((line) => ({
          invoiceId: created.id,
          serviceId: line.serviceId,
          description: line.description,
          quantity: centsToDb(line.quantityH),
          unitPrice: centsToDb(line.unitCents),
          discountAmount: "0",
          taxRate: centsToDb(line.taxH),
          taxAmount: centsToDb(line.tax),
          lineTotal: centsToDb(line.lineTotal),
          sortOrder: line.sortOrder,
        })),
      );
      return { id: created.id, number: created.number };
    });

    await db.insert(activities).values({
      companyId,
      customerId,
      type: "system",
      summary: `${docType === "invoice" ? "Invoice" : "Quotation"} ${invoiceId.number} issued for ${humanize(docType)} total ${centsToDb(totals.total)}`,
      createdById: ctx.user.id,
    });
    await logAudit({ companyId, userId: ctx.user.id, action: `${docType}.created`, entityType: docType, entityId: invoiceId.id, summary: `${invoiceId.number} created for ${customer.fullName}` });
    return invoiceId.id;
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  redirect(`/c/${companyId}/accounting/invoices/${result.data}`);
}

export async function cancelDocument(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const invoiceId = parseId(String(formData.get("invoiceId") ?? ""));
  const reason = String(formData.get("reason") ?? "").trim().slice(0, 300);
  const result = await safeAction(async () => {
    if (!companyId || !invoiceId) throw new AppError("Document not found.");
    if (reason.length < 5) throw new AppError("Write a clear reason for cancelling (at least 5 letters).");
    const ctx = await requireAccess(companyId, "accounting", "delete");
    const invoice = await getInvoice(companyId, invoiceId);
    if (!inBranchScope(ctx, invoice.branchId)) throw new AppError("This document belongs to another branch.");
    if (invoice.status === "cancelled") throw new AppError("This document is already cancelled.");
    if (invoice.docType === "invoice" && dbToCents(invoice.paidAmount) > 0) {
      throw new AppError("This invoice has payments recorded. Cancel the related receipts first, so the money trail stays clear.");
    }
    if (invoice.docType === "quotation" && invoice.status === "converted") throw new AppError("A converted quotation cannot be cancelled. Cancel the invoice instead.");
    await db
      .update(invoices)
      .set({ status: "cancelled", dueAmount: "0", cancelReason: reason, cancelledAt: new Date(), cancelledById: ctx.user.id, updatedById: ctx.user.id, updatedAt: new Date() })
      .where(eq(invoices.id, invoiceId));
    await logAudit({ companyId, userId: ctx.user.id, action: `${invoice.docType}.cancelled`, entityType: invoice.docType, entityId: invoiceId, summary: `${invoice.number} cancelled: ${reason}` });
  });
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/accounting/invoices/${invoiceId}`, result.ok ? "notice" : "error", result.ok ? "Document cancelled. Its number is kept and will not be reused." : result.error));
}

export async function setQuotationStatus(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const invoiceId = parseId(String(formData.get("invoiceId") ?? ""));
  const status = String(formData.get("status") ?? "");
  const result = await safeAction(async () => {
    if (!companyId || !invoiceId) throw new AppError("Quotation not found.");
    if (!["sent", "accepted", "rejected"].includes(status)) throw new AppError("Choose a valid quotation status.");
    const ctx = await requireAccess(companyId, "accounting", "create");
    const invoice = await getInvoice(companyId, invoiceId);
    if (invoice.docType !== "quotation") throw new AppError("Only quotations can change this way.");
    if (invoice.status === "converted" || invoice.status === "cancelled") throw new AppError("This quotation can no longer change.");
    await db.update(invoices).set({ status: status as InvoiceStatus, updatedById: ctx.user.id, updatedAt: new Date() }).where(eq(invoices.id, invoiceId));
  });
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/accounting/invoices/${invoiceId}`, result.ok ? "notice" : "error", result.ok ? `Quotation marked ${status}.` : result.error));
}

export async function convertQuotation(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const quotationId = parseId(String(formData.get("invoiceId") ?? ""));
  const result = await safeAction(async () => {
    if (!companyId || !quotationId) throw new AppError("Quotation not found.");
    const ctx = await requireAccess(companyId, "accounting", "create");
    const quote = await getInvoice(companyId, quotationId);
    if (quote.docType !== "quotation") throw new AppError("Only quotations can be converted.");
    if (quote.status === "converted" || quote.status === "cancelled" || quote.status === "rejected") {
      throw new AppError(`This quotation cannot be converted (status: ${humanize(quote.status)}).`);
    }
    const lines = await db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, quotationId)).orderBy(asc(invoiceItems.sortOrder));
    const converted = await db.transaction(async (tx) => {
      const sequence = await nextSequence(tx, companyId, "invoice");
      const number = formatDocNumber(ctx.company.invoicePrefix, sequence);
      const [created] = await tx
        .insert(invoices)
        .values({
          companyId,
          branchId: quote.branchId,
          customerId: quote.customerId,
          visaApplicationId: quote.visaApplicationId,
          docType: "invoice",
          number,
          status: "issued",
          issueDate: todayISO(),
          dueDate: quote.dueDate,
          serviceReference: quote.serviceReference,
          subtotal: quote.subtotal,
          discountAmount: quote.discountAmount,
          taxAmount: quote.taxAmount,
          total: quote.total,
          paidAmount: "0",
          dueAmount: quote.total,
          currency: quote.currency,
          sourceQuotationId: quote.id,
          notes: quote.notes,
          terms: quote.terms,
          createdById: ctx.user.id,
          updatedById: ctx.user.id,
        })
        .returning({ id: invoices.id });
      if (lines.length > 0) {
        await tx.insert(invoiceItems).values(
          lines.map((l) => ({
            invoiceId: created.id,
            serviceId: l.serviceId,
            description: l.description,
            quantity: l.quantity,
            unitPrice: l.unitPrice,
            discountAmount: l.discountAmount,
            taxRate: l.taxRate,
            taxAmount: l.taxAmount,
            lineTotal: l.lineTotal,
            sortOrder: l.sortOrder,
          })),
        );
      }
      await tx.update(invoices).set({ status: "converted", updatedById: ctx.user.id, updatedAt: new Date() }).where(eq(invoices.id, quotationId));
      return { id: created.id, number };
    });
    await logAudit({ companyId, userId: ctx.user.id, action: "quotation.converted", entityType: "invoice", entityId: converted.id, summary: `${quote.number} converted into invoice ${converted.number}` });
    return converted.id;
  });
  refreshAll();
  if (!result.ok) redirect(flashUrl(`/c/${companyId}/accounting/invoices/${quotationId}`, "error", result.error));
  redirect(flashUrl(`/c/${companyId}/accounting/invoices/${result.data}`, "notice", "Quotation converted into a new invoice."));
}

// ---------- Money receipts ----------
const receiptSchema = z.object({
  paymentMethod: oneOf(PAYMENT_METHOD_KEYS, "Choose how the money was paid."),
  transactionRef: z.string().trim().max(80),
  receivedByName: z.string().trim().max(120),
  notes: z.string().trim().max(1000),
});

export async function recordReceipt(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const token = readText(values, "formToken");
  if (token.length < 8) return failure("This form has expired. Please reload the page and try again.", values);
  const parsed = receiptSchema.safeParse({
    paymentMethod: readText(values, "paymentMethod") || "cash",
    transactionRef: readText(values, "transactionRef"),
    receivedByName: readText(values, "receivedByName"),
    notes: readText(values, "notes"),
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const receiptDate = readText(values, "receiptDate") || todayISO();
  if (!DATE_PATTERN.test(receiptDate)) return failure("Use a valid date.", values, { receiptDate: "Use a valid date." });

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "accounting", "create");
    const customerId = parseId(readText(values, "customerId"));
    if (!customerId) throw new AppError("Choose the customer.", { customerId: "Choose the customer." });
    const customer = await assertCustomer(ctx, companyId, customerId);
    const amount = parseToCents(readText(values, "amount"));
    if (amount === null || amount <= 0) throw new AppError("Enter the amount received.", { amount: "Enter an amount above 0." });
    const account = await assertAccount(companyId, parseId(readText(values, "accountId")));
    const invoiceId = parseId(readText(values, "invoiceId"));
    const applyText = readText(values, "applyAmount");
    const branchId = ctx.branchId ?? (await assertBranch(companyId, parseId(readText(values, "branchId"))));

    const outcome = await db.transaction(async (tx) => {
      const existing = await findReceiptByToken(tx, companyId, token);
      if (existing) return { id: existing.id, number: existing.number, duplicate: true };

      await ensureTransactionRefFree(tx, companyId, parsed.data.transactionRef);

      let invoice: Awaited<ReturnType<typeof lockInvoiceTx>> = null;
      let due: Cents = 0;
      if (invoiceId) {
        invoice = await lockInvoiceTx(tx, invoiceId);
        if (!invoice || invoice.companyId !== companyId) throw new AppError("The selected invoice was not found.", { invoiceId: "Choose an invoice." });
        if (invoice.customerId !== customerId) throw new AppError("This invoice belongs to a different customer.", { invoiceId: "Choose this customer's invoice." });
        if (invoice.docType !== "invoice" || (invoice.status !== "issued" && invoice.status !== "partially_paid")) {
          throw new AppError("This invoice is not open for payment.", { invoiceId: "This invoice is not open for payment." });
        }
        due = dbToCents(invoice.dueAmount);
      }

      const apply = applyText ? parseToCents(applyText) : Math.min(amount, due);
      if (apply === null || apply < 0) throw new AppError("Enter the amount to apply as a number.", { applyAmount: "Enter a valid amount." });
      if (apply > amount) throw new AppError("The amount applied to the invoice cannot be more than the amount received.", { applyAmount: "Too large." });
      if (invoice && apply > due) throw new AppError(`Only ৳ ${centsToDb(due)} is still due on this invoice.`, { applyAmount: "More than the amount due." });
      if (!invoice && apply > 0) throw new AppError("Choose the invoice to apply this money to.", { invoiceId: "Choose an invoice." });

      const sequence = await nextSequence(tx, companyId, "receipt");
      const number = formatDocNumber(ctx.company.receiptPrefix, sequence);
      const [row] = await tx
        .insert(receipts)
        .values({
          companyId,
          branchId,
          customerId,
          accountId: account?.id ?? null,
          number,
          kind: "payment",
          status: "active",
          receiptDate,
          amount: centsToDb(amount),
          paymentMethod: parsed.data.paymentMethod as PaymentMethod,
          transactionRef: parsed.data.transactionRef || null,
          receivedByName: parsed.data.receivedByName || ctx.user.fullName,
          notes: parsed.data.notes || null,
          formToken: token,
          createdById: ctx.user.id,
        })
        .returning({ id: receipts.id, number: receipts.number });

      if (invoice && apply > 0) {
        await tx.insert(paymentAllocations).values({
          companyId,
          receiptId: row.id,
          invoiceId: invoice.id,
          amount: centsToDb(apply),
          createdById: ctx.user.id,
        });
        await recomputeInvoiceTx(tx, invoice.id);
      }
      return { id: row.id, number: row.number, duplicate: false };
    });

    if (!outcome.duplicate) {
      await db.insert(activities).values({
        companyId,
        customerId,
        type: "system",
        summary: `Receipt ${outcome.number} recorded: ${centsToDb(amount)} by ${humanize(parsed.data.paymentMethod)}`,
        createdById: ctx.user.id,
      });
      await logAudit({ companyId, userId: ctx.user.id, action: "receipt.created", entityType: "receipt", entityId: outcome.id, summary: `Receipt ${outcome.number} for ${customer.fullName}: ${centsToDb(amount)}` });
    }
    return outcome;
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  if (result.data.duplicate) {
    redirect(flashUrl(`/c/${companyId}/accounting/receipts/${result.data.id}`, "notice", "This payment was already recorded. No duplicate was created."));
  }
  redirect(flashUrl(`/c/${companyId}/accounting/receipts/${result.data.id}`, "notice", "Money receipt recorded."));
}

export async function recordRefund(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const token = readText(values, "formToken");
  if (token.length < 8) return failure("This form has expired. Please reload the page and try again.", values);
  const receiptDate = readText(values, "receiptDate") || todayISO();
  const parsed = receiptSchema.safeParse({
    paymentMethod: readText(values, "paymentMethod") || "cash",
    transactionRef: readText(values, "transactionRef"),
    receivedByName: readText(values, "receivedByName"),
    notes: readText(values, "notes"),
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  if (!DATE_PATTERN.test(receiptDate)) return failure("Use a valid date.", values, { receiptDate: "Use a valid date." });
  if (parsed.data.notes.length < 5) return failure("Write the reason for the refund.", values, { notes: "Write the reason (at least 5 letters)." });

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "accounting", "create");
    if (!ctx.can("accounting", "approve")) {
      throw new AppError("Refunds need approval. Ask a senior accountant or manager to record this refund.");
    }
    const customerId = parseId(readText(values, "customerId"));
    if (!customerId) throw new AppError("Choose the customer.", { customerId: "Choose the customer." });
    await assertCustomer(ctx, companyId, customerId);
    const amount = parseToCents(readText(values, "amount"));
    if (amount === null || amount <= 0) throw new AppError("Enter the refund amount.", { amount: "Enter an amount above 0." });
    const advance = await customerAdvanceCents(companyId, customerId);
    if (amount > advance) {
      throw new AppError(`The refund is larger than the advance this customer holds (৳ ${centsToDb(Math.max(advance, 0))}).`, { amount: "Larger than the advance held." });
    }
    const account = await assertAccount(companyId, parseId(readText(values, "accountId")));

    const outcome = await db.transaction(async (tx) => {
      const existing = await findReceiptByToken(tx, companyId, token);
      if (existing) return { id: existing.id, number: existing.number, duplicate: true };
      await ensureTransactionRefFree(tx, companyId, parsed.data.transactionRef);
      const sequence = await nextSequence(tx, companyId, "receipt");
      const number = formatDocNumber(ctx.company.receiptPrefix, sequence);
      const [row] = await tx
        .insert(receipts)
        .values({
          companyId,
          customerId,
          accountId: account?.id ?? null,
          number,
          kind: "refund",
          status: "active",
          receiptDate,
          amount: centsToDb(amount),
          paymentMethod: parsed.data.paymentMethod as PaymentMethod,
          transactionRef: parsed.data.transactionRef || null,
          receivedByName: parsed.data.receivedByName || ctx.user.fullName,
          notes: parsed.data.notes,
          formToken: token,
          createdById: ctx.user.id,
        })
        .returning({ id: receipts.id, number: receipts.number });
      return { id: row.id, number: row.number, duplicate: false };
    });
    if (!outcome.duplicate) {
      await logAudit({ companyId, userId: ctx.user.id, action: "refund.created", entityType: "receipt", entityId: outcome.id, summary: `Refund ${outcome.number}: ${centsToDb(amount)}. Reason: ${parsed.data.notes}` });
    }
    return outcome;
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/accounting/receipts/${result.data.id}`, "notice", result.data.duplicate ? "This refund was already recorded." : "Refund recorded."));
}

export async function applyAdvance(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  const invoiceId = parseId(values.invoiceId);
  const receiptId = parseId(values.receiptId);
  if (!companyId || !invoiceId || !receiptId) return failure("Choose the invoice and the payment to apply.", values, { receiptId: "Choose a payment." });
  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "accounting", "create");
    const outcome = await db.transaction(async (tx) => {
      const invoice = await lockInvoiceTx(tx, invoiceId);
      if (!invoice || invoice.companyId !== companyId) throw new AppError("Invoice not found.");
      if (invoice.docType !== "invoice" || (invoice.status !== "issued" && invoice.status !== "partially_paid")) {
        throw new AppError("This invoice is not open for payment.");
      }
      const [receipt] = await tx
        .select()
        .from(receipts)
        .where(and(eq(receipts.id, receiptId), eq(receipts.companyId, companyId)))
        .limit(1);
      if (!receipt || receipt.status !== "active" || receipt.kind !== "payment") throw new AppError("This payment is not available.");
      if (receipt.customerId !== invoice.customerId) throw new AppError("This payment belongs to a different customer.");
      const [used] = await tx
        .select({ total: sql`coalesce(sum(${paymentAllocations.amount}), 0)` })
        .from(paymentAllocations)
        .where(eq(paymentAllocations.receiptId, receiptId));
      const unallocated = dbToCents(receipt.amount) - dbToCents(String(used?.total ?? "0"));
      const due = dbToCents(invoice.dueAmount);
      const apply = parseToCents(readText(values, "amount")) ?? Math.min(unallocated, due);
      if (apply <= 0) throw new AppError("Enter an amount above 0.", { amount: "Enter an amount above 0." });
      if (apply > unallocated) throw new AppError(`Only ৳ ${centsToDb(unallocated)} of this payment is unused.`, { amount: "Too large." });
      if (apply > due) throw new AppError(`Only ৳ ${centsToDb(due)} is still due on this invoice.`, { amount: "More than due." });
      await tx.insert(paymentAllocations).values({ companyId, receiptId, invoiceId, amount: centsToDb(apply), createdById: ctx.user.id });
      await recomputeInvoiceTx(tx, invoiceId);
      return { applied: apply, receiptNumber: receipt.number, invoiceNumber: invoice.number };
    });
    await logAudit({ companyId, userId: ctx.user.id, action: "receipt.advance_applied", entityType: "invoice", entityId: invoiceId, summary: `${centsToDb(outcome.applied)} from receipt ${outcome.receiptNumber} applied to ${outcome.invoiceNumber}` });
    return outcome;
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Advance applied to the invoice.");
}

export async function cancelReceipt(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const receiptId = parseId(String(formData.get("receiptId") ?? ""));
  const reason = String(formData.get("reason") ?? "").trim().slice(0, 300);
  const result = await safeAction(async () => {
    if (!companyId || !receiptId) throw new AppError("Receipt not found.");
    if (reason.length < 5) throw new AppError("Write a clear reason for cancelling (at least 5 letters).");
    const ctx = await requireAccess(companyId, "accounting", "delete");
    const receipt = await getReceipt(companyId, receiptId);
    if (!inBranchScope(ctx, receipt.branchId)) throw new AppError("This receipt belongs to another branch.");
    if (receipt.status === "cancelled") throw new AppError("This receipt is already cancelled.");
    await db.transaction(async (tx) => {
      const allocated = await tx.select({ invoiceId: paymentAllocations.invoiceId }).from(paymentAllocations).where(eq(paymentAllocations.receiptId, receiptId));
      await tx
        .update(receipts)
        .set({ status: "cancelled", cancelReason: reason, cancelledAt: new Date(), cancelledById: ctx.user.id, updatedAt: new Date() })
        .where(eq(receipts.id, receiptId));
      const invoiceIds = [...new Set(allocated.map((a) => a.invoiceId))];
      for (const invoiceId of invoiceIds) {
        await lockInvoiceTx(tx, invoiceId);
        await recomputeInvoiceTx(tx, invoiceId);
      }
    });
    await logAudit({ companyId, userId: ctx.user.id, action: "receipt.cancelled", entityType: "receipt", entityId: receiptId, summary: `Receipt ${receipt.number} cancelled: ${reason}` });
  });
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/accounting/receipts/${receiptId}`, result.ok ? "notice" : "error", result.ok ? "Receipt cancelled. Its number is kept and will not be reused." : result.error));
}

export async function printReceipt(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const receiptId = parseId(String(formData.get("receiptId") ?? ""));
  let copy = 1;
  const result = await safeAction(async () => {
    if (!companyId || !receiptId) throw new AppError("Receipt not found.");
    const ctx = await requireAccess(companyId, "accounting", "print");
    const receipt = await getReceipt(companyId, receiptId);
    if (!inBranchScope(ctx, receipt.branchId)) throw new AppError("This receipt belongs to another branch.");
    copy = receipt.reprintCount + 1;
    await db.update(receipts).set({ reprintCount: copy }).where(eq(receipts.id, receiptId));
    await logAudit({ companyId, userId: ctx.user.id, action: "receipt.printed", entityType: "receipt", entityId: receiptId, summary: `Receipt ${receipt.number} printed (copy ${copy})` });
  });
  if (!result.ok) redirect(flashUrl(`/c/${companyId}/accounting/receipts/${receiptId}`, "error", result.error));
  redirect(`/c/${companyId}/accounting/receipts/${receiptId}/print?copy=${copy}`);
}

// ---------- Expenses ----------
const expenseSchema = z.object({
  description: z.string().trim().min(3, "Describe what the money was spent on.").max(300),
  payeeName: z.string().trim().max(150),
  reference: z.string().trim().max(80),
  paymentMethod: oneOf(PAYMENT_METHOD_KEYS, "Choose how it was paid."),
});

export async function createExpense(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const parsed = expenseSchema.safeParse({
    description: readText(values, "description"),
    payeeName: readText(values, "payeeName"),
    reference: readText(values, "reference"),
    paymentMethod: readText(values, "paymentMethod") || "cash",
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const expenseDate = readText(values, "expenseDate") || todayISO();
  if (!DATE_PATTERN.test(expenseDate)) return failure("Use a valid date.", values, { expenseDate: "Use a valid date." });
  const file = formData.get("receipt");
  const hasFile = file instanceof File && file.size > 0;

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "accounting", "create");
    const amount = parseToCents(readText(values, "amount"));
    if (amount === null || amount <= 0) throw new AppError("Enter the amount spent.", { amount: "Enter an amount above 0." });
    const categoryId = parseId(readText(values, "categoryId"));
    const [category] = categoryId
      ? await db
          .select({ id: expenseCategories.id })
          .from(expenseCategories)
          .where(and(eq(expenseCategories.id, categoryId), eq(expenseCategories.companyId, companyId), eq(expenseCategories.isActive, true)))
          .limit(1)
      : [];
    if (!category) throw new AppError("Choose an expense category.", { categoryId: "Choose a category." });
    const account = await assertAccount(companyId, parseId(readText(values, "accountId")));
    const campaignId = parseId(readText(values, "campaignId"));
    if (campaignId) {
      const [campaign] = await db
        .select({ id: campaigns.id })
        .from(campaigns)
        .where(and(eq(campaigns.id, campaignId), eq(campaigns.companyId, companyId)))
        .limit(1);
      if (!campaign) throw new AppError("The campaign does not belong to this company.", { campaignId: "Choose a campaign." });
    }
    const branchId = ctx.branchId ?? (await assertBranch(companyId, parseId(readText(values, "branchId"))));

    const autoApprove = ctx.can("accounting", "approve");
    const [created] = await db
      .insert(expenses)
      .values({
        companyId,
        branchId,
        categoryId: category.id,
        campaignId,
        accountId: account?.id ?? null,
        expenseDate,
        amount: centsToDb(amount),
        payeeName: parsed.data.payeeName || null,
        description: parsed.data.description,
        paymentMethod: parsed.data.paymentMethod as PaymentMethod,
        reference: parsed.data.reference || null,
        status: autoApprove ? "approved" : "pending",
        decidedById: autoApprove ? ctx.user.id : null,
        decidedAt: autoApprove ? new Date() : null,
        createdById: ctx.user.id,
      })
      .returning({ id: expenses.id });

    if (hasFile) {
      const saved = await saveUpload(file);
      await db.insert(documents).values({
        companyId,
        module: "accounting",
        category: "receipt",
        title: `Expense receipt: ${parsed.data.description.slice(0, 80)}`,
        fileName: saved.fileName,
        mimeType: saved.mimeType,
        sizeBytes: saved.sizeBytes,
        storageKey: saved.storageKey,
        expenseId: created.id,
        uploadedById: ctx.user.id,
      });
    }
    if (!autoApprove) {
      const approvers = await usersWithPermission(companyId, "accounting", "approve");
      await notifyMany(approvers, { companyId, title: "Expense waiting for approval", body: `${parsed.data.description} · ${centsToDb(amount)}`, link: `/c/${companyId}/accounting/expenses` }, ctx.user.id);
    }
    await logAudit({ companyId, userId: ctx.user.id, action: "expense.created", entityType: "expense", entityId: created.id, summary: `Expense ${centsToDb(amount)}: ${parsed.data.description} (${autoApprove ? "approved" : "pending approval"})` });
    return autoApprove;
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/accounting/expenses`, "notice", result.data ? "Expense recorded and approved." : "Expense recorded. It is waiting for approval."));
}

export async function decideExpense(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const expenseId = parseId(String(formData.get("expenseId") ?? ""));
  const decision = String(formData.get("decision") ?? "");
  const note = String(formData.get("note") ?? "").trim().slice(0, 300);
  const result = await safeAction(async () => {
    if (!companyId || !expenseId) throw new AppError("Expense not found.");
    if (decision !== "approve" && decision !== "reject") throw new AppError("Choose approve or reject.");
    const ctx = await requireAccess(companyId, "accounting", decision === "approve" ? "approve" : "reject");
    const [expense] = await db
      .select()
      .from(expenses)
      .where(and(eq(expenses.id, expenseId), eq(expenses.companyId, companyId)))
      .limit(1);
    if (!expense) throw new AppError("Expense not found.");
    if (!inBranchScope(ctx, expense.branchId)) throw new AppError("This expense belongs to another branch.");
    if (expense.status !== "pending") throw new AppError("This expense has already been decided.");
    if (expense.createdById === ctx.user.id) throw new AppError("You cannot approve your own expense. Ask another approver.");
    const status = decision === "approve" ? "approved" : "rejected";
    await db
      .update(expenses)
      .set({ status, decidedById: ctx.user.id, decidedAt: new Date(), decisionNote: note || null, updatedAt: new Date() })
      .where(eq(expenses.id, expenseId));
    if (expense.createdById) {
      await notifyMany([expense.createdById], { companyId, title: `Expense ${status}`, body: expense.description, link: `/c/${companyId}/accounting/expenses` });
    }
    await logAudit({ companyId, userId: ctx.user.id, action: `expense.${status}`, entityType: "expense", entityId: expenseId, summary: `Expense ${centsToDb(dbToCents(expense.amount))} ${status}${note ? `: ${note}` : ""}` });
  });
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/accounting/expenses`, result.ok ? "notice" : "error", result.ok ? "Decision saved." : result.error));
}

export async function createExpenseCategory(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const name = String(formData.get("name") ?? "").trim().slice(0, 80);
  const result = await safeAction(async () => {
    if (!companyId) throw new AppError("Company not found.");
    if (name.length < 2) throw new AppError("Enter a category name.");
    const ctx = await requireAccess(companyId, "accounting", "edit");
    await db.insert(expenseCategories).values({ companyId, name }).onConflictDoNothing();
    await logAudit({ companyId, userId: ctx.user.id, action: "expense_category.created", entityType: "expense_category", summary: `Expense category "${name}" added` });
  });
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/accounting/expenses`, result.ok ? "notice" : "error", result.ok ? "Category added." : result.error));
}

// ---------- Cash, bank and mobile wallets ----------
const accountSchema = z.object({
  name: z.string().trim().min(2, "Give the account a name.").max(100),
  providerName: z.string().trim().max(100),
  accountNumberMasked: z.string().trim().max(40),
});

export async function createCashAccount(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const parsed = accountSchema.safeParse({
    name: readText(values, "name"),
    providerName: readText(values, "providerName"),
    accountNumberMasked: readText(values, "accountNumberMasked"),
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const accountType = readText(values, "accountType") || "cash";
  if (!(ACCOUNT_TYPE_KEYS as readonly string[]).includes(accountType)) return failure("Choose the account type.", values);
  const opening = parseToCents(readText(values, "openingBalance") || "0");
  if (opening === null) return failure("Enter the opening balance as a number.", values, { openingBalance: "Enter a valid amount." });

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "accounting", "edit");
    await db.insert(cashAccounts).values({
      companyId,
      name: parsed.data.name,
      accountType: accountType as AccountType,
      providerName: parsed.data.providerName || null,
      accountNumberMasked: parsed.data.accountNumberMasked || null,
      openingBalance: centsToDb(opening),
    });
    await logAudit({ companyId, userId: ctx.user.id, action: "account.created", entityType: "cash_account", summary: `Account "${parsed.data.name}" added` });
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Account added.");
}

export async function transferFunds(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const from = parseId(readText(values, "fromAccountId"));
  const to = parseId(readText(values, "toAccountId"));
  const amount = parseToCents(readText(values, "amount"));
  const date = readText(values, "transferDate") || todayISO();
  if (!from || !to || from === to) return failure("Choose two different accounts.", values, { toAccountId: "Choose a different account." });
  if (amount === null || amount <= 0) return failure("Enter the amount to move.", values, { amount: "Enter an amount above 0." });
  if (!DATE_PATTERN.test(date)) return failure("Use a valid date.", values, { transferDate: "Use a valid date." });

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "accounting", "create");
    await assertAccount(companyId, from);
    await assertAccount(companyId, to);
    const balances = await accountBalances(companyId);
    const available = balances.get(from) ?? 0;
    if (amount > available) throw new AppError(`The source account only has ৳ ${centsToDb(Math.max(available, 0))}.`, { amount: "Not enough money in that account." });
    await db.insert(accountTransfers).values({
      companyId,
      fromAccountId: from,
      toAccountId: to,
      amount: centsToDb(amount),
      transferDate: date,
      reference: readText(values, "reference") || null,
      notes: readText(values, "notes") || null,
      createdById: ctx.user.id,
    });
    await logAudit({ companyId, userId: ctx.user.id, action: "account.transfer", entityType: "account_transfer", summary: `Transfer ${centsToDb(amount)} between accounts` });
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Transfer recorded.");
}

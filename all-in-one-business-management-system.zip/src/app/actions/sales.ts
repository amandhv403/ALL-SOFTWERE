"use server";

// Sales targets and marketing campaigns.
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { campaigns, targets, userCompanyAccess } from "@/db/schema";
import { logAudit } from "@/lib/audit";
import { AppError, failure, flashUrl, formValues, readText, refreshAll, safeAction, success, zodFieldErrors } from "@/lib/action";
import { CAMPAIGN_CHANNEL_KEYS, CAMPAIGN_STATUS_KEYS, TARGET_METRIC_KEYS, TARGET_PERIOD_KEYS, TARGET_SCOPE_KEYS, type TargetPeriod, type TargetScope, type TargetMetric, type CampaignChannel, type CampaignStatus } from "@/lib/constants";
import type { FormState } from "@/lib/form-state";
import { addDaysISO, parseId } from "@/lib/format";
import { parseToCents, centsToDb } from "@/lib/money";
import { requireAccess } from "@/lib/permissions";
import { redirect } from "next/navigation";

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

/** The last day of a target period, calculated from its start date. */
function periodEndFor(periodType: TargetPeriod, start: string): string {
  switch (periodType) {
    case "daily":
      return start;
    case "weekly":
      return addDaysISO(start, 6);
    case "monthly": {
      const [year, month] = start.split("-").map(Number);
      const last = new Date(Date.UTC(year, month, 0)).getUTCDate();
      return `${start.slice(0, 8)}${String(last).padStart(2, "0")}`;
    }
    case "quarterly":
      return addDaysISO(addMonthsISO(start, 3), -1);
    case "yearly":
      return addDaysISO(addMonthsISO(start, 12), -1);
  }
}

function addMonthsISO(start: string, months: number): string {
  const [year, month, day] = start.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1 + months, day));
  return date.toISOString().slice(0, 10);
}

const targetSchema = z.object({
  label: z.string().trim().min(3, "Give the target a name (at least 3 letters).").max(150),
  periodStart: z.string().regex(DATE_PATTERN, "Choose a start date."),
  targetValue: z.string().trim(),
});

export async function createTarget(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const parsed = targetSchema.safeParse({
    label: readText(values, "label"),
    periodStart: readText(values, "periodStart"),
    targetValue: readText(values, "targetValue"),
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));

  // The scope choice is "company", "branch:<id>", "department:<id>" or "employee:<id>".
  const [scopeKind, scopeIdText] = (readText(values, "scopeChoice") || "company").split(":");
  const scopeType = scopeKind;
  const metric = readText(values, "metric");
  const periodType = readText(values, "periodType") || "monthly";
  if (!(TARGET_SCOPE_KEYS as readonly string[]).includes(scopeType)) return failure("Choose who the target is for.", values);
  if (!(TARGET_METRIC_KEYS as readonly string[]).includes(metric)) return failure("Choose what to measure.", values, { metric: "Choose a measure." });
  if (!(TARGET_PERIOD_KEYS as readonly string[]).includes(periodType)) return failure("Choose a period.", values);

  const value = parseToCents(parsed.data.targetValue);
  if (value === null || value < 0) return failure("Enter a target number such as 500000 or 25.", values, { targetValue: "Enter a valid number." });

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "sales", "assign");
    const scopeId = scopeType === "company" ? null : parseId(scopeIdText ?? "");
    if (scopeType !== "company" && !scopeId) throw new AppError("Choose who or which team the target is for.", { scopeId: "Choose one." });
    if (scopeId && scopeType === "employee") {
      const [member] = await db
        .select({ id: userCompanyAccess.userId })
        .from(userCompanyAccess)
        .where(and(eq(userCompanyAccess.companyId, companyId), eq(userCompanyAccess.userId, scopeId), eq(userCompanyAccess.isActive, true)))
        .limit(1);
      if (!member) throw new AppError("That person does not work in this company.", { scopeId: "Choose a team member." });
    }
    const periodStart = parsed.data.periodStart;
    const periodEnd = periodEndFor(periodType as TargetPeriod, periodStart);
    await db.insert(targets).values({
      companyId,
      label: parsed.data.label,
      scopeType: scopeType as TargetScope,
      scopeId,
      metric: metric as TargetMetric,
      periodType: periodType as TargetPeriod,
      periodStart,
      periodEnd,
      targetValue: centsToDb(value),
      createdById: ctx.user.id,
    });
    await logAudit({ companyId, userId: ctx.user.id, action: "target.created", entityType: "target", summary: `Target "${parsed.data.label}" set for ${periodStart} to ${periodEnd}` });
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Target saved. Achievement is calculated automatically from your records.");
}

export async function deleteTarget(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const targetId = parseId(String(formData.get("targetId") ?? ""));
  const result = await safeAction(async () => {
    if (!companyId || !targetId) throw new AppError("Target not found.");
    const ctx = await requireAccess(companyId, "sales", "assign");
    await db.delete(targets).where(and(eq(targets.id, targetId), eq(targets.companyId, companyId)));
    await logAudit({ companyId, userId: ctx.user.id, action: "target.deleted", entityType: "target", entityId: targetId, summary: "Target removed" });
  });
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/sales/targets`, result.ok ? "notice" : "error", result.ok ? "Target removed." : result.error));
}

const campaignSchema = z.object({
  name: z.string().trim().min(3, "Give the campaign a name (at least 3 letters).").max(150),
  objective: z.string().trim().max(500),
});

export async function createCampaign(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found. Please reload the page.");
  const parsed = campaignSchema.safeParse({ name: readText(values, "name"), objective: readText(values, "objective") });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const channel = readText(values, "channel") || "facebook";
  const status = readText(values, "status") || "planned";
  if (!(CAMPAIGN_CHANNEL_KEYS as readonly string[]).includes(channel)) return failure("Choose a channel.", values);
  if (!(CAMPAIGN_STATUS_KEYS as readonly string[]).includes(status)) return failure("Choose a status.", values);
  const budget = parseToCents(readText(values, "budget") || "0");
  if (budget === null || budget < 0) return failure("Enter the budget as a number.", values, { budget: "Enter a valid amount." });
  const start = readText(values, "startDate");
  const end = readText(values, "endDate");
  if ((start && !DATE_PATTERN.test(start)) || (end && !DATE_PATTERN.test(end))) return failure("Use valid dates.", values);

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "marketing", "create");
    const [created] = await db
      .insert(campaigns)
      .values({
        companyId,
        name: parsed.data.name,
        channel: channel as CampaignChannel,
        objective: parsed.data.objective || null,
        startDate: start || null,
        endDate: end || null,
        budget: centsToDb(budget),
        status: status as CampaignStatus,
        ownerUserId: parseId(readText(values, "ownerUserId")) ?? ctx.user.id,
        createdById: ctx.user.id,
      })
      .returning({ id: campaigns.id });
    await logAudit({ companyId, userId: ctx.user.id, action: "campaign.created", entityType: "campaign", entityId: created.id, summary: `Campaign "${parsed.data.name}" created` });
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Campaign saved.");
}

export async function updateCampaignStatus(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const campaignId = parseId(String(formData.get("campaignId") ?? ""));
  const status = String(formData.get("status") ?? "");
  const result = await safeAction(async () => {
    if (!companyId || !campaignId) throw new AppError("Campaign not found.");
    if (!(CAMPAIGN_STATUS_KEYS as readonly string[]).includes(status)) throw new AppError("Choose a valid status.");
    const ctx = await requireAccess(companyId, "marketing", "edit");
    await db
      .update(campaigns)
      .set({ status: status as CampaignStatus, updatedAt: new Date() })
      .where(and(eq(campaigns.id, campaignId), eq(campaigns.companyId, companyId)));
    await logAudit({ companyId, userId: ctx.user.id, action: "campaign.status", entityType: "campaign", entityId: campaignId, summary: `Campaign status set to ${status}` });
  });
  refreshAll();
  redirect(flashUrl(`/c/${companyId}/marketing/campaigns`, result.ok ? "notice" : "error", result.ok ? "Campaign status updated." : result.error));
}

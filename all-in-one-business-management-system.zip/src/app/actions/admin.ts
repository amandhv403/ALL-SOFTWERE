"use server";

// Company, branch, department, module, team access, user account and role management.
import { randomBytes } from "node:crypto";
import { and, asc, eq, inArray, sql } from "drizzle-orm";
import { redirect } from "next/navigation";
import { z } from "zod";
import { db } from "@/db";
import {
  branches,
  companies,
  departments,
  expenseCategories,
  roles,
  userCompanyAccess,
  users,
} from "@/db/schema";
import { logAudit, notify } from "@/lib/audit";
import {
  AppError,
  failure,
  flashUrl,
  formValues,
  readFlag,
  readText,
  refreshAll,
  safeAction,
  success,
  zodFieldErrors,
} from "@/lib/action";
import { getSessionUser, hashPassword, passwordSchema, revokeUserSessions, type SessionUser } from "@/lib/auth";
import {
  ACTION_KEYS,
  BUSINESS_TYPE_KEYS,
  DEFAULT_EXPENSE_CATEGORIES,
  GLOBAL_ROLE_KEYS,
  MODULE_KEYS,
  PORTFOLIO_COMPANIES,
  TOGGLEABLE_MODULE_KEYS,
  type BusinessType,
  type GlobalRole,
} from "@/lib/constants";
import type { FormState } from "@/lib/form-state";
import { normalizeEmail, normalizePhone, parseId } from "@/lib/format";
import { ALL_PERMISSION_KEYS, ensureSystemRoles, requireAccess } from "@/lib/permissions";

const TIME_PATTERN = /^([01]\d|2[0-3]):[0-5]\d$/;
const PREFIX_PATTERN = /^[A-Z0-9-]{1,12}$/;
const oneOf = (keys: readonly string[], message: string) =>
  z.string().refine((value) => keys.includes(value), { message });

async function currentUser(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) throw new AppError("Your session has ended. Please sign in again.");
  return user;
}

function requireGlobalAdmin(user: SessionUser, ownerOnly = false): void {
  const allowed = ownerOnly
    ? user.globalRole === "owner"
    : user.globalRole === "owner" || user.globalRole === "group_admin";
  if (!allowed) {
    throw new AppError(ownerOnly ? "Only the Owner can do this." : "Only the Owner or a Group Administrator can do this.");
  }
}

function flashResult(path: string, result: { ok: true } | { ok: false; error: string }, okMessage: string): never {
  return redirect(result.ok ? flashUrl(path, "notice", okMessage) : flashUrl(path, "error", result.error));
}

// ---------- Companies ----------
const companySchema = z.object({
  name: z.string().trim().min(2, "Enter the company name.").max(150, "Name is too long."),
  legalName: z.string().trim().max(200).optional(),
  businessType: oneOf(BUSINESS_TYPE_KEYS, "Choose a business type."),
  phone: z.string().trim().max(40).optional(),
  email: z.string().trim().max(190).optional(),
  website: z.string().trim().max(190).optional(),
  address: z.string().trim().max(400).optional(),
  city: z.string().trim().max(100).optional(),
});

export async function createCompany(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const parsed = companySchema.safeParse({
    name: readText(values, "name"),
    legalName: readText(values, "legalName"),
    businessType: readText(values, "businessType"),
    phone: readText(values, "phone"),
    email: readText(values, "email"),
    website: readText(values, "website"),
    address: readText(values, "address"),
    city: readText(values, "city"),
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const d = parsed.data;

  const result = await safeAction(async () => {
    requireGlobalAdmin(await currentUser());
    const existing = await db
      .select({ id: companies.id })
      .from(companies)
      .where(sql`lower(${companies.name}) = lower(${d.name})`)
      .limit(1);
    if (existing.length > 0) {
      throw new AppError("A company with this name already exists.", { name: "This name is already used." });
    }
    const user = await currentUser();
    const [created] = await db
      .insert(companies)
      .values({
        name: d.name,
        legalName: d.legalName || null,
        businessType: d.businessType as BusinessType,
        phone: d.phone || null,
        email: d.email || null,
        website: d.website || null,
        address: d.address || null,
        city: d.city || null,
        enabledModules: [...TOGGLEABLE_MODULE_KEYS],
        createdById: user.id,
      })
      .returning({ id: companies.id });
    await db
      .insert(expenseCategories)
      .values(DEFAULT_EXPENSE_CATEGORIES.map((name) => ({ companyId: created.id, name })))
      .onConflictDoNothing();
    await logAudit({
      companyId: created.id,
      userId: user.id,
      action: "company.created",
      entityType: "company",
      entityId: created.id,
      summary: `Company "${d.name}" created`,
    });
    return created.id;
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  redirect(flashUrl(`/c/${result.data}/settings`, "notice", "Company created. Now add the logo, numbering and branches."));
}

export async function seedPortfolioCompanies(): Promise<void> {
  const result = await safeAction(async () => {
    const user = await currentUser();
    requireGlobalAdmin(user);
    const existing = await db.select({ name: companies.name }).from(companies);
    const existingNames = new Set(existing.map((row) => row.name.toLowerCase()));
    let added = 0;
    for (const item of PORTFOLIO_COMPANIES) {
      if (existingNames.has(item.name.toLowerCase())) continue;
      const [created] = await db
        .insert(companies)
        .values({ name: item.name, businessType: item.businessType, enabledModules: [...TOGGLEABLE_MODULE_KEYS], createdById: user.id })
        .returning({ id: companies.id });
      await db
        .insert(expenseCategories)
        .values(DEFAULT_EXPENSE_CATEGORIES.map((name) => ({ companyId: created.id, name })))
        .onConflictDoNothing();
      added += 1;
    }
    await logAudit({
      userId: user.id,
      action: "company.portfolio_seeded",
      entityType: "company",
      summary: `Added ${added} portfolio companies`,
    });
    return added;
  });
  if (result.ok) {
    refreshAll();
    redirect(flashUrl("/companies", "notice", `Added ${result.data} business workspace(s). Existing ones were not changed.`));
  }
  redirect(flashUrl("/companies", "error", result.error));
}

const profileSchema = z.object({
  name: z.string().trim().min(2, "Enter the company name.").max(150),
  legalName: z.string().trim().max(200).optional(),
  businessType: oneOf(BUSINESS_TYPE_KEYS, "Choose a business type."),
  registrationNo: z.string().trim().max(80).optional(),
  taxId: z.string().trim().max(80).optional(),
  phone: z.string().trim().max(40).optional(),
  email: z.string().trim().max(190).optional(),
  website: z.string().trim().max(190).optional(),
  address: z.string().trim().max(400).optional(),
  city: z.string().trim().max(100).optional(),
  brandColor: z.string().regex(/^#[0-9a-fA-F]{6}$/, "Use a colour code such as #0f766e."),
  invoicePrefix: z.string().regex(PREFIX_PATTERN, "Use 1 to 12 capital letters, numbers or dashes."),
  quotationPrefix: z.string().regex(PREFIX_PATTERN, "Use 1 to 12 capital letters, numbers or dashes."),
  receiptPrefix: z.string().regex(PREFIX_PATTERN, "Use 1 to 12 capital letters, numbers or dashes."),
  visaPrefix: z.string().regex(PREFIX_PATTERN, "Use 1 to 12 capital letters, numbers or dashes."),
  invoiceFooter: z.string().trim().max(500).optional(),
  receiptFooter: z.string().trim().max(500).optional(),
  financialYearStartMonth: z.coerce.number().int().min(1, "Choose a month.").max(12, "Choose a month."),
  shiftStart: z.string().regex(TIME_PATTERN, "Use a time such as 09:00."),
  shiftEnd: z.string().regex(TIME_PATTERN, "Use a time such as 18:00."),
  graceMinutes: z.coerce.number().int().min(0, "Use 0 or more.").max(120, "Use 120 or less."),
});

export async function updateCompanyProfile(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("This company could not be identified. Please reload the page.");
  const upper = (key: string) => readText(values, key).toUpperCase();
  const parsed = profileSchema.safeParse({
    name: readText(values, "name"),
    legalName: readText(values, "legalName"),
    businessType: readText(values, "businessType"),
    registrationNo: readText(values, "registrationNo"),
    taxId: readText(values, "taxId"),
    phone: readText(values, "phone"),
    email: readText(values, "email"),
    website: readText(values, "website"),
    address: readText(values, "address"),
    city: readText(values, "city"),
    brandColor: readText(values, "brandColor") || "#0f766e",
    invoicePrefix: upper("invoicePrefix"),
    quotationPrefix: upper("quotationPrefix"),
    receiptPrefix: upper("receiptPrefix"),
    visaPrefix: upper("visaPrefix"),
    invoiceFooter: readText(values, "invoiceFooter"),
    receiptFooter: readText(values, "receiptFooter"),
    financialYearStartMonth: readText(values, "financialYearStartMonth") || "7",
    shiftStart: readText(values, "shiftStart"),
    shiftEnd: readText(values, "shiftEnd"),
    graceMinutes: readText(values, "graceMinutes") || "10",
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const d = parsed.data;

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "company", "edit");
    const duplicate = await db
      .select({ id: companies.id })
      .from(companies)
      .where(and(sql`lower(${companies.name}) = lower(${d.name})`, sql`${companies.id} <> ${companyId}`))
      .limit(1);
    if (duplicate.length > 0) throw new AppError("Another company already uses this name.", { name: "This name is already used." });
    await db
      .update(companies)
      .set({
        name: d.name,
        legalName: d.legalName || null,
        businessType: d.businessType as BusinessType,
        registrationNo: d.registrationNo || null,
        taxId: d.taxId || null,
        phone: d.phone || null,
        email: d.email || null,
        website: d.website || null,
        address: d.address || null,
        city: d.city || null,
        brandColor: d.brandColor,
        invoicePrefix: d.invoicePrefix,
        quotationPrefix: d.quotationPrefix,
        receiptPrefix: d.receiptPrefix,
        visaPrefix: d.visaPrefix,
        invoiceFooter: d.invoiceFooter || null,
        receiptFooter: d.receiptFooter || null,
        financialYearStartMonth: d.financialYearStartMonth,
        shiftStart: d.shiftStart,
        shiftEnd: d.shiftEnd,
        graceMinutes: d.graceMinutes,
        updatedAt: new Date(),
      })
      .where(eq(companies.id, companyId));
    await logAudit({
      companyId,
      userId: ctx.user.id,
      action: "company.updated",
      entityType: "company",
      entityId: companyId,
      summary: `Company profile and settings updated for "${d.name}"`,
    });
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Company profile saved.");
}

export async function updateCompanyModules(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("This company could not be identified. Please reload the page.");
  const enabled = TOGGLEABLE_MODULE_KEYS.filter((key) => readFlag(values, `module_${key}`));
  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "company", "edit");
    await db.update(companies).set({ enabledModules: enabled, updatedAt: new Date() }).where(eq(companies.id, companyId));
    await logAudit({
      companyId,
      userId: ctx.user.id,
      action: "company.modules_changed",
      entityType: "company",
      entityId: companyId,
      summary: `Enabled modules: ${enabled.join(", ") || "none"}`,
    });
  });
  if (!result.ok) return failure(result.error);
  refreshAll();
  return success("Module settings saved. Menus will update the next time you open the page.");
}

export async function setCompanyActive(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const active = String(formData.get("active")) === "1";
  const result = await safeAction(async () => {
    const user = await currentUser();
    requireGlobalAdmin(user);
    if (!companyId) throw new AppError("Company not found.");
    await db.update(companies).set({ isActive: active, updatedAt: new Date() }).where(eq(companies.id, companyId));
    await logAudit({
      companyId,
      userId: user.id,
      action: active ? "company.activated" : "company.deactivated",
      entityType: "company",
      entityId: companyId,
      summary: active ? "Company reactivated" : "Company deactivated (data is kept)",
    });
  });
  refreshAll();
  flashResult("/companies", result, active ? "Company is active again." : "Company deactivated. Its data is kept safe.");
}

// ---------- Branches and departments ----------
const branchSchema = z.object({
  name: z.string().trim().min(2, "Enter a branch name.").max(120),
  address: z.string().trim().max(300).optional(),
  phone: z.string().trim().max(40).optional(),
});

export async function createBranch(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found.");
  const parsed = branchSchema.safeParse({
    name: readText(values, "name"),
    address: readText(values, "address"),
    phone: readText(values, "phone"),
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "company", "edit");
    await db.insert(branches).values({
      companyId,
      name: parsed.data.name,
      address: parsed.data.address || null,
      phone: normalizePhone(parsed.data.phone) ?? null,
    });
    await logAudit({
      companyId,
      userId: ctx.user.id,
      action: "branch.created",
      entityType: "branch",
      summary: `Branch "${parsed.data.name}" added`,
    });
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success(`Branch "${parsed.data.name}" added.`);
}

export async function toggleBranch(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const branchId = parseId(String(formData.get("branchId") ?? ""));
  const active = String(formData.get("active")) === "1";
  const result = await safeAction(async () => {
    if (!companyId || !branchId) throw new AppError("Branch not found.");
    await requireAccess(companyId, "company", "edit");
    await db
      .update(branches)
      .set({ isActive: active, updatedAt: new Date() })
      .where(and(eq(branches.id, branchId), eq(branches.companyId, companyId)));
  });
  refreshAll();
  flashResult(`/c/${companyId}/settings/structure`, result, active ? "Branch re-opened." : "Branch closed. Its records are kept.");
}

const departmentSchema = z.object({
  name: z.string().trim().min(2, "Enter a department name.").max(120),
  description: z.string().trim().max(300).optional(),
});

export async function createDepartment(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  if (!companyId) return failure("Company not found.");
  const parsed = departmentSchema.safeParse({ name: readText(values, "name"), description: readText(values, "description") });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "company", "edit");
    await db.insert(departments).values({
      companyId,
      name: parsed.data.name,
      description: parsed.data.description || null,
    });
    await logAudit({
      companyId,
      userId: ctx.user.id,
      action: "department.created",
      entityType: "department",
      summary: `Department "${parsed.data.name}" added`,
    });
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success(`Department "${parsed.data.name}" added.`);
}

export async function toggleDepartment(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const departmentId = parseId(String(formData.get("departmentId") ?? ""));
  const active = String(formData.get("active")) === "1";
  const result = await safeAction(async () => {
    if (!companyId || !departmentId) throw new AppError("Department not found.");
    await requireAccess(companyId, "company", "edit");
    await db
      .update(departments)
      .set({ isActive: active, updatedAt: new Date() })
      .where(and(eq(departments.id, departmentId), eq(departments.companyId, companyId)));
  });
  refreshAll();
  flashResult(`/c/${companyId}/settings/structure`, result, active ? "Department re-opened." : "Department closed.");
}

// ---------- Team access (who works in which company, with which role) ----------
const PERMISSION_KEY_SET = new Set<string>([...ALL_PERMISSION_KEYS, ...MODULE_KEYS.map((m) => `${m}.manage`)]);

function parsePermissionList(raw: string): { keys: string[]; invalid: string[] } {
  const items = raw
    .split(/[,\s]+/)
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean);
  const keys: string[] = [];
  const invalid: string[] = [];
  for (const item of items) {
    if (PERMISSION_KEY_SET.has(item)) keys.push(item);
    else invalid.push(item);
  }
  return { keys: [...new Set(keys)], invalid };
}

export async function assignTeamAccess(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const companyId = parseId(values.companyId);
  const userId = parseId(values.userId);
  const roleId = parseId(values.roleId);
  const branchId = parseId(values.branchId);
  const departmentId = parseId(values.departmentId);
  if (!companyId) return failure("Company not found.");
  if (!userId) return failure("Choose a person.", values, { userId: "Choose a person." });
  if (!roleId) return failure("Choose a role.", values, { roleId: "Choose a role." });

  const grant = parsePermissionList(readText(values, "grants"));
  const revoke = parsePermissionList(readText(values, "revokes"));
  const invalid = [...grant.invalid, ...revoke.invalid];
  if (invalid.length > 0) {
    return failure(`These permission names are not recognised: ${invalid.join(", ")}.`, values, { grants: "Check the names." });
  }

  const result = await safeAction(async () => {
    const ctx = await requireAccess(companyId, "team", "manage");
    const [person] = await db.select({ id: users.id, isActive: users.isActive }).from(users).where(eq(users.id, userId)).limit(1);
    if (!person || !person.isActive) throw new AppError("This person is not an active user.", { userId: "Not an active user." });
    const [role] = await db.select({ id: roles.id, name: roles.name }).from(roles).where(and(eq(roles.id, roleId), eq(roles.isActive, true))).limit(1);
    if (!role) throw new AppError("This role does not exist.", { roleId: "Choose a valid role." });
    if (branchId) {
      const [b] = await db.select({ id: branches.id }).from(branches).where(and(eq(branches.id, branchId), eq(branches.companyId, companyId))).limit(1);
      if (!b) throw new AppError("The branch does not belong to this company.", { branchId: "Choose a branch of this company." });
    }
    if (departmentId) {
      const [d] = await db.select({ id: departments.id }).from(departments).where(and(eq(departments.id, departmentId), eq(departments.companyId, companyId))).limit(1);
      if (!d) throw new AppError("The department does not belong to this company.", { departmentId: "Choose a department of this company." });
    }

    await db
      .insert(userCompanyAccess)
      .values({
        userId,
        companyId,
        roleId,
        branchId: branchId ?? null,
        departmentId: departmentId ?? null,
        overrides: { grant: grant.keys, revoke: revoke.keys },
        isActive: true,
      })
      .onConflictDoUpdate({
        target: [userCompanyAccess.userId, userCompanyAccess.companyId],
        set: {
          roleId,
          branchId: branchId ?? null,
          departmentId: departmentId ?? null,
          overrides: { grant: grant.keys, revoke: revoke.keys },
          isActive: true,
          updatedAt: new Date(),
        },
      });

    const [company] = await db.select({ name: companies.name }).from(companies).where(eq(companies.id, companyId)).limit(1);
    await notify(userId, {
      companyId,
      title: "Your access has been updated",
      body: `You now have the "${role.name}" role in ${company?.name ?? "a company"}.`,
      link: `/c/${companyId}`,
    });
    await logAudit({
      companyId,
      userId: ctx.user.id,
      action: "team.access_assigned",
      entityType: "user",
      entityId: userId,
      summary: `Access set to role "${role.name}"${grant.keys.length ? `, extra: ${grant.keys.join(", ")}` : ""}${revoke.keys.length ? `, removed: ${revoke.keys.join(", ")}` : ""}`,
    });
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success("Access saved.");
}

export async function removeTeamAccess(formData: FormData): Promise<void> {
  const companyId = parseId(String(formData.get("companyId") ?? ""));
  const userId = parseId(String(formData.get("userId") ?? ""));
  const result = await safeAction(async () => {
    if (!companyId || !userId) throw new AppError("Access record not found.");
    const ctx = await requireAccess(companyId, "team", "manage");
    await db
      .update(userCompanyAccess)
      .set({ isActive: false, updatedAt: new Date() })
      .where(and(eq(userCompanyAccess.userId, userId), eq(userCompanyAccess.companyId, companyId)));
    await logAudit({
      companyId,
      userId: ctx.user.id,
      action: "team.access_removed",
      entityType: "user",
      entityId: userId,
      summary: "Company access removed (history kept)",
    });
  });
  refreshAll();
  flashResult(`/c/${companyId}/team`, result, "Access removed. Past records are kept.");
}

// ---------- Global user accounts (Owner and Group Administrator) ----------
const userSchema = z.object({
  fullName: z.string().trim().min(2, "Enter the full name.").max(120),
  email: z.email("Enter a valid email address.").max(190),
  phone: z.string().trim().max(40).optional(),
  globalRole: oneOf(GLOBAL_ROLE_KEYS, "Choose a role."),
  tempPassword: passwordSchema,
});

export async function createUserAccount(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const parsed = userSchema.safeParse({
    fullName: readText(values, "fullName"),
    email: readText(values, "email"),
    phone: readText(values, "phone"),
    globalRole: readText(values, "globalRole") || "staff",
    tempPassword: values.tempPassword ?? "",
  });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));
  const d = parsed.data;
  const email = normalizeEmail(d.email) ?? d.email;

  const result = await safeAction(async () => {
    const user = await currentUser();
    requireGlobalAdmin(user);
    if (d.globalRole !== "staff" && user.globalRole !== "owner") {
      throw new AppError("Only the Owner can create Owner or Group Administrator accounts.", { globalRole: "Only the Owner can choose this." });
    }
    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing) throw new AppError("An account with this email already exists.", { email: "This email is already registered." });
    const passwordHash = await hashPassword(d.tempPassword);
    const [created] = await db
      .insert(users)
      .values({
        fullName: d.fullName,
        email,
        phone: normalizePhone(d.phone) ?? null,
        passwordHash,
        globalRole: d.globalRole as GlobalRole,
        mustChangePassword: true,
      })
      .returning({ id: users.id });
    await logAudit({
      userId: user.id,
      action: "user.created",
      entityType: "user",
      entityId: created.id,
      summary: `Account created for ${email} (${d.globalRole})`,
    });
  });

  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success(`Account created for ${email}. Give them the temporary password; they must change it at first sign-in.`);
}

export async function resetUserPassword(formData: FormData): Promise<void> {
  const userId = parseId(String(formData.get("userId") ?? ""));
  const tempPassword = String(formData.get("tempPassword") ?? "");
  const check = passwordSchema.safeParse(tempPassword);
  const result = await safeAction(async () => {
    const actor = await currentUser();
    requireGlobalAdmin(actor);
    if (!userId) throw new AppError("User not found.");
    if (!check.success) throw new AppError(check.error.issues[0]?.message ?? "The temporary password is not strong enough.");
    const [target] = await db.select({ id: users.id, globalRole: users.globalRole }).from(users).where(eq(users.id, userId)).limit(1);
    if (!target) throw new AppError("User not found.");
    if (target.globalRole === "owner" && actor.globalRole !== "owner") throw new AppError("Only the Owner can reset the Owner's password.");
    await db
      .update(users)
      .set({ passwordHash: await hashPassword(tempPassword), mustChangePassword: true, failedLoginCount: 0, lockedUntil: null, updatedAt: new Date() })
      .where(eq(users.id, userId));
    await revokeUserSessions(userId);
    await logAudit({
      userId: actor.id,
      action: "user.password_reset",
      entityType: "user",
      entityId: userId,
      summary: "Temporary password set; user signed out everywhere",
    });
  });
  refreshAll();
  flashResult("/admin/users", result, "Temporary password set. The person has been signed out everywhere and must change it.");
}

export async function setUserActive(formData: FormData): Promise<void> {
  const userId = parseId(String(formData.get("userId") ?? ""));
  const active = String(formData.get("active")) === "1";
  const result = await safeAction(async () => {
    const actor = await currentUser();
    requireGlobalAdmin(actor);
    if (!userId) throw new AppError("User not found.");
    if (userId === actor.id) throw new AppError("You cannot switch off your own account.");
    const [target] = await db.select({ globalRole: users.globalRole }).from(users).where(eq(users.id, userId)).limit(1);
    if (target?.globalRole === "owner" && actor.globalRole !== "owner") throw new AppError("Only the Owner can change the Owner account.");
    await db.update(users).set({ isActive: active, updatedAt: new Date() }).where(eq(users.id, userId));
    if (!active) await revokeUserSessions(userId);
    await logAudit({
      userId: actor.id,
      action: active ? "user.activated" : "user.deactivated",
      entityType: "user",
      entityId: userId,
      summary: active ? "Account switched on" : "Account switched off and signed out",
    });
  });
  refreshAll();
  flashResult("/admin/users", result, active ? "Account switched on." : "Account switched off. The person has been signed out.");
}

export async function setUserGlobalRole(formData: FormData): Promise<void> {
  const userId = parseId(String(formData.get("userId") ?? ""));
  const role = String(formData.get("globalRole") ?? "");
  const result = await safeAction(async () => {
    const actor = await currentUser();
    requireGlobalAdmin(actor, true);
    if (!userId) throw new AppError("User not found.");
    if (userId === actor.id) throw new AppError("You cannot change your own top-level role.");
    if (!(GLOBAL_ROLE_KEYS as readonly string[]).includes(role)) throw new AppError("Choose a valid role.");
    await db.update(users).set({ globalRole: role as GlobalRole, updatedAt: new Date() }).where(eq(users.id, userId));
    await logAudit({
      userId: actor.id,
      action: "user.global_role_changed",
      entityType: "user",
      entityId: userId,
      summary: `Top-level role changed to ${role}`,
    });
  });
  refreshAll();
  flashResult("/admin/users", result, "Role updated.");
}

// ---------- Custom roles ----------
const roleSchema = z.object({
  name: z.string().trim().min(3, "Enter a role name (at least 3 letters).").max(80),
  description: z.string().trim().max(300).optional(),
});

export async function createCustomRole(_prev: FormState, formData: FormData): Promise<FormState> {
  const values = formValues(formData);
  const parsed = roleSchema.safeParse({ name: readText(values, "name"), description: readText(values, "description") });
  if (!parsed.success) return failure("Please check the highlighted fields.", values, zodFieldErrors(parsed.error));

  const permissions: string[] = [];
  for (const [key, value] of Object.entries(values)) {
    if (!key.startsWith("p_") || value !== "on") continue;
    const rest = key.slice(2);
    const index = rest.lastIndexOf("_");
    const moduleKey = rest.slice(0, index);
    const action = rest.slice(index + 1);
    if ((MODULE_KEYS as readonly string[]).includes(moduleKey) && (ACTION_KEYS as readonly string[]).includes(action)) {
      permissions.push(`${moduleKey}.${action}`);
    }
  }
  if (permissions.length === 0) return failure("Select at least one permission for this role.", values, { name: "Tick at least one permission below." });

  const result = await safeAction(async () => {
    const user = await currentUser();
    requireGlobalAdmin(user, true);
    await ensureSystemRoles();
    const slug = parsed.data.name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "").slice(0, 30);
    const key = `custom_${slug}_${randomBytes(3).toString("hex")}`;
    await db.insert(roles).values({
      key,
      name: parsed.data.name,
      description: parsed.data.description || null,
      permissions: [...new Set(permissions)],
      isSystem: false,
    });
    await logAudit({
      userId: user.id,
      action: "role.created",
      entityType: "role",
      entityId: key,
      summary: `Custom role "${parsed.data.name}" created with ${permissions.length} permissions`,
    });
  });
  if (!result.ok) return failure(result.error, values, result.fieldErrors);
  refreshAll();
  return success(`Role "${parsed.data.name}" created. You can now give it to people from a company's Team page.`);
}

export async function deleteCustomRole(formData: FormData): Promise<void> {
  const roleId = parseId(String(formData.get("roleId") ?? ""));
  const result = await safeAction(async () => {
    const user = await currentUser();
    requireGlobalAdmin(user, true);
    if (!roleId) throw new AppError("Role not found.");
    const [role] = await db.select().from(roles).where(eq(roles.id, roleId)).limit(1);
    if (!role) throw new AppError("Role not found.");
    if (role.isSystem) throw new AppError("Built-in roles cannot be deleted.");
    const inUse = await db
      .select({ id: userCompanyAccess.id })
      .from(userCompanyAccess)
      .where(and(eq(userCompanyAccess.roleId, roleId), eq(userCompanyAccess.isActive, true)))
      .limit(1);
    if (inUse.length > 0) throw new AppError("This role is still given to people. Remove it from them first.");
    await db.delete(roles).where(eq(roles.id, roleId));
    await logAudit({
      userId: user.id,
      action: "role.deleted",
      entityType: "role",
      entityId: roleId,
      summary: `Custom role "${role.name}" deleted`,
    });
  });
  refreshAll();
  flashResult("/admin/roles", result, "Role deleted.");
}



// CSV exports. Each export checks the export permission, respects branch limits, never includes salary
// unless the salary permission is held, and is recorded in the audit log.
import { and, asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { attendance, branches, cashAccounts, companies, customers, departments, employees, expenseCategories, expenses, invoices, leads, receipts, users, visaApplications } from "@/db/schema";
import { logAudit } from "@/lib/audit";
import { getSessionUser } from "@/lib/auth";
import { toCsv } from "@/lib/csv";
import { formatDate, maskIdentifier, parseId, todayISO } from "@/lib/format";
import { branchWhere, getAccess, type AccessContext } from "@/lib/permissions";
import type { ModuleKey } from "@/lib/constants";

export const dynamic = "force-dynamic";

const LIMIT = 5000;
const TYPE_PERMISSION: Record<string, ModuleKey> = {
  leads: "crm",
  customers: "crm",
  invoices: "accounting",
  receipts: "accounting",
  expenses: "accounting",
  visa: "visa",
  employees: "hr",
  attendance: "hr",
};

type Dataset = { headers: string[]; rows: (string | number | null)[][] };

async function buildDataset(type: string, companyId: number, ctx: AccessContext): Promise<Dataset> {
  const showSalary = ctx.can("hr_salary", "view");
  const canSeePassport = ctx.can("documents", "view");
  switch (type) {
    case "leads": {
      const rows = await db
        .select({ l: leads, assignee: users.fullName })
        .from(leads)
        .leftJoin(users, eq(users.id, leads.assignedUserId))
        .where(and(eq(leads.companyId, companyId), branchWhere(ctx, leads.branchId)))
        .orderBy(desc(leads.createdAt))
        .limit(LIMIT);
      return {
        headers: ["Code", "Name", "Phone", "Email", "City", "Source", "Interested in", "Status", "Expected value (BDT)", "Assigned to", "Added"],
        rows: rows.map(({ l, assignee }) => [l.code, l.fullName, l.phone, l.email, l.city, l.leadSource, l.interestedService, l.status, l.expectedValue, assignee, formatDate(l.createdAt)]),
      };
    }
    case "customers": {
      const rows = await db
        .select({ c: customers, assignee: users.fullName })
        .from(customers)
        .leftJoin(users, eq(users.id, customers.assignedUserId))
        .where(and(eq(customers.companyId, companyId), eq(customers.isArchived, false), branchWhere(ctx, customers.branchId)))
        .orderBy(asc(customers.fullName))
        .limit(LIMIT);
      return {
        headers: ["Code", "Name", "Phone", "Email", "City", "Country", "Category", "Passport number", "Passport expiry", "Relationship manager", "Since"],
        rows: rows.map(({ c, assignee }) => [c.code, c.fullName, c.phone, c.email, c.city, c.country, c.category, canSeePassport ? c.passportNumber : maskIdentifier(c.passportNumber), c.passportExpiry, assignee, formatDate(c.createdAt)]),
      };
    }
    case "invoices": {
      const rows = await db
        .select({ inv: invoices, customerName: customers.fullName })
        .from(invoices)
        .innerJoin(customers, eq(customers.id, invoices.customerId))
        .where(and(eq(invoices.companyId, companyId), branchWhere(ctx, invoices.branchId)))
        .orderBy(desc(invoices.issueDate))
        .limit(LIMIT);
      return {
        headers: ["Type", "Number", "Issue date", "Due date", "Customer", "Subtotal", "Tax", "Discount", "Total", "Paid", "Due", "Status", "Reference"],
        rows: rows.map(({ inv, customerName }) => [inv.docType, inv.number, inv.issueDate, inv.dueDate, customerName, inv.subtotal, inv.taxAmount, inv.discountAmount, inv.total, inv.paidAmount, inv.dueAmount, inv.status, inv.serviceReference]),
      };
    }
    case "receipts": {
      const rows = await db
        .select({ r: receipts, customerName: customers.fullName, accountName: cashAccounts.name })
        .from(receipts)
        .innerJoin(customers, eq(customers.id, receipts.customerId))
        .leftJoin(cashAccounts, eq(cashAccounts.id, receipts.accountId))
        .where(and(eq(receipts.companyId, companyId), branchWhere(ctx, receipts.branchId)))
        .orderBy(desc(receipts.receiptDate))
        .limit(LIMIT);
      return {
        headers: ["Receipt", "Date", "Customer", "Type", "Amount", "Method", "Transaction ID", "Account", "Status", "Cancel reason", "Times printed"],
        rows: rows.map(({ r, customerName, accountName }) => [r.number, r.receiptDate, customerName, r.kind, r.amount, r.paymentMethod, r.transactionRef, accountName, r.status, r.cancelReason, r.reprintCount]),
      };
    }
    case "expenses": {
      const rows = await db
        .select({ e: expenses, categoryName: expenseCategories.name, requester: users.fullName })
        .from(expenses)
        .innerJoin(expenseCategories, eq(expenseCategories.id, expenses.categoryId))
        .leftJoin(users, eq(users.id, expenses.createdById))
        .where(and(eq(expenses.companyId, companyId), branchWhere(ctx, expenses.branchId)))
        .orderBy(desc(expenses.expenseDate))
        .limit(LIMIT);
      return {
        headers: ["Date", "Category", "Description", "Paid to", "Amount", "Method", "Reference", "Status", "Requested by"],
        rows: rows.map(({ e, categoryName, requester }) => [e.expenseDate, categoryName, e.description, e.payeeName, e.amount, e.paymentMethod, e.reference, e.status, requester]),
      };
    }
    case "visa": {
      const rows = await db
        .select({ v: visaApplications, customerName: customers.fullName, officer: users.fullName })
        .from(visaApplications)
        .innerJoin(customers, eq(customers.id, visaApplications.customerId))
        .leftJoin(users, eq(users.id, visaApplications.assignedUserId))
        .where(and(eq(visaApplications.companyId, companyId), branchWhere(ctx, visaApplications.branchId)))
        .orderBy(desc(visaApplications.applicationDate))
        .limit(LIMIT);
      return {
        headers: ["File", "Customer", "Destination", "Category", "Status", "Application date", "Submitted", "Appointment", "Decision date", "Valid until", "Officer", "Service fee"],
        rows: rows.map(({ v, customerName, officer }) => [v.code, customerName, v.destinationCountry, v.visaCategory, v.status, v.applicationDate, v.submissionDate, v.appointmentAt?.toISOString() ?? null, v.approvalDate, v.validUntil, officer, v.serviceFee]),
      };
    }
    case "employees": {
      const rows = await db
        .select({ e: employees, departmentName: departments.name, branchName: branches.name })
        .from(employees)
        .leftJoin(departments, eq(departments.id, employees.departmentId))
        .leftJoin(branches, eq(branches.id, employees.branchId))
        .where(and(eq(employees.companyId, companyId), branchWhere(ctx, employees.branchId)))
        .orderBy(asc(employees.fullName))
        .limit(LIMIT);
      const headers = ["Code", "Name", "Designation", "Department", "Branch", "Joined", "Status", "Phone", "Email"];
      if (showSalary) headers.push("Basic salary (BDT)");
      return {
        headers,
        rows: rows.map(({ e, departmentName, branchName }) => {
          const base: (string | number | null)[] = [e.code, e.fullName, e.designation, departmentName, branchName, e.joinDate, e.employmentStatus, e.phone, e.email];
          if (showSalary) base.push(e.basicSalary);
          return base;
        }),
      };
    }
    case "attendance": {
      const rows = await db
        .select({ a: attendance, code: employees.code, name: employees.fullName, branchId: employees.branchId })
        .from(attendance)
        .innerJoin(employees, eq(employees.id, attendance.employeeId))
        .where(and(eq(attendance.companyId, companyId), branchWhere(ctx, employees.branchId)))
        .orderBy(desc(attendance.attendanceDate))
        .limit(LIMIT);
      return {
        headers: ["Date", "Employee code", "Employee", "Status", "Check-in", "Check-out", "Late (minutes)", "Left early (minutes)"],
        rows: rows.map(({ a, code, name }) => [a.attendanceDate, code, name, a.status, a.checkIn, a.checkOut, a.lateMinutes, a.earlyLeaveMinutes]),
      };
    }
    default:
      return { headers: [], rows: [] };
  }
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const companyId = parseId(url.searchParams.get("companyId"));
  const type = url.searchParams.get("type") ?? "";
  if (!companyId || !Object.hasOwn(TYPE_PERMISSION, type)) return new Response("Invalid export request.", { status: 400 });

  const user = await getSessionUser();
  if (!user) return new Response("Please sign in first.", { status: 401 });
  const ctx = await getAccess(companyId);
  if (!ctx) return new Response("Not found", { status: 404 });
  if (!ctx.can(TYPE_PERMISSION[type], "export")) return new Response("You do not have permission to export this data.", { status: 403 });

  const dataset = await buildDataset(type, companyId, ctx);
  await logAudit({
    companyId,
    userId: user.id,
    action: "export.csv",
    entityType: type,
    summary: `Exported ${dataset.rows.length} ${type} row(s) to CSV`,
  });

  const [company] = await db.select({ name: companies.name }).from(companies).where(eq(companies.id, companyId)).limit(1);
  const safeName = (company?.name ?? "company").replace(/[^a-z0-9]+/gi, "-").toLowerCase();
  const csv = "\uFEFF" + toCsv(dataset.headers, dataset.rows);
  return new Response(csv, {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${safeName}-${type}-${todayISO()}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}

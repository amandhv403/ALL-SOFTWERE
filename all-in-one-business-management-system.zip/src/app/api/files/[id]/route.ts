// Serves private files (passports, visa documents, contracts, logos) only to people who are allowed to see them.
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { customers, documents, employees, expenses, visaApplications } from "@/db/schema";
import { logAudit } from "@/lib/audit";
import { getSessionUser } from "@/lib/auth";
import { parseId } from "@/lib/format";
import { getAccess, inBranchScope } from "@/lib/permissions";
import { readUpload } from "@/lib/storage";
import type { ModuleKey } from "@/lib/constants";

export const dynamic = "force-dynamic";

async function linkedBranchId(doc: typeof documents.$inferSelect): Promise<number | null | undefined> {
  if (doc.customerId) {
    const [row] = await db.select({ branchId: customers.branchId }).from(customers).where(eq(customers.id, doc.customerId)).limit(1);
    return row?.branchId ?? null;
  }
  if (doc.visaApplicationId) {
    const [row] = await db.select({ branchId: visaApplications.branchId }).from(visaApplications).where(eq(visaApplications.id, doc.visaApplicationId)).limit(1);
    return row?.branchId ?? null;
  }
  if (doc.employeeId) {
    const [row] = await db.select({ branchId: employees.branchId }).from(employees).where(eq(employees.id, doc.employeeId)).limit(1);
    return row?.branchId ?? null;
  }
  if (doc.expenseId) {
    const [row] = await db.select({ branchId: expenses.branchId }).from(expenses).where(eq(expenses.id, doc.expenseId)).limit(1);
    return row?.branchId ?? null;
  }
  return null;
}

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id: rawId } = await context.params;
  const id = parseId(rawId);
  if (!id) return new Response("Not found", { status: 404 });

  const user = await getSessionUser();
  if (!user) return new Response("Please sign in to view this file.", { status: 401 });

  const [doc] = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
  if (!doc) return new Response("Not found", { status: 404 });

  // Anyone outside the company gets the same answer as "not found", so file existence is never revealed.
  const ctx = await getAccess(doc.companyId);
  if (!ctx) return new Response("Not found", { status: 404 });

  // Company logos appear on printed invoices and receipts, so anyone with access to the company may view them.
  const isLogo = doc.category === "logo";
  const moduleKey: ModuleKey = doc.module === "general" ? "documents" : doc.module;
  if (!isLogo && (!ctx.can("documents", "view") || !ctx.can(moduleKey, "view"))) {
    return new Response("You do not have permission to open this file.", { status: 403 });
  }
  if (ctx.branchId) {
    const branch = await linkedBranchId(doc);
    if (branch !== null && branch !== undefined && !inBranchScope(ctx, branch)) {
      return new Response("Not found", { status: 404 });
    }
  }

  let buffer: Buffer;
  try {
    buffer = await readUpload(doc.storageKey);
  } catch {
    return new Response("The file could not be found on the server.", { status: 404 });
  }

  const download = new URL(request.url).searchParams.get("download") === "1";
  if (doc.isSensitive || download) {
    await logAudit({
      companyId: doc.companyId,
      userId: user.id,
      action: download ? "document.downloaded" : "document.viewed",
      entityType: "document",
      entityId: doc.id,
      summary: `${download ? "Downloaded" : "Opened"} ${doc.category} file: ${doc.title}`,
    });
  }

  return new Response(new Uint8Array(buffer), {
    status: 200,
    headers: {
      "Content-Type": doc.mimeType,
      "Content-Length": String(buffer.length),
      "Content-Disposition": `${download ? "attachment" : "inline"}; filename*=UTF-8''${encodeURIComponent(doc.fileName)}`,
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}

# Database Schema

The complete definition is in `src/db/schema.ts`. This page summarises the main tables and how they connect. Every business table has `company_id` (except the global identity and role tables).

## Identity and access

| Table | Purpose | Key links |
|---|---|---|
| `users` | Sign-in accounts, top-level role (owner, group_admin, staff), lockout counters | — |
| `sessions` | Active sign-ins (token hash only) | → users |
| `companies` | Each business workspace: profile, branding, numbering prefixes, working hours, enabled modules | — |
| `branches` | Offices or locations | → companies |
| `departments` | Teams | → companies |
| `roles` | Built-in and custom roles with a list of permissions | — |
| `user_company_access` | Who works in which company, with which role, branch, department and individual grants and revokes | → users, companies, roles, branches, departments |
| `number_sequences` | Counters for document numbers per company | → companies |

## CRM and sales

| Table | Purpose |
|---|---|
| `customers` | One profile per customer (contact, passport details, category, relationship manager, consent) |
| `leads` | Enquiries, with status, source, campaign, expected value, conversion link to a customer |
| `follow_ups` | Scheduled tasks linked to a lead or customer |
| `activities` | Timeline entries (calls, notes, status changes, system events) |
| `campaigns` | Marketing campaigns with budget and channel |
| `targets` | Goals by measure, period and scope (company, branch, department, person) |
| `services` | Catalogue of services and products with default price and tax |

## Accounting

| Table | Purpose |
|---|---|
| `invoices` | Invoices and quotations (`doc_type`), totals, paid and due amounts, cancellation details |
| `invoice_items` | Lines of an invoice or quotation |
| `receipts` | Money received (payment) or paid out (refund), with method, transaction ID, account and cancellation details |
| `payment_allocations` | Which part of a receipt was applied to which invoice |
| `cash_accounts` | Cash boxes, bank accounts and mobile wallets with opening balance |
| `account_transfers` | Moves of money between accounts |
| `expense_categories` | Expense categories per company |
| `expenses` | Spending, with approval status and optional campaign and account |

## Visa

| Table | Purpose |
|---|---|
| `visa_applications` | One file per application: destination, category, dates, status, decision and validity |
| `visa_status_history` | Every status change, with who and when |
| `visa_checklist_items` | Document checklist per file, with received and verified status |

## HR and office

| Table | Purpose |
|---|---|
| `employees` | Staff records (salary is protected by permission) |
| `attendance` | One row per person per day, with check-in, check-out, late and early minutes |
| `leave_requests` | Leave with dates, days, decision |
| `tasks` | Office tasks with priority, status and due date |

## Files, notifications and audit

| Table | Purpose |
|---|---|
| `documents` | Metadata of private files (the file itself is in `UPLOAD_DIR`), linked to a customer, visa file, employee or expense |
| `notifications` | In-app messages per user |
| `audit_logs` | Record of important actions |

## Important constraints

- `invoices`: unique (company, document type, number).
- `receipts`: unique (company, number); unique (company, form token); unique (company, transaction ID) for active receipts.
- `customers`, `leads`, `visa_applications`, `employees`: unique code per company.
- `user_company_access`: one row per person and company.
- `attendance`: one row per employee per day.
- Links to a company use `RESTRICT`: a company that has any records cannot be deleted (use Deactivate instead).
- Child lines (for example invoice items, status history and checklist items) are removed together with their parent record.
- Customers, invoices, receipts, cash accounts and employees are protected with `RESTRICT` where they are referenced, so they cannot be removed while they are in use.

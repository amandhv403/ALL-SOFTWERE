# Testing Report

This report lists exactly what was tested, how, and what the results were. Anything not listed here has **not** been tested yet.

## Test environment

| Item | Version or detail |
|---|---|
| Operating system | Linux sandbox (Debian 12) |
| Node.js | 22.23.4 |
| npm | 10.9.9 |
| Next.js | 16.4.2 (Turbopack build) |
| React | 19.2.6 |
| PostgreSQL | 15.19 |
| Drizzle ORM | 0.45.x with drizzle-kit 0.31.x |
| Zod | 4.6.x |

## 1. Build and type checks (all passed)

| Check | Command | Result |
|---|---|---|
| Route type generation | `npx next typegen` | Passed |
| TypeScript check (strict mode, whole project) | `npm exec tsc -- --noEmit` | Passed, 0 errors |
| Production build | `npm run build` | Passed, 0 warnings. 60+ routes generated |
| Start and health check | Platform start tool, then `GET /api/health` | Passed (`{"ok":true}`) |

Database schema: `npx drizzle-kit push` created all 33 tables and their indexes on an empty database, without warnings.

## 2. End-to-end smoke test (passed)

File: `scripts/smoke-test.mjs`. It talks to the running application over HTTP, the same way a browser does. It submits the same server-action requests the forms send, follows redirects, and checks the database directly with `psql`.

Run it on an **empty** database only, because it creates test accounts and records:

```
node scripts/smoke-test.mjs http://localhost:3000
```

**Result on a fresh database: 187 checks passed, 0 failed (two separate full runs in version 0.1.1; see REVIEW_REPORT.md).**

What the 183 checks cover:

| Area | Checks performed |
|---|---|
| First-time setup | Setup page shows; owner account created and signed in; owner stored; 15+ built-in roles created |
| Pages | Dashboard, companies, notifications, account, admin users, admin roles, admin audit all load (HTTP 200) |
| Companies | 11 portfolio companies created in one action; a custom company created; profile, numbering prefixes and working hours saved; modules switched on; branch and department created; deactivate and reactivate work |
| Leads | Lead created with code `LD-`; duplicate phone blocked; status change works; "lost" needs a reason; assignment works |
| Customers | Customer created with code `CUS-`; passport number stored in capitals; duplicate detected even when the phone is written as +880; follow-up scheduled; timeline note added; lead converted into a customer |
| Cash and bank | Two accounts created; transfer recorded; transfer larger than the balance refused |
| Invoices | Invoice with two lines and 15% tax; total correct; number uses company prefix (`DH-INV-`); quotation with discount created, accepted and converted into an invoice |
| Receipts | Receipt against invoice; receipt number uses company prefix; invoice status becomes partially paid; **same form submitted twice creates only one receipt**; **same transaction ID refused**; advance (money with no invoice) recorded; advance applied to an invoice; due amounts recalculated correctly |
| Cancellations | Invoice with payments cannot be cancelled; receipt cancelled with reason; cancelled receipt keeps its number; invoice balance restored after the cancellation |
| Expenses | Expense recorded and auto-approved for the owner |
| Visa | File opened with company prefix (`DH-VISA-`); 10+ checklist items created; status changes recorded in history; refusal without reason refused; approval with validity dates; checklist item verified |
| Documents | PDF uploaded; opened inline by an authorised user; downloaded as an attachment; **refused (401) without signing in**; access logged |
| HR | Employee created with code `EMP-`; salary stored; attendance saved; **late minutes calculated correctly (15 minutes after the grace period)**; status changed to late; leave requested; leave days counted; **overlapping leave refused**; leave approved |
| Tasks, targets, campaigns | Task created and completed; revenue target created; campaign created |
| Roles and permissions | Custom role created and deleted; unknown permission name refused; staff login created and given the Read-only role |
| Staff restrictions | Staff login signs in; **salary not shown** on the employee page; **cannot create expenses**; **sent away from the payment form**; **cannot open a company they are not assigned to**; **cannot open the admin pages**; **CSV export refused (403)** |
| Sessions and accounts | Switched-off login loses its session; password reset by the owner; **account locked after 5 wrong passwords**; team access removed (history kept); profile updated; notifications marked read |
| Exports | CSV exports for leads, customers, invoices, receipts, expenses, visa files, employees and attendance all return correct content type; export of employees includes the salary column for the owner; exports logged |
| Pages with real data | 40+ pages opened with data present (company dashboard, invoice print, receipt print in A4 and compact, cash ledger, reports, visa file, employee file, targets, campaigns and more) |

## 2a. Arena preview fix and sign-in cookies (version 0.1.2)

Problem reported: the Arena Code preview showed "refused to connect". Cause: every page sent `X-Frame-Options: DENY`, which stops any other website from showing the application. Fix: the framing rule now follows the `FRAME_ANCESTORS` setting (see README section 3a).

| Test | Result |
|---|---|
| End-to-end test with the preview settings (`FRAME_ANCESTORS` lists the Arena addresses) | 192 passed, 0 failed |
| End-to-end test with the live-site settings (fresh copy extracted from the ZIP, `FRAME_ANCESTORS` empty, installed, built and started from scratch) | 192 passed, 0 failed |
| Framing, preview settings: `X-Frame-Options` removed; `frame-ancestors` lists arena.ai, *.arena.ai and *.arena.site | Passed |
| Framing, live-site settings: `X-Frame-Options: DENY` and `frame-ancestors 'none'` (framing blocked, as intended) | Passed |
| Sign-in cookie, preview settings: `SameSite=None; Secure; Partitioned` | Passed |
| Sign-in cookie, live-site settings: `HttpOnly; SameSite=Lax` | Passed |
| Sign-out overwrites the sign-in cookie, and the dashboard then asks for sign-in again | Passed |
| "Mark all notifications as read" changes the unread count from 1 to 0 (the earlier version of this check always passed) | Passed |
| An invalid `FRAME_ANCESTORS` value (for example `http://...`) stops the build with a clear message | Passed |

Not verified in this round (be aware):
- **A real browser window showing the Arena preview.** The framing tests simulate the request the Arena preview sends (a page loaded inside a frame from arena.ai). Someone must open the preview in Chrome or Edge to confirm it shows the sign-in page.
- **The Arena address itself.** During this round it still returned the previous headers. The platform rebuilds that address after the work for a turn ends, so it must be checked again after that rebuild.

## 3. Backup and restore (passed)

Procedure in BACKUP_RESTORE_GUIDE.md was run on the test database:

1. `pg_dump` in custom format created a 160 KB dump with 33 tables.
2. `pg_restore --list` confirmed the table list.
3. The dump was restored into a new empty database. Company, invoice and receipt counts matched the live database exactly (12, 3 and 2).
4. The scratch database was then removed.

Note: `createdb` without a saved password waits for input. Use `psql` with the connection string instead (the guide now shows this).

## 4. Browser assets

The sign-in page references 13 JavaScript files. A sample file returned HTTP 200, so the interactive forms and menus have their browser code available.

## What has NOT been tested

Be aware of these gaps before relying on the system:

1. **Real browser clicks.** The smoke test calls the server directly. It does not click buttons in a real browser, so the visual feedback of the forms (red error text next to fields, the "Saving…" button label, the company switcher, the mobile menu, date pickers) has been checked only by code review, not by eye.
2. **Mobile and tablet layout.** Responsive classes are used, but no phone or tablet screenshot test has been done.
3. **Printing.** The print pages were checked for data and content. Actual printed paper and "Save as PDF" output were not checked.
4. **Load and speed.** No test with many thousands of records or many simultaneous users.
5. **Security testing by a specialist.** No penetration test. See SECURITY_NOTES.md.
6. **Upgrade path with real data.** Schema changes were applied to empty databases. An upgrade test with a copy of real data is needed before the first real update.
7. **Excel import, PDF generation on the server, e-mail, SMS and WhatsApp.** These features are not built.
8. **Deployment.** The application has not been deployed to a live hosting service (see DEPLOYMENT_GUIDE.md and DEVELOPMENT_STATUS.md).

## Known issues found during testing

| Issue | Status |
|---|---|
| Smoke test first run failed because the test harness sent form fields in the wrong order | Fixed in the test harness (not in the application) |
| Smoke test expected wrong balances in two checks | Fixed expectations after checking the arithmetic (invoice total 35,000) |
| System roles were not recreated if the database was reset while the app was running | Fixed: the role check now reads the database each time |
| Turbopack warning about dynamic file paths in the storage module | Fixed with a bundler hint. Build is now warning-free |
| Build generated `tsconfig.json` changes from Next.js (`jsx` setting, extra include path) | Accepted: these are Next.js standard settings |

## How to repeat these tests

1. Start with an empty database (`DROP SCHEMA public CASCADE; CREATE SCHEMA public;`, then `npx drizzle-kit push`).
2. Run `npm run build` and `npm run start`.
3. Run `node scripts/smoke-test.mjs http://localhost:3000`.
4. Expect `187 passed, 0 failed` (the number grows as tests are added).

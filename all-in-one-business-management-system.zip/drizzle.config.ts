import "dotenv/config";
import { defineConfig } from "drizzle-kit";

// Reads DATABASE_URL from the .env file, so no credentials are stored in code.
export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  dbCredentials: {
    url: process.env.DATABASE_URL ?? "",
  },
});

# Development Status

Last updated: version 0.1.2 (Arena Code preview fix), after two full review rounds (see REVIEW_REPORT.md). Earlier status (0.1.0) is kept in CHANGELOG.md.

This page is the honest summary of what works, what does not, and what is needed next. Numbers and results come from the tests in TESTING_REPORT.md.

## Summary

| Question | Answer |
|---|---|
| Is the software usable for real work now? | **Yes, for the modules listed under "Working", after the owner completes the setup steps below.** Use it on a private network or a secured server (see DEPLOYMENT_GUIDE.md) |
| Is it the complete all-in-one platform described in the brief? | **No.** It is the foundation and the core business modules (Phases 1, 2, 5 and most of 3, 4 and 6). Several business-specific modules and integrations are still to be built |
| Is it on GitHub? | **No.** No GitHub access was available in this session. The source is ready to push (see Owner actions) |
| Is it live on Vercel or another host? | **No.** No hosting account was available. Deployment steps are in DEPLOYMENT_GUIDE.md |
| Is there a ZIP of the source code? | **Yes**: `BUSINESS-MANAGEMENT-SYSTEM.zip`, in the project folder. It was extracted and checked (see below) |
| Does it build and pass checks? | **Yes.** Type generation, TypeScript check and production build pass with no warnings. The end-to-end smoke test passes 183 of 183 checks |

## Phase progress

| Phase (from the brief) | Status | Notes |
|---|---|---|
| 1. Foundation (setup, database, sign-in, companies, branches, departments, users, roles, permissions, owner dashboard) | **Done** | Permissions are enforced on the server for pages and actions. Department-level data limits are not yet enforced (branch-level is) |
| 2. CRM and data entry | **Mostly done** | Leads, customers, follow-ups, timeline, duplicate check, conversion, pipeline. **Not yet:** CSV/Excel import with preview, draft records, data-correction history, customer complaints and support tickets, customer segmentation, repeat-customer report |
| 3. Sales and marketing | **Partly done** | Quotations, pricing from a service catalogue, discounts, targets with achievement, campaigns with cost per lead and return, lost-deal reasons. **Not yet:** sales commission, sales forecasting, custom pipeline stages per company, promotional offers and discount campaigns, social media content calendar, direct platform integrations |
| 4. Visa, travel, education | **Visa done; travel and education not started** | Visa files, checklist, documents, status history, appointments, refusal and approval records. **Not yet:** country and requirement database, document templates (cover letters, sponsorship letters), embassy correspondence log, visa-expiry reminders. Travel bookings and the education university/course database are not started |
| 5. Accounting (basic operational) | **Done (basic)** | Invoices, quotations, receipts, partial and advance payments, refunds with approval, cancellations with reasons, reprints, expenses with approval, cash and bank accounts, transfers, reports. **Not yet:** chart of accounts, general ledger, journal entries, trial balance, profit and loss, balance sheet, bank reconciliation, budgets, accounts payable with supplier bills. These are future accounting work and the database is ready for them |
| 6. HR | **Partly done** | Employee records, salary protection, attendance with late calculation, leave with approval and overlap checks. **Not yet:** payroll, payslips, salary advances and loans, allowances and deductions, performance reviews, training and warning records, resignation and final settlement, employee self-service portal (except leave requests linked to a login) |
| 7. Office management, procurement, inventory, support | **Partly done** | Tasks board, notifications, audit log, approvals (expenses and leave, one level). **Not yet:** meetings and minutes, assets and maintenance, visitor and courier registers, supplier management and purchase orders, inventory, customer support tickets, multi-level approval chains |
| 8. Specialist businesses (tourism projects, community partners, cultural tourism, e-commerce, bookings and sessions) | **Not started** | The company types exist, and the services catalogue can be used, but no specialist workflows yet |
| 9. Reports and automation | **Partly done** | Reports for money, aging, expenses, leads, visa, attendance, and CSV exports. **Not yet:** PDF and Excel export from reports, scheduled reports, automatic reminders by e-mail or WhatsApp |
| 10. Production and delivery | **Partly done** | Security notes, testing, documentation, backup procedure tested, ZIP created. **Not yet:** GitHub repository, Vercel or other hosting, production database, HTTPS setup, penetration test, performance test, Windows setup script |

## Completed and working

- **Sign-in:** first-time owner setup, sign-in, sign-out, password change, account lockout, switching accounts off.
- **Companies:** create, edit profile, numbering, working hours, logo, module switches, activate and deactivate, one-click creation of the 11 portfolio businesses.
- **Structure and access:** branches, departments, team access by company with role, branch and department, individual extra and removed permissions, 15 built-in company roles, 2 top-level roles, custom roles.
- **CRM:** leads, customers, follow-ups, notes and timeline, conversion, duplicate warnings, pipeline.
- **Sales and marketing:** quotations, targets, campaigns.
- **Visa:** files, checklist, documents (private), status history, dates and decisions.
- **Accounting:** invoices, quotations, receipts, advances, refunds, cancellations, reprints, expenses, cash and bank, transfers, printable A4 invoices and receipts with amount in words.
- **HR:** employees, attendance sheet, leave.
- **Office:** tasks, notifications, audit log.
- **Reports and exports:** reports page, CSV exports with permissions and logging.
- **Security:** server-side permission checks on every page and action, private file storage with type checks, login-protected file viewer, audit log.

## Incomplete or limited (be aware)

- Printed documents are produced by the browser's print function. "Save as PDF" works, but there is no server-side PDF file generator yet.
- Reports can be exported as CSV only (no Excel or PDF).
- Customer lifetime value, aging and income figures are operational views. They are not statutory accounts.
- Branch limits apply to lists and records. Department limits are not enforced on data yet.
- The Arena Code preview works only when it is opened inside arena.ai. A direct link shows "Preview Unavailable". Sign-in inside the preview works best in Chrome or Edge. The live site is not affected.
- Visa-expiry and passport-expiry warnings show in the lists (red text). Automatic reminders are not sent.
- Document access is protected, but there is no separate consent record for each document.
- The customer's marketing consent is a tick box only. Consent history and withdrawal records are not built.
- Only single-level approvals exist for expenses, leave and refunds.
- Sales targets measure revenue, leads, conversions, visa files, approvals and completed tasks. Custom KPIs are not available.

## Known issues

| Issue | Impact | Planned fix |
|---|---|---|
| Browser-side behaviour has not been tested with a real browser | Small visual or interaction issues may exist | Browser test run before go-live |
| Mobile layout has not been checked on a real phone | Some tables may need horizontal scrolling on small screens | Screen review on phones and tablets |
| No two-factor sign-in and no "forgot password" e-mail | Owner must reset passwords by hand | Add two-factor sign-in and e-mail reset when an e-mail provider is chosen |
| Login limit is per account, not per network address | Someone could try many accounts slowly | Add per-address limits behind the production proxy |
| Sessions last 12 hours with no idle timeout | Shared computers need manual sign-out | Add idle timeout |
| Backups are manual | Risk of missing a backup | Scheduled backup job and a restore test every quarter |
| No automated database migrations (schema is applied with `drizzle-kit push`) | Safe for now, but needs care with real data | Move to generated migration files before the first production update |
| Date and time shown are Bangladesh time, but the input for appointment times assumes Bangladesh time too | Correct for Bangladesh-based staff; wrong if staff set times for another zone | Add a time-zone setting per company |

## Actions required from the owner

1. **Create the Owner account** the first time you open the system, and keep its password in a password manager.
2. **Choose the hosting setup.** Recommended: a small Linux server (VPS) with PostgreSQL and HTTPS, as described in DEPLOYMENT_GUIDE.md. Tell the developer which you prefer.
3. **Create or give access to a GitHub repository** (private is recommended). Then the source can be pushed with the instructions in the Next steps.
4. **Create or give access to a hosting account** (for example Vercel with a managed database, or a VPS). Hosting accounts must belong to the company, not to a personal login if possible.
5. **Confirm the business rules** that the system needs to follow:
   - VAT or tax rates by service, and whether invoices must show a tax number;
   - which roles may approve expenses, refunds and leave;
   - the default working hours and grace period for late arrival;
   - the number format for each company (the defaults are `DH-INV-00001` style);
   - how long to keep passports and personal documents after a visa is finished.
6. **Set a backup schedule** (daily database backup and copy of the document folder) and assign someone to check it.
7. **Set up the staff accounts and roles** on the Team page of each company, and remove access for people who have left.
8. **Share the privacy notice** with customers, and decide the wording for the marketing consent tick box.

## Recommended next steps (in order)

1. **Browser test and phone test** of the main flows (sign in, lead to customer, invoice to receipt, visa file, attendance).
2. **Test an update with a copy of real data** after the first real entries are made.
3. **Publish to GitHub:** create a private repository, add it as the remote, and push the `main` branch. The repository should contain the source only. Never commit `.env`.
4. **Deploy** to the chosen host and run the smoke test against the live address (on a test database first).
5. **Build the next modules** in this order, based on the business's priorities: passport and visa expiry reminders by e-mail, supplier bills and payments, payroll and payslips, customer support tickets, education applications and university database, travel bookings, and the specialist modules for tourism, e-commerce and sessions.
6. **Add Excel import** for customers and leads with an import preview and error report.
7. **Add a server-side PDF generator** for invoices, receipts and reports, and Excel exports for reports.
8. **Add two-factor sign-in** for the Owner and finance roles.
9. **Security review** by a specialist before handling large volumes of passport data.

## Source and package

- Project files are in the project folder. Dependencies are listed in `package.json` and `package-lock.json`.
- The ZIP `BUSINESS-MANAGEMENT-SYSTEM.zip` contains the source, documents and the smoke test. It does not contain `node_modules`, build output, uploaded files or the `.env` secrets file.
- To recreate the software: extract the ZIP, follow INSTALLATION_GUIDE.md, and run the database setup in DATABASE_SETUP_GUIDE.md.
